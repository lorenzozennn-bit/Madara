import com.madarataijutsu.anim.Pose;
import com.madarataijutsu.choreo.ChoreographyLibrary;
import com.madarataijutsu.choreo.Choreography;
import com.madarataijutsu.choreo.ImpactType;
import com.madarataijutsu.combat.CombatState;
import com.madarataijutsu.combat.CombatStateMachine;
import com.madarataijutsu.combat.SceneFx;
import com.madarataijutsu.combat.VirtualActor;
import com.madarataijutsu.mode.TaijutsuMode;

import java.util.HashSet;
import java.util.Set;

public class ChoreoSimTest {
    static int failures = 0;

    static void check(boolean cond, String msg) {
        if (!cond) { failures++; System.out.println("  FALHA: " + msg); }
    }

    public static void main(String[] args) {
        Set<String> signatures = new HashSet<>();
        for (TaijutsuMode mode : TaijutsuMode.values()) {
            Choreography c = ChoreographyLibrary.get(mode);
            System.out.println("== " + mode.shortName() + ": " + c.steps().size() + " etapas, " + c.totalTicks() + " ticks");
            check(c.actorCount() == mode.opponents, "numero de atores");
            StringBuilder sig = new StringBuilder();
            c.steps().forEach(s -> sig.append(s.playerClip == null ? "-" : s.playerClip.name).append(s.face).append(';'));
            check(signatures.add(sig.toString()), "sequencia repetida em " + mode);

            for (String scenario : new String[]{"paced", "spam", "slow"}) {
                final int[] impacts = {0};
                final int[] defeats = {0};
                final int[] victories = {0};
                CombatStateMachine m = new CombatStateMachine();
                m.setFx(new SceneFx() {
                    public void onImpact(VirtualActor a, ImpactType t) { impacts[0]++; }
                    public void onActorDefeated(VirtualActor a) { defeats[0]++; }
                    public void onVictory() { victories[0]++; }
                });
                m.start(c, 0);
                check(m.state() == CombatState.READY, "estado inicial READY");
                Pose tmp = new Pose();
                int clicks = 0;
                for (int t = 1; t < 4000; t++) {
                    boolean click;
                    if (scenario.equals("spam")) click = true;               // clique em todo tick
                    else if (scenario.equals("slow")) click = t % 40 == 0;     // espera a etapa acabar
                    else click = t % 12 == 0;
                    if (click) { m.onClick(t); clicks++; }
                    m.tick(t);
                    // amostra com partialTicks
                    for (float p = 0; p < 1; p += 0.25f) {
                        float now = t + p;
                        check(m.player().pose(now, tmp).isFinite(), "pose do jogador finita");
                        for (VirtualActor a : m.actors()) {
                            check(a.pose(now, tmp).isFinite(), "pose do ator finita");
                            float r = a.radius(now);
                            check(r > 0.5f && r < 4f, "raio plausivel " + r);
                        }
                    }
                    if (m.state() == CombatState.VICTORY && t > 3000) break;
                }
                check(m.state() == CombatState.VICTORY, scenario + ": terminou em VICTORY (" + m.state() + ")");
                check(victories[0] == 1, scenario + ": vitoria disparada 1x (" + victories[0] + ")");
                check(defeats[0] == mode.opponents, scenario + ": derrotas = " + defeats[0]);
                for (VirtualActor a : m.actors()) check(a.isDefeated(), scenario + ": ator " + a.index + " caido");
                // cliques apos vitoria nao reiniciam
                check(!m.onClick(5000), "clique apos vitoria ignorado");
                m.tick(5001);
                check(m.state() == CombatState.VICTORY, "continua em vitoria");
                // jogador termina na pose de vitoria (segura)
                check(m.player().currentClipName().equals("p_victory"), "clip final do jogador = " + m.player().currentClipName());
                for (VirtualActor a : m.actors()) check(a.currentClipName().startsWith("a_fall"), "ator caido clip " + a.currentClipName());
                System.out.println("  " + scenario + ": OK impactos=" + impacts[0] + " derrotas=" + defeats[0] + " cliques=" + clicks);

                // reinicio (tecla R)
                m.start(c, 6000);
                check(m.state() == CombatState.READY, "R volta a READY");
                check(m.actors().size() == mode.opponents, "R restaura atores");
                for (VirtualActor a : m.actors()) check(!a.isDefeated(), "R restaura atores em pe");
                check(m.stepNumber() == 0, "R reinicia etapas");
                m.stop();
                check(m.actors().isEmpty() && m.state() == CombatState.INACTIVE, "V remove atores");
            }
        }
        // Teste do giro 360: transicao do chute giratorio para guarda nao deve "desgirar".
        Pose a = new Pose().yaw(-385), b = new Pose().yaw(-25), out = new Pose();
        Pose.blendWrapped(a, b, 0.5f, out);
        check(Math.abs(out.get(Pose.ROOT_YAW) - -25f) < 0.01f, "wrap de yaw (" + out.get(Pose.ROOT_YAW) + ")");

        System.out.println(failures == 0 ? "\nTODOS OS TESTES PASSARAM" : "\nFALHAS: " + failures);
        System.exit(failures == 0 ? 0 : 1);
    }
}
