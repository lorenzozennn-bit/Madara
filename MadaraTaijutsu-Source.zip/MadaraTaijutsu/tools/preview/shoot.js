// Uso: node shoot.js <json> <outdir> [filtro]
const { chromium } = require('playwright');
const fs = require('fs');
const http = require('http');
const path = require('path');

const root = __dirname;
const server = http.createServer((req, res) => {
  const f = path.join(root, decodeURIComponent(req.url.split('?')[0]));
  if (!f.startsWith(root) || !fs.existsSync(f)) { res.writeHead(404); return res.end(); }
  const ext = path.extname(f);
  res.writeHead(200, { 'Content-Type': ext === '.html' ? 'text/html' : ext === '.js' ? 'text/javascript' : 'application/json' });
  fs.createReadStream(f).pipe(res);
});

(async () => {
  await new Promise(r => server.listen(8123, r));
  const [jsonPath, outDir, filter] = process.argv.slice(2);
  fs.mkdirSync(outDir, { recursive: true });
  fs.copyFileSync(jsonPath, path.join(root, 'data.json'));
  const browser = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const page = await browser.newPage();
  page.on('console', m => { if (m.type() === 'error') console.log('console:', m.text()); });
  page.on('pageerror', e => console.log('pageerror:', e.message));
  await page.goto('http://localhost:8123/index.html');
  await page.waitForFunction('window.ready === true');
  const names = await page.evaluate(async () => {
    window.DATA = await (await fetch('/data.json')).json();
    return window.DATA.sheets.map(s => s.name);
  });
  for (const name of names) {
    if (filter && !new RegExp(filter).test(name)) continue;
    const scene = name.startsWith('scene_');
    const opts = name === 'scene_1v1'
      ? { tile: 300, maxCols: 8, views: [[-90, 8, 6.0, 0, 1.5, 1.4]] }
      : scene
      ? { tile: 280, maxCols: 8, views: [[20, 62, 8.5, 0, 0.3, 0]] }
      : { tile: 260, views: [[65, 38, 3.8], [-90, 8, 3.6]] };
    const url = await page.evaluate(([n, o]) => window.renderSheet(window.DATA, n, o), [name, opts]);
    fs.writeFileSync(path.join(outDir, name + '.png'), Buffer.from(url.split(',')[1], 'base64'));
    console.log('png', name);
  }
  await browser.close();
  server.close();
})();
