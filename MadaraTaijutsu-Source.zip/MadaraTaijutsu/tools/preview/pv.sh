#!/bin/bash
# Compila lógica + exporta + renderiza folhas filtradas. Uso: pv.sh "<regex>"
set -e
cd /home/claude/MadaraTaijutsu
rm -rf /tmp/pv && mkdir -p /tmp/pv
S=src/main/java/com/madarataijutsu
javac --release 8 -Xlint:-options -encoding UTF-8 -d /tmp/pv $S/anim/*.java $S/choreo/*.java $S/combat/*.java $S/rig/*.java $S/mode/TaijutsuMode.java tools/PreviewExport.java 2>&1 | grep -v JAVA_TOOL || true
java -cp /tmp/pv PreviewExport /tmp/preview.json 7 2>&1 | grep -v JAVA_TOOL
cd /home/claude/preview && timeout 600 node shoot.js /tmp/preview.json /tmp/shots "$1" 2>&1 | grep -v "^png" || true
