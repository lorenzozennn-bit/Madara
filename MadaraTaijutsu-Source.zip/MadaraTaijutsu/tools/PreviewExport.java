import com.madarataijutsu.anim.Clip;
import com.madarataijutsu.anim.Pose;
import com.madarataijutsu.choreo.ActorClips;
import com.madarataijutsu.choreo.ChoreographyLibrary;
import com.madarataijutsu.choreo.PlayerClips;
import com.madarataijutsu.combat.CombatState;
import com.madarataijutsu.combat.CombatStateMachine;
import com.madarataijutsu.combat.VirtualActor;
import com.madarataijutsu.mode.TaijutsuMode;
import com.madarataijutsu.rig.BoxMesh;
import com.madarataijutsu.rig.Mat4;
import com.madarataijutsu.rig.Skeleton;

import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Ferramenta de desenvolvimento: exporta a geometria e as matrizes de cada osso
 * (calculadas pelo MESMO código usado no jogo) para a pré-visualização 3D.
 *
 * Uso: java -cp <classes> PreviewExport saida.json [quadrosPorClipe]
 */
public class PreviewExport {

    static StringBuilder sb = new StringBuilder();

    public static void main(String[] args) throws Exception {
        String outPath = args.length > 0 ? args[0] : "preview.json";
        int framesPerClip = args.length > 1 ? Integer.parseInt(args[1]) : 8;
        sb.append("{\"meshes\":");
        meshes();
        sb.append(",\"sheets\":[");
        boolean first = true;
        for (Field f : PlayerClips.class.getFields()) {
            if (Modifier.isStatic(f.getModifiers()) && f.getType() == Clip.class) {
                if (!first) sb.append(',');
                first = false;
                clipSheet((Clip) f.get(null), true, framesPerClip);
            }
        }
        for (Field f : ActorClips.class.getFields()) {
            if (Modifier.isStatic(f.getModifiers()) && f.getType() == Clip.class) {
                sb.append(',');
                clipSheet((Clip) f.get(null), false, framesPerClip);
            }
        }
        for (TaijutsuMode m : TaijutsuMode.values()) {
            sb.append(',');
            sceneSheet(m);
        }
        sb.append("]}");
        try (FileWriter w = new FileWriter(outPath)) {
            w.write(sb.toString());
        }
        System.out.println("ok " + outPath + " " + sb.length() / 1024 + " KB");
    }

    static void meshes() {
        sb.append('[');
        for (int s = 0; s < 2; s++) {
            if (s > 0) sb.append(',');
            sb.append('[');
            for (int b = 0; b < Skeleton.BONES; b++) {
                if (b > 0) sb.append(',');
                sb.append("{\"in\":");
                mesh(Skeleton.inner(s == 1, b));
                sb.append(",\"out\":");
                mesh(Skeleton.outer(s == 1, b));
                sb.append('}');
            }
            sb.append(']');
        }
        sb.append(']');
    }

    static void mesh(BoxMesh m) {
        sb.append('[');
        boolean first = true;
        for (BoxMesh.Quad q : m.quads()) {
            if (!first) sb.append(',');
            first = false;
            sb.append('[');
            for (int i = 0; i < 12; i++) { num(q.xyz[i]); sb.append(','); }
            for (int i = 0; i < 8; i++) { num(q.uv[i]); sb.append(','); }
            num(q.nx); sb.append(','); num(q.ny); sb.append(','); num(q.nz);
            sb.append(']');
        }
        sb.append(']');
    }

    static void num(float f) {
        sb.append(String.format(Locale.ROOT, "%.4f", f));
    }

    /** Um corpo: posição no mundo (blocos), direção e pose. */
    static void body(double x, double y, double z, float yaw, Pose p, boolean slim, int tint) {
        Mat4[] bones = new Mat4[Skeleton.BONES];
        Skeleton.compute(p, slim, bones);
        Mat4 base = new Mat4().translate((float) x, (float) y, (float) z).mul(Skeleton.bodyMatrix(yaw, p));
        sb.append("{\"slim\":").append(slim).append(",\"tint\":").append(tint).append(",\"m\":[");
        for (int b = 0; b < Skeleton.BONES; b++) {
            if (b > 0) sb.append(',');
            Mat4 w = base.copy().mul(bones[b]);
            sb.append('[');
            for (int i = 0; i < 16; i++) { if (i > 0) sb.append(','); num(w.m[i]); }
            sb.append(']');
        }
        sb.append("]}");
    }

    /** Clipe isolado: jogador (ou ator) na origem olhando +Z, com o "parceiro" em guarda à frente. */
    static void clipSheet(Clip c, boolean player, int n) {
        sb.append("{\"name\":\"").append(c.name).append("\",\"frames\":[");
        int frames = c.loop ? 4 : n;
        for (int i = 0; i < frames; i++) {
            float t = frames == 1 ? 0 : c.duration * i / (frames - 1);
            Pose p = new Pose();
            c.sample(t, p);
            if (i > 0) sb.append(',');
            sb.append("{\"label\":\"t=").append(String.format(Locale.ROOT, "%.1f", t)).append("\",\"bodies\":[");
            body(0, 0, 0, 0, p, false, player ? 0 : 1);
            sb.append(',');
            Pose partner = new Pose();
            (player ? ActorClips.GUARD_IDLE : PlayerClips.GUARD_IDLE).sample(0, partner);
            body(0, 0, 1.45, 180, partner, player, player ? 1 : 0);
            sb.append("]}");
        }
        sb.append("]}");
    }

    /** Cena completa: um quadro no meio e outro no fim de cada etapa. */
    static void sceneSheet(TaijutsuMode mode) {
        sb.append("{\"name\":\"scene_").append(mode.shortName()).append("\",\"scene\":true,\"frames\":[");
        CombatStateMachine m = new CombatStateMachine();
        m.start(ChoreographyLibrary.get(mode), 0);
        int t = 0;
        boolean first = true;
        List<int[]> captures = new ArrayList<int[]>();
        int stepCount = m.stepCount();
        for (int s = 0; s < stepCount; s++) {
            m.onClick(t);
            int dur = ChoreographyLibrary.get(mode).steps().get(s).duration;
            int[] at = {t + Math.max(2, dur / 3), t + dur - 1};
            for (int k = 0; k < dur; k++) {
                t++;
                m.tick(t);
                for (int a : at) {
                    if (a == t) {
                        if (!first) sb.append(',');
                        first = false;
                        frame(m, t, "etapa " + (s + 1) + (a == at[0] ? " a" : " b"));
                    }
                }
            }
        }
        for (int k = 0; k < 30; k++) { t++; m.tick(t); }
        sb.append(',');
        frame(m, t, m.state() == CombatState.VICTORY ? "vitoria" : "fim");
        sb.append("]}");
    }

    static void frame(CombatStateMachine m, float now, String label) {
        sb.append("{\"label\":\"").append(label).append("\",\"bodies\":[");
        Pose p = new Pose();
        m.player().pose(now, p);
        body(0, 0, 0, m.player().facing(now), p, false, 0);
        for (VirtualActor a : m.actors()) {
            Pose ap = new Pose();
            a.pose(now, ap);
            double w = Math.toRadians(a.angle);
            double r = a.radius(now);
            sb.append(',');
            body(-Math.sin(w) * r, 0, Math.cos(w) * r, a.angle + 180, ap, a.slim, 1);
        }
        // remove vírgulas: corpos são separados abaixo
        sb.append("]}");
    }
}
