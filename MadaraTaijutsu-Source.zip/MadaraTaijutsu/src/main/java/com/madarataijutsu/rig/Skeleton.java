package com.madarataijutsu.rig;

import com.madarataijutsu.anim.Pose;

/**
 * Esqueleto articulado compatível com skins do Minecraft (Steve 4 px / Alex 3 px).
 *
 * Fonte única da geometria: o renderizador do jogo e a ferramenta de
 * pré-visualização usam exatamente estas matrizes e malhas.
 */
public final class Skeleton {

    public static final int TORSO = 0;
    public static final int HEAD = 1;
    public static final int R_UPPER_ARM = 2;
    public static final int R_FOREARM = 3;
    public static final int L_UPPER_ARM = 4;
    public static final int L_FOREARM = 5;
    public static final int R_THIGH = 6;
    public static final int R_SHIN = 7;
    public static final int L_THIGH = 8;
    public static final int L_SHIN = 9;
    public static final int BONES = 10;

    /** Distância do ombro até o cotovelo e do quadril até o joelho (px). */
    public static final float ELBOW_Y = 4.0F;
    public static final float KNEE_Y = 6.0F;

    private static final BoxMesh[][] INNER = new BoxMesh[2][];
    private static final BoxMesh[][] OUTER = new BoxMesh[2][];

    static {
        for (int s = 0; s < 2; s++) {
            boolean slim = s == 1;
            int aw = slim ? 3 : 4;
            float rx = slim ? -2.0F : -3.0F;
            BoxMesh[] in = new BoxMesh[BONES];
            BoxMesh[] out = new BoxMesh[BONES];

            in[TORSO] = new BoxMesh().addBox(-4, -12, -2, 8, 12, 4, 16, 16, 0.0F);
            out[TORSO] = new BoxMesh().addBox(-4, -12, -2, 8, 12, 4, 16, 32, 0.25F);
            in[HEAD] = new BoxMesh().addBox(-4, -8, -4, 8, 8, 8, 0, 0, 0.0F);
            out[HEAD] = new BoxMesh().addBox(-4, -8, -4, 8, 8, 8, 32, 0, 0.5F);

            in[R_UPPER_ARM] = new BoxMesh().addSegment(rx, -2, -2, aw, 6, 4, 40, 16, 0, 12, 0.0F);
            in[R_FOREARM] = new BoxMesh().addSegment(rx, 0, -2, aw, 6, 4, 40, 16, 6, 12, 0.0F);
            out[R_UPPER_ARM] = new BoxMesh().addSegment(rx, -2, -2, aw, 6, 4, 40, 32, 0, 12, 0.25F);
            out[R_FOREARM] = new BoxMesh().addSegment(rx, 0, -2, aw, 6, 4, 40, 32, 6, 12, 0.25F);

            in[L_UPPER_ARM] = new BoxMesh().addSegment(-1, -2, -2, aw, 6, 4, 32, 48, 0, 12, 0.0F);
            in[L_FOREARM] = new BoxMesh().addSegment(-1, 0, -2, aw, 6, 4, 32, 48, 6, 12, 0.0F);
            out[L_UPPER_ARM] = new BoxMesh().addSegment(-1, -2, -2, aw, 6, 4, 48, 48, 0, 12, 0.25F);
            out[L_FOREARM] = new BoxMesh().addSegment(-1, 0, -2, aw, 6, 4, 48, 48, 6, 12, 0.25F);

            in[R_THIGH] = new BoxMesh().addSegment(-2, 0, -2, 4, 6, 4, 0, 16, 0, 12, 0.0F);
            in[R_SHIN] = new BoxMesh().addSegment(-2, 0, -2, 4, 6, 4, 0, 16, 6, 12, 0.0F);
            out[R_THIGH] = new BoxMesh().addSegment(-2, 0, -2, 4, 6, 4, 0, 32, 0, 12, 0.25F);
            out[R_SHIN] = new BoxMesh().addSegment(-2, 0, -2, 4, 6, 4, 0, 32, 6, 12, 0.25F);

            in[L_THIGH] = new BoxMesh().addSegment(-2, 0, -2, 4, 6, 4, 16, 48, 0, 12, 0.0F);
            in[L_SHIN] = new BoxMesh().addSegment(-2, 0, -2, 4, 6, 4, 16, 48, 6, 12, 0.0F);
            out[L_THIGH] = new BoxMesh().addSegment(-2, 0, -2, 4, 6, 4, 0, 48, 0, 12, 0.25F);
            out[L_SHIN] = new BoxMesh().addSegment(-2, 0, -2, 4, 6, 4, 0, 48, 6, 12, 0.25F);

            INNER[s] = in;
            OUTER[s] = out;
        }
    }

    private Skeleton() {
    }

    public static BoxMesh inner(boolean slim, int bone) {
        return INNER[slim ? 1 : 0][bone];
    }

    public static BoxMesh outer(boolean slim, int bone) {
        return OUTER[slim ? 1 : 0][bone];
    }

    /**
     * Calcula as matrizes de cada osso no espaço do modelo (px, Y para baixo,
     * pés em y = 24). O quadril desce automaticamente para manter o pé mais
     * baixo apoiado no chão quando os joelhos dobram.
     */
    public static void compute(Pose p, boolean slim, Mat4[] out) {
        build(p, slim, 0.0F, out);
        float maxY = Math.max(footY(out[R_SHIN]), footY(out[L_SHIN]));
        float drop = 24.0F - maxY;
        if (drop > 0.001F) {
            build(p, slim, drop, out);
        }
    }

    private static final float[] TMP = new float[3];

    private static float footY(Mat4 shin) {
        float max = -1e9F;
        for (int i = 0; i < 4; i++) {
            float x = (i & 1) == 0 ? -2.0F : 2.0F;
            float z = (i & 2) == 0 ? -2.0F : 2.0F;
            synchronized (TMP) {
                shin.transformPoint(x, 6.0F, z, TMP);
                max = Math.max(max, TMP[1]);
            }
        }
        return max;
    }

    private static void build(Pose p, boolean slim, float drop, Mat4[] out) {
        for (int i = 0; i < BONES; i++) {
            if (out[i] == null) out[i] = new Mat4();
        }
        Mat4 hips = new Mat4().translate(0.0F, 12.0F + drop, 0.0F);

        out[TORSO].set(hips).rotateZYX(p.get(Pose.BODY), p.get(Pose.BODY + 1), p.get(Pose.BODY + 2));

        out[HEAD].set(out[TORSO]).translate(0.0F, -12.0F, 0.0F)
                .rotateZYX(p.get(Pose.HEAD), p.get(Pose.HEAD + 1), p.get(Pose.HEAD + 2));

        float shoulderY = slim ? -9.5F : -10.0F;
        out[R_UPPER_ARM].set(out[TORSO]).translate(-5.0F, shoulderY, 0.0F)
                .rotateZYX(p.get(Pose.R_ARM), p.get(Pose.R_ARM + 1), p.get(Pose.R_ARM + 2));
        out[R_FOREARM].set(out[R_UPPER_ARM]).translate(0.0F, ELBOW_Y, 0.0F).rotate(-p.get(Pose.R_ELBOW), 0);

        out[L_UPPER_ARM].set(out[TORSO]).translate(5.0F, shoulderY, 0.0F)
                .rotateZYX(p.get(Pose.L_ARM), p.get(Pose.L_ARM + 1), p.get(Pose.L_ARM + 2));
        out[L_FOREARM].set(out[L_UPPER_ARM]).translate(0.0F, ELBOW_Y, 0.0F).rotate(-p.get(Pose.L_ELBOW), 0);

        out[R_THIGH].set(hips).translate(-1.9F, 0.0F, 0.0F)
                .rotateZYX(p.get(Pose.R_LEG), p.get(Pose.R_LEG + 1), p.get(Pose.R_LEG + 2));
        out[R_SHIN].set(out[R_THIGH]).translate(0.0F, KNEE_Y, 0.0F).rotate(p.get(Pose.R_KNEE), 0);

        out[L_THIGH].set(hips).translate(1.9F, 0.0F, 0.0F)
                .rotateZYX(p.get(Pose.L_LEG), p.get(Pose.L_LEG + 1), p.get(Pose.L_LEG + 2));
        out[L_SHIN].set(out[L_THIGH]).translate(0.0F, KNEE_Y, 0.0F).rotate(p.get(Pose.L_KNEE), 0);
    }

    /**
     * Transformação raiz em blocos (aplicada depois da rotação de direção da
     * entidade e antes do scale(-1, -1, 1) do modelo).
     */
    public static Mat4 rootMatrix(Pose p) {
        Mat4 m = new Mat4();
        m.translate(p.get(Pose.OFF_X), p.get(Pose.OFF_Y), -p.get(Pose.OFF_F));
        m.rotate(p.get(Pose.ROOT_YAW), 1);
        float pitch = p.get(Pose.ROOT_PITCH);
        float roll = p.get(Pose.ROOT_ROLL);
        if (pitch != 0.0F || roll != 0.0F) {
            float pivot = p.get(Pose.PIVOT_Y);
            m.translate(0.0F, pivot, 0.0F);
            m.rotate(-pitch, 0);
            m.rotate(-roll, 2);
            m.translate(0.0F, -pivot, 0.0F);
        }
        return m;
    }

    /**
     * Matriz completa (mundo relativo aos pés -> espaço do modelo em px) usada
     * pela pré-visualização e pelos atores: mesma sequência do RenderLivingBase.
     */
    public static Mat4 bodyMatrix(float worldYaw, Pose p) {
        Mat4 m = new Mat4();
        m.rotate(180.0F - worldYaw, 1);
        m.mul(rootMatrix(p));
        m.scale(-1.0F, -1.0F, 1.0F);
        m.scale(0.9375F, 0.9375F, 0.9375F);
        m.translate(0.0F, -1.501F, 0.0F);
        m.scale(0.0625F, 0.0625F, 0.0625F);
        return m;
    }

    /**
     * Cadeia ombro -> cotovelo para posicionar o item na mão. Retorna a matriz
     * (px) em que o item vanilla, deslocado ~10 px "ao longo do braço",
     * cai na mão do antebraço.
     */
    public static Mat4 handAnchor(Mat4[] bones, boolean right) {
        Mat4 fore = bones[right ? R_FOREARM : L_FOREARM];
        return fore.copy().translate(0.0F, -ELBOW_Y, 0.0F);
    }
}
