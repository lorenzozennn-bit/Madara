package com.madarataijutsu.rig;

/**
 * Matriz 4x4 em ordem de colunas (column-major), mesmo formato do OpenGL.
 * Todas as operações multiplicam à direita, como as chamadas glTranslate/glRotate.
 */
public final class Mat4 {

    public final float[] m = new float[16];

    public Mat4() {
        identity();
    }

    public Mat4 identity() {
        for (int i = 0; i < 16; i++) m[i] = 0.0F;
        m[0] = m[5] = m[10] = m[15] = 1.0F;
        return this;
    }

    public Mat4 set(Mat4 o) {
        System.arraycopy(o.m, 0, m, 0, 16);
        return this;
    }

    public Mat4 copy() {
        return new Mat4().set(this);
    }

    /** this = this * o */
    public Mat4 mul(Mat4 o) {
        float[] a = m, b = o.m;
        float[] r = new float[16];
        for (int c = 0; c < 4; c++) {
            for (int row = 0; row < 4; row++) {
                r[c * 4 + row] = a[row] * b[c * 4] + a[4 + row] * b[c * 4 + 1]
                        + a[8 + row] * b[c * 4 + 2] + a[12 + row] * b[c * 4 + 3];
            }
        }
        System.arraycopy(r, 0, m, 0, 16);
        return this;
    }

    public Mat4 translate(float x, float y, float z) {
        m[12] += m[0] * x + m[4] * y + m[8] * z;
        m[13] += m[1] * x + m[5] * y + m[9] * z;
        m[14] += m[2] * x + m[6] * y + m[10] * z;
        m[15] += m[3] * x + m[7] * y + m[11] * z;
        return this;
    }

    public Mat4 scale(float x, float y, float z) {
        for (int i = 0; i < 4; i++) {
            m[i] *= x;
            m[4 + i] *= y;
            m[8 + i] *= z;
        }
        return this;
    }

    /** Rotação em graus em torno de um eixo principal (0=X, 1=Y, 2=Z), como glRotate. */
    public Mat4 rotate(float degrees, int axis) {
        if (degrees == 0.0F) return this;
        double rad = Math.toRadians(degrees);
        float c = (float) Math.cos(rad);
        float s = (float) Math.sin(rad);
        Mat4 r = new Mat4();
        float[] q = r.m;
        switch (axis) {
            case 0:
                q[5] = c; q[6] = s; q[9] = -s; q[10] = c;
                break;
            case 1:
                q[0] = c; q[2] = -s; q[8] = s; q[10] = c;
                break;
            default:
                q[0] = c; q[1] = s; q[4] = -s; q[5] = c;
                break;
        }
        return mul(r);
    }

    /** Rotação de articulação na ordem do ModelRenderer: Z, depois Y, depois X. */
    public Mat4 rotateZYX(float xDeg, float yDeg, float zDeg) {
        return rotate(zDeg, 2).rotate(yDeg, 1).rotate(xDeg, 0);
    }

    /** Cópia com a translação multiplicada por s (para matrizes rígidas em px -> blocos). */
    public Mat4 withScaledTranslation(float s) {
        Mat4 r = copy();
        r.m[12] *= s;
        r.m[13] *= s;
        r.m[14] *= s;
        return r;
    }

    /** Transforma um ponto (x, y, z, 1) e grava em out[0..2]. */
    public void transformPoint(float x, float y, float z, float[] out) {
        out[0] = m[0] * x + m[4] * y + m[8] * z + m[12];
        out[1] = m[1] * x + m[5] * y + m[9] * z + m[13];
        out[2] = m[2] * x + m[6] * y + m[10] * z + m[14];
    }
}
