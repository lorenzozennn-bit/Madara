package com.madarataijutsu.rig;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Malha de caixas com o mesmo mapeamento UV do ModelBox do Minecraft, mas
 * permitindo recortar um membro (12 px de altura) em segmentos, para que
 * antebraço/canela usem a metade inferior da textura da skin.
 *
 * Coordenadas do modelo: pixels, Y para baixo, frente em -Z,
 * lado direito do personagem em -X. Textura 64x64.
 */
public final class BoxMesh {

    public static final float TEX = 64.0F;

    /** Um quadrilátero: 4 vértices (x, y, z, u, v) + normal. */
    public static final class Quad {
        public final float[] xyz = new float[12];
        public final float[] uv = new float[8];
        public final float nx, ny, nz;

        Quad(float nx, float ny, float nz) {
            this.nx = nx;
            this.ny = ny;
            this.nz = nz;
        }

        void put(int i, float x, float y, float z, float u, float v) {
            xyz[i * 3] = x;
            xyz[i * 3 + 1] = y;
            xyz[i * 3 + 2] = z;
            uv[i * 2] = u / TEX;
            uv[i * 2 + 1] = v / TEX;
        }
    }

    private final List<Quad> quads = new ArrayList<Quad>();

    public List<Quad> quads() {
        return Collections.unmodifiableList(quads);
    }

    /**
     * Adiciona um segmento de uma caixa da skin.
     *
     * @param x  canto mínimo X da caixa (px)
     * @param y  canto mínimo Y da caixa (px) no espaço do osso
     * @param z  canto mínimo Z da caixa (px)
     * @param w  largura (X) da caixa original
     * @param h  altura (Y) DO SEGMENTO
     * @param d  profundidade (Z)
     * @param u  offset U da caixa original na skin
     * @param v  offset V da caixa original na skin
     * @param rowStart linha (0..altura total) da textura lateral onde o segmento começa
     * @param fullHeight altura total da caixa original na skin
     * @param delta inflação (camadas externas da skin)
     */
    public BoxMesh addSegment(float x, float y, float z, int w, int h, int d, int u, int v,
                              int rowStart, int fullHeight, float delta) {
        float x0 = x - delta, y0 = y - delta, z0 = z - delta;
        float x1 = x + w + delta, y1 = y + h + delta, z1 = z + d + delta;

        float sideV0 = v + d + rowStart;
        float sideV1 = v + d + rowStart + h;

        // Frente (-Z): u cresce com x.
        float fu0 = u + d, fu1 = u + d + w;
        Quad q = new Quad(0, 0, -1);
        q.put(0, x1, y0, z0, fu1, sideV0);
        q.put(1, x0, y0, z0, fu0, sideV0);
        q.put(2, x0, y1, z0, fu0, sideV1);
        q.put(3, x1, y1, z0, fu1, sideV1);
        quads.add(q);

        // Costas (+Z): u decresce com x.
        float bu0 = u + d + w + d, bu1 = u + d + w + d + w;
        q = new Quad(0, 0, 1);
        q.put(0, x0, y0, z1, bu1, sideV0);
        q.put(1, x1, y0, z1, bu0, sideV0);
        q.put(2, x1, y1, z1, bu0, sideV1);
        q.put(3, x0, y1, z1, bu1, sideV1);
        quads.add(q);

        // -X (lado direito do personagem): z0 -> u+d, z1 -> u.
        q = new Quad(-1, 0, 0);
        q.put(0, x0, y0, z0, u + d, sideV0);
        q.put(1, x0, y0, z1, u, sideV0);
        q.put(2, x0, y1, z1, u, sideV1);
        q.put(3, x0, y1, z0, u + d, sideV1);
        quads.add(q);

        // +X (lado esquerdo): z0 -> u+d+w, z1 -> u+d+w+d.
        float lu0 = u + d + w, lu1 = u + d + w + d;
        q = new Quad(1, 0, 0);
        q.put(0, x1, y0, z1, lu1, sideV0);
        q.put(1, x1, y0, z0, lu0, sideV0);
        q.put(2, x1, y1, z0, lu0, sideV1);
        q.put(3, x1, y1, z1, lu1, sideV1);
        quads.add(q);

        // Topo (-Y): x -> u crescente; z1 -> v, z0 -> v+d.
        float tu0 = u + d, tu1 = u + d + w;
        q = new Quad(0, -1, 0);
        q.put(0, x1, y0, z1, tu1, v);
        q.put(1, x0, y0, z1, tu0, v);
        q.put(2, x0, y0, z0, tu0, v + d);
        q.put(3, x1, y0, z0, tu1, v + d);
        quads.add(q);

        // Base (+Y): x -> u crescente; z0 -> v+d, z1 -> v.
        float du0 = u + d + w, du1 = u + d + w + w;
        q = new Quad(0, 1, 0);
        q.put(0, x1, y1, z0, du1, v + d);
        q.put(1, x0, y1, z0, du0, v + d);
        q.put(2, x0, y1, z1, du0, v);
        q.put(3, x1, y1, z1, du1, v);
        quads.add(q);

        return this;
    }

    /** Caixa inteira (sem recorte). */
    public BoxMesh addBox(float x, float y, float z, int w, int h, int d, int u, int v, float delta) {
        return addSegment(x, y, z, w, h, d, u, v, 0, h, delta);
    }
}
