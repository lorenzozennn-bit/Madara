package com.madarataijutsu.proxy;

import com.madarataijutsu.MadaraTaijutsu;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

/** Lado servidor: o mod não faz nada (clientSideOnly), apenas registra no log. */
public class CommonProxy {

    public void preInit(FMLPreInitializationEvent event) {
        if (MadaraTaijutsu.logger != null) {
            MadaraTaijutsu.logger.info("Madara Taijutsu Cinematic é apenas client-side; nada a registrar no servidor.");
        }
    }

    public void init(FMLInitializationEvent event) {
    }
}
