package com.madarataijutsu.anim;

/** Um keyframe: instante (em ticks), pose e curva do segmento que termina nele. */
public final class Keyframe {
    public final float time;
    public final Pose pose;
    public final Ease ease;

    public Keyframe(float time, Pose pose, Ease ease) {
        if (pose == null) throw new IllegalArgumentException("pose nula");
        this.time = time;
        this.pose = pose.copy();
        this.ease = ease == null ? Ease.SMOOTH : ease;
    }
}
