package com.madarataijutsu.anim;

import java.util.ArrayList;
import java.util.List;

/**
 * Clipe de animação: sequência ordenada de keyframes. Amostrado com tempo
 * contínuo (ticks + partialTicks), o que garante suavidade em qualquer FPS.
 */
public final class Clip {

    public final String name;
    private final Keyframe[] keys;
    public final float duration;
    public final boolean loop;

    private Clip(String name, List<Keyframe> keys, boolean loop) {
        this.name = name;
        this.keys = keys.toArray(new Keyframe[0]);
        this.duration = this.keys[this.keys.length - 1].time;
        this.loop = loop;
    }

    public static Builder build(String name) {
        return new Builder(name);
    }

    public int keyCount() {
        return keys.length;
    }

    public Pose firstPose() {
        return keys[0].pose;
    }

    public Pose lastPose() {
        return keys[keys.length - 1].pose;
    }

    /** Escreve em {@code out} a pose no instante {@code t} (ticks desde o início do clipe). */
    public void sample(float t, Pose out) {
        if (loop && duration > 0.0F) {
            t = t % duration;
            if (t < 0.0F) t += duration;
        }
        if (t <= keys[0].time) {
            out.set(keys[0].pose);
            return;
        }
        Keyframe last = keys[keys.length - 1];
        if (t >= last.time) {
            out.set(last.pose);
            return;
        }
        for (int i = 1; i < keys.length; i++) {
            Keyframe b = keys[i];
            if (t <= b.time) {
                Keyframe a = keys[i - 1];
                float span = b.time - a.time;
                float local = span <= 0.0F ? 1.0F : (t - a.time) / span;
                Pose.lerp(a.pose, b.pose, b.ease.apply(local), out);
                return;
            }
        }
        out.set(last.pose);
    }

    public static final class Builder {
        private final String name;
        private final List<Keyframe> keys = new ArrayList<Keyframe>();
        private boolean loop;

        private Builder(String name) {
            this.name = name;
        }

        public Builder key(float time, Pose pose) {
            return key(time, pose, Ease.SMOOTH);
        }

        public Builder key(float time, Pose pose, Ease ease) {
            if (!keys.isEmpty() && time < keys.get(keys.size() - 1).time) {
                throw new IllegalArgumentException("keyframes fora de ordem no clipe " + name);
            }
            keys.add(new Keyframe(time, pose, ease));
            return this;
        }

        public Builder loop() {
            this.loop = true;
            return this;
        }

        public Clip done() {
            if (keys.isEmpty()) throw new IllegalStateException("clipe sem keyframes: " + name);
            return new Clip(name, keys, loop);
        }
    }
}
