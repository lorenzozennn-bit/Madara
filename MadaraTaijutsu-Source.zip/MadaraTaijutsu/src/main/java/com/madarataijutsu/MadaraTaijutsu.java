package com.madarataijutsu;

import com.madarataijutsu.proxy.CommonProxy;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import org.apache.logging.log4j.Logger;

/**
 * Madara Taijutsu Cinematic – classe principal.
 * Mod exclusivamente client-side: não registra blocos, itens, entidades nem pacotes.
 */
@Mod(modid = MadaraTaijutsu.MODID,
        name = MadaraTaijutsu.NAME,
        version = MadaraTaijutsu.VERSION,
        acceptedMinecraftVersions = "[1.12.2]",
        clientSideOnly = true)
public class MadaraTaijutsu {

    public static final String MODID = "madarataijutsu";
    public static final String NAME = "Madara Taijutsu Cinematic";
    public static final String VERSION = "1.0.0";

    public static Logger logger;

    @SidedProxy(clientSide = "com.madarataijutsu.client.ClientProxy",
            serverSide = "com.madarataijutsu.proxy.CommonProxy")
    public static CommonProxy proxy;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        logger = event.getModLog();
        proxy.preInit(event);
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        proxy.init(event);
    }
}
