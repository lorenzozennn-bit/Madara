package com.madarataijutsu.config;

import com.madarataijutsu.mode.TaijutsuMode;
import net.minecraftforge.common.config.Configuration;
import net.minecraftforge.common.config.Property;

import java.io.File;

/** Persistência das configurações em config/madarataijutsu.cfg. */
public final class TaijutsuConfig {

    private static Configuration config;
    private static Property modeProp;
    private static Property thirdPersonProp;
    private static Property speedProp;

    private TaijutsuConfig() {
    }

    public static void load(File file) {
        config = new Configuration(file);
        config.load();
        modeProp = config.get(Configuration.CATEGORY_GENERAL, "selectedMode", 1,
                "Modo selecionado: 1=1v1, 2=1v2, 3=1v3, 4=1v4, 5=1v5", 1, 5);
        thirdPersonProp = config.get(Configuration.CATEGORY_GENERAL, "autoThirdPerson", true,
                "Muda automaticamente para a câmera em terceira pessoa ao ativar o Taijutsu.");
        speedProp = config.get(Configuration.CATEGORY_GENERAL, "fightSpeed", 1.6D,
                "Velocidade das animações de luta (1.0 = normal, 1.6 = rápido, 2.0 = muito rápido).", 0.5D, 3.0D);
        if (config.hasChanged()) {
            config.save();
        }
    }

    public static TaijutsuMode getMode() {
        if (modeProp == null) return TaijutsuMode.ONE_V_ONE;
        return TaijutsuMode.byOpponents(modeProp.getInt(1));
    }

    public static void setMode(TaijutsuMode mode) {
        if (modeProp == null) return;
        modeProp.set(mode.opponents);
        config.save();
    }

    public static float fightSpeed() {
        if (speedProp == null) return 1.6F;
        double v = speedProp.getDouble(1.6D);
        return (float) Math.max(0.5D, Math.min(3.0D, v));
    }

    public static boolean autoThirdPerson() {
        return thirdPersonProp == null || thirdPersonProp.getBoolean(true);
    }
}
