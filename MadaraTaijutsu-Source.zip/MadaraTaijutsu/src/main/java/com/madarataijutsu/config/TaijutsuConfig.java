package com.madarataijutsu.config;

import com.madarataijutsu.mode.TaijutsuMode;
import net.minecraftforge.common.config.Configuration;
import net.minecraftforge.common.config.Property;

import java.io.File;

/** Persistência das configurações em config/madarataijutsu.cfg. */
public final class TaijutsuConfig {

    private static Configuration config;
    private static Property modeProp;
    private static Property thirdPersonProp;

    private TaijutsuConfig() {
    }

    public static void load(File file) {
        config = new Configuration(file);
        config.load();
        modeProp = config.get(Configuration.CATEGORY_GENERAL, "selectedMode", 1,
                "Modo selecionado: 1=1v1, 2=1v2, 3=1v3, 4=1v4, 5=1v5", 1, 5);
        thirdPersonProp = config.get(Configuration.CATEGORY_GENERAL, "autoThirdPerson", true,
                "Muda automaticamente para a câmera em terceira pessoa ao ativar o Taijutsu.");
        if (config.hasChanged()) {
            config.save();
        }
    }

    public static TaijutsuMode getMode() {
        if (modeProp == null) return TaijutsuMode.ONE_V_ONE;
        return TaijutsuMode.byOpponents(modeProp.getInt(1));
    }

    public static void setMode(TaijutsuMode mode) {
        if (modeProp == null) return;
        modeProp.set(mode.opponents);
        config.save();
    }

    public static boolean autoThirdPerson() {
        return thirdPersonProp == null || thirdPersonProp.getBoolean(true);
    }
}
