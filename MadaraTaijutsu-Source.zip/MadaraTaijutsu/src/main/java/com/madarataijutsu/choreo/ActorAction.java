package com.madarataijutsu.choreo;

import com.madarataijutsu.anim.Clip;

/** Ação de um adversário dentro de uma etapa, com atraso relativo ao início da etapa. */
public final class ActorAction {
    public final int actor;
    /** Clipe a tocar (pode ser nulo quando a ação é só movimento ou efeito). */
    public final Clip clip;
    public final int delay;
    /** Nova distância até o jogador, ou NaN para manter. */
    public final float radius;
    public final int moveTicks;
    public final ImpactType impact;
    public final boolean defeat;

    public ActorAction(int actor, Clip clip, int delay, float radius, int moveTicks, ImpactType impact, boolean defeat) {
        this.actor = actor;
        this.clip = clip;
        this.delay = delay;
        this.radius = radius;
        this.moveTicks = moveTicks;
        this.impact = impact == null ? ImpactType.NONE : impact;
        this.defeat = defeat;
    }

    public boolean movesRadius() {
        return !Float.isNaN(radius);
    }
}
