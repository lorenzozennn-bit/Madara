package com.madarataijutsu.choreo;

import com.madarataijutsu.mode.TaijutsuMode;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Coreografia completa de um modo: disposição dos adversários e etapas. */
public final class Choreography {

    public final TaijutsuMode mode;
    /** Nome da variação (mostrado ao ativar). */
    public final String name;
    /** Ângulo (graus) de cada adversário em volta do jogador. 0 = à frente. */
    private final float[] angles;
    public final float startRadius;
    private final List<Step> steps;

    public Choreography(TaijutsuMode mode, float[] angles, float startRadius, List<Step> steps) {
        this(mode, mode.label, angles, startRadius, steps);
    }

    public Choreography(TaijutsuMode mode, String name, float[] angles, float startRadius, List<Step> steps) {
        this.name = name;
        if (angles.length != mode.opponents) {
            throw new IllegalArgumentException("número de adversários não confere com o modo " + mode);
        }
        this.mode = mode;
        this.angles = angles.clone();
        this.startRadius = startRadius;
        this.steps = Collections.unmodifiableList(new ArrayList<Step>(steps));
        validate();
    }

    public int actorCount() {
        return angles.length;
    }

    public float angle(int actor) {
        return angles[actor];
    }

    public List<Step> steps() {
        return steps;
    }

    public int totalTicks() {
        int t = 0;
        for (Step s : steps) t += s.duration;
        return t;
    }

    /** Garante que toda coreografia termina com todos os adversários derrotados. */
    private void validate() {
        if (steps.isEmpty()) throw new IllegalStateException("coreografia vazia: " + mode);
        boolean[] defeated = new boolean[angles.length];
        for (int si = 0; si < steps.size(); si++) {
            Step s = steps.get(si);
            if (s.face >= angles.length) {
                throw new IllegalStateException(mode + " etapa " + (si + 1) + ": alvo inexistente");
            }
            for (ActorAction a : s.actions()) {
                if (a.actor < 0 || a.actor >= angles.length) {
                    throw new IllegalStateException(mode + " etapa " + (si + 1) + ": ator inexistente " + a.actor);
                }
                if (defeated[a.actor] && a.clip != null) {
                    throw new IllegalStateException(mode + " etapa " + (si + 1) + ": ator " + a.actor + " já derrotado");
                }
                if (a.delay >= s.duration) {
                    throw new IllegalStateException(mode + " etapa " + (si + 1) + ": atraso maior que a etapa");
                }
                if (a.defeat) defeated[a.actor] = true;
            }
        }
        for (int i = 0; i < defeated.length; i++) {
            if (!defeated[i]) throw new IllegalStateException(mode + ": adversário " + i + " nunca é derrotado");
        }
    }
}
