package com.madarataijutsu.choreo;

import com.madarataijutsu.anim.Clip;
import com.madarataijutsu.anim.Ease;
import com.madarataijutsu.anim.Pose;

/**
 * Animações dos adversários virtuais (esqueleto articulado). O "frente" do ator
 * é sempre a direção do jogador. Quedas terminam deitadas e são mantidas.
 */
public final class ActorClips {

    private ActorClips() {
    }

    /** Guarda de boxe simples, quadrado para o jogador. */
    public static final Pose GUARD = new Pose()
            .root(10, 0, 0)
            .body(8, -5, 0)
            .head(-4, -5, 0)
            .ra(-30, -20, 10).la(-40, 20, -10)
            .elbows(115, 100)
            .rl(14, 0, 5).ll(-16, 0, -5)
            .knees(25, 25);

    public static final Clip GUARD_IDLE = Clip.build("a_guard_idle")
            .key(0, GUARD)
            .key(10, Pose.from(GUARD).body(10, -5, 0).ra(-28, -20, 10).la(-38, 20, -10).knees(30, 30))
            .key(20, GUARD)
            .loop()
            .done();

    private static Pose stride(float phase) {
        return Pose.from(GUARD).body(12, -5, 0)
                .rl(-28 * phase, 0, 4).ll(28 * phase, 0, -4)
                .knees(phase > 0 ? 45 : 15, phase > 0 ? 15 : 45)
                .off(0, 0.02F, 0);
    }

    /** Aproximação em passos de luta (a distância é animada pela coreografia). */
    public static final Clip ADVANCE = Clip.build("a_advance")
            .key(0, GUARD)
            .key(3, stride(1))
            .key(6, stride(-1))
            .key(9, stride(1))
            .key(12, GUARD)
            .done();

    /** Soco de direita contra o jogador. Golpe chega: tick 6. */
    public static final Clip PUNCH = Clip.build("a_punch")
            .key(0, GUARD)
            .key(3, Pose.from(GUARD).root(25, 0, 0).body(5, 20, 0).ra(-20, 10, 30).elbows(130, 100))
            .key(6, Pose.from(GUARD).root(0, 0, 0).body(16, -30, 0).head(-4, 20, 0)
                    .ra(-90, -6, 0).elbows(0, 100).rl(15, -20, 5).knees(15, 40).off(0, 0, 0.3F), Ease.OUT)
            .key(8, Pose.from(GUARD).root(0, 0, 0).body(16, -28, 0).head(-4, 20, 0)
                    .ra(-88, -6, 0).elbows(5, 100).rl(15, -20, 5).knees(15, 40).off(0, 0, 0.28F))
            .key(13, GUARD)
            .done();

    /** Chute frontal contra o jogador. Golpe chega: tick 6. */
    public static final Clip KICK = Clip.build("a_kick")
            .key(0, GUARD)
            .key(3, Pose.from(GUARD).body(2, -5, 0).rl(-80, 0, 0).ll(-5, 0, -5).knees(110, 25))
            .key(6, Pose.from(GUARD).body(-12, -5, 0).head(8, -5, 0)
                    .rl(-90, 0, 0).ll(0, 0, -5).knees(0, 20).off(0, 0, 0.22F), Ease.OUT)
            .key(8, Pose.from(GUARD).body(-10, -5, 0).head(8, -5, 0)
                    .rl(-88, 0, 0).ll(0, 0, -5).knees(5, 20).off(0, 0, 0.2F))
            .key(13, GUARD)
            .done();

    /** Bloqueio alto; recua com o impacto. */
    public static final Clip BLOCK = Clip.build("a_block")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).body(14, 0, 0).head(12, 0, 0)
                    .ra(-80, -25, 0).la(-80, 25, 0).elbows(105, 105).knees(35, 35), Ease.OUT)
            .key(4, Pose.from(GUARD).body(8, 0, 0).head(12, 0, 0)
                    .ra(-80, -25, 0).la(-80, 25, 0).elbows(105, 105).knees(40, 40).off(0, 0, -0.15F))
            .key(9, GUARD)
            .done();

    /** Reação a golpe no rosto: cabeça e tronco jogados para trás. */
    public static final Clip HIT = Clip.build("a_hit")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).body(-22, 15, 0).head(-30, 20, 5)
                    .ra(-40, 0, 35).la(-50, 0, -30).elbows(60, 70).knees(30, 35).off(0, 0, -0.25F), Ease.OUT)
            .key(6, Pose.from(GUARD).body(-10, 8, 0).head(-12, 10, 0)
                    .ra(-30, 0, 20).la(-40, 0, -20).elbows(80, 80).knees(35, 35).off(0, 0, -0.2F))
            .key(12, GUARD)
            .done();

    /** Reação a golpe no corpo: curva-se para frente. */
    public static final Clip HIT_BODY = Clip.build("a_hit_body")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).body(38, 0, 0).head(20, 0, 0)
                    .ra(-60, -40, 0).la(-60, 40, 0).elbows(80, 80).knees(45, 45).off(0, 0, -0.4F), Ease.OUT)
            .key(7, Pose.from(GUARD).body(32, 0, 0).head(15, 0, 0)
                    .ra(-60, -40, 0).la(-60, 40, 0).elbows(80, 80).knees(42, 42).off(0, 0, -0.36F))
            .key(13, GUARD)
            .done();

    /** Cambaleio forte (desequilíbrio), recupera a guarda no fim. */
    public static final Clip STAGGER = Clip.build("a_stagger")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).root(20, 0, 8).body(-28, 25, 0).head(-25, 15, 5)
                    .ra(-10, 0, 50).la(-20, 0, -45).elbows(30, 40)
                    .rl(-25, 0, 8).knees(20, 40).off(0, 0, -0.45F), Ease.OUT)
            .key(6, Pose.from(GUARD).root(-10, 0, -6).body(-12, -10, 0).head(-5, -5, 0)
                    .ra(-25, 0, 35).la(-20, 0, -35).elbows(40, 40)
                    .ll(-30, 0, -8).knees(35, 50).off(0, 0, -0.5F))
            .key(10, Pose.from(GUARD).body(15, 0, 0).knees(50, 50).off(0, 0, -0.35F))
            .key(16, GUARD)
            .done();

    /** Esquiva lateral do ator. */
    public static final Clip DODGE = Clip.build("a_dodge")
            .key(0, GUARD)
            .key(3, Pose.from(GUARD).root(10, 0, 18).body(12, -5, 12).knees(55, 45).off(0.4F, 0, 0), Ease.OUT)
            .key(5, Pose.from(GUARD).root(10, 0, 16).body(12, -5, 10).knees(52, 42).off(0.38F, 0, 0))
            .key(9, GUARD)
            .done();

    /** Deitado de costas, pernas meio dobradas, braços abertos. */
    private static final Pose LYING_BACK = new Pose()
            .head(-10, 15, 0)
            .ra(-150, 0, 35).la(-150, 0, -30).elbows(40, 20)
            .rl(-10, 0, 10).ll(-25, 0, -8).knees(20, 40)
            .root(0, -90, 0)
            .off(0, 0.14F, -0.65F);

    /** Queda de costas. Termina deitado e permanece assim. */
    public static final Clip FALL_BACK = Clip.build("a_fall_back")
            .key(0, GUARD)
            .key(3, Pose.from(GUARD).root(0, -20, 0).body(-30, 0, 0).head(-30, 0, 0)
                    .ra(-120, 0, 40).la(-120, 0, -40).elbows(30, 30).knees(30, 30).off(0, 0.05F, -0.3F), Ease.OUT)
            .key(9, LYING_BACK, Ease.IN)
            .key(11, Pose.from(LYING_BACK).off(0, 0.2F, -0.67F))
            .key(13, LYING_BACK)
            .done();

    /** Deitado de bruços. */
    private static final Pose LYING_FRONT = new Pose()
            .head(-35, 25, 0)
            .ra(-160, 0, 30).la(-140, 0, -35).elbows(50, 70)
            .rl(0, 0, 6).ll(0, 0, -10).knees(10, 30)
            .root(85, 90, 0)
            .off(0.3F, 0.14F, -0.35F);

    /** Queda de bruços (após cotovelada/joelhada). */
    public static final Clip FALL_FORWARD = Clip.build("a_fall_forward")
            .key(0, GUARD)
            .key(3, Pose.from(GUARD).root(40, 25, 0).body(35, 0, 0).head(20, 0, 0)
                    .ra(-50, -40, 0).la(-50, 40, 0).elbows(80, 80).knees(60, 60).off(0, 0, -0.1F), Ease.OUT)
            .key(9, LYING_FRONT, Ease.IN)
            .key(11, Pose.from(LYING_FRONT).off(0.3F, 0.19F, -0.35F))
            .key(13, LYING_FRONT)
            .done();

    private static final Pose LYING_SPUN = Pose.from(LYING_BACK).root(430, -90, 0).off(0.3F, 0.14F, -0.75F)
            .head(0, 30, 0).rl(-5, 0, 20).ll(-30, 0, -3).knees(15, 60);

    /** Lançado girando (após chute giratório). */
    public static final Clip FALL_SPIN = Clip.build("a_fall_spin")
            .key(0, GUARD)
            .key(4, Pose.from(GUARD).root(200, -30, 15).body(-20, 20, 0).head(-20, 0, 0)
                    .ra(-100, 0, 70).la(-100, 0, -70).elbows(20, 20)
                    .knees(50, 20).off(0.1F, 0.35F, -0.5F), Ease.OUT)
            .key(10, LYING_SPUN, Ease.IN)
            .key(12, Pose.from(LYING_SPUN).off(0.3F, 0.2F, -0.77F))
            .key(14, LYING_SPUN)
            .done();

    // ------------------------------------------------------------ combo aéreo

    /** Pose no ar, atordoado: corpo arqueado para trás, braços e pernas soltos. */
    private static final Pose AIRBORNE = new Pose()
            .root(0, -18, 0).pivot(1.0F)
            .body(-15, 10, 0).head(-35, 15, 0)
            .ra(-30, 0, 55).la(-40, 0, -50).elbows(40, 55)
            .rl(15, 0, 10).ll(-20, 0, -8).knees(35, 55)
            .off(0, 2.15F, 0);

    /** Uppercut no queixo: o adversário sobe reto. Termina perto do ápice (~2.2 blocos). */
    public static final Clip LAUNCH_UP = Clip.build("a_launch_up")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).root(0, -10, 0).pivot(1.0F).body(-25, 5, 0).head(-45, 10, 0)
                    .ra(-20, 0, 40).la(-30, 0, -35).elbows(50, 60).knees(10, 15).off(0, 0.45F, 0), Ease.OUT)
            .key(8, Pose.from(AIRBORNE).off(0, 1.95F, 0), Ease.OUT)
            .key(14, AIRBORNE, Ease.SMOOTH)
            .done();

    /** Flutua no ápice (segurança caso o golpe seguinte demore). */
    public static final Clip AIR_HOVER = Clip.build("a_air_hover")
            .key(0, AIRBORNE)
            .key(10, Pose.from(AIRBORNE).root(0, -22, 0).off(0, 2.2F, 0).knees(45, 50))
            .key(20, AIRBORNE)
            .loop()
            .done();

    private static final Pose LANDED_FAR = Pose.from(LYING_BACK).root(-25, -90, 0).off(0, 0.14F, -0.4F);

    /** Chute aéreo: arremessado para longe girando, cai e quica. A distância vem da coreografia. */
    public static final Clip FLY_AWAY = Clip.build("a_fly_away")
            .key(0, AIRBORNE)
            .key(2, Pose.from(AIRBORNE).root(10, -45, 25).body(-30, 30, 0).head(-40, 30, 0)
                    .ra(-150, 0, 70).la(-150, 0, -70).elbows(10, 10).knees(10, 20)
                    .off(0, 2.3F, 0), Ease.OUT)
            .key(7, Pose.from(AIRBORNE).root(-10, -80, -40).body(-20, 20, 0)
                    .ra(-160, 0, 60).la(-140, 0, -70).elbows(20, 30).knees(20, 40)
                    .off(0, 1.3F, -0.2F))
            .key(11, LANDED_FAR, Ease.IN)
            .key(13, Pose.from(LANDED_FAR).off(0, 0.4F, -0.5F).knees(40, 60))
            .key(15, LANDED_FAR, Ease.IN)
            .key(16, Pose.from(LANDED_FAR).off(0, 0.2F, -0.45F))
            .key(18, LANDED_FAR)
            .done();

    // ------------------------------------------------------- reações humilhantes

    /** Atordoado de costas para o jogador (após o tapa). */
    private static final Pose DAZED = Pose.from(GUARD).root(185, 0, 6).body(20, 10, 8).head(15, 25, 10)
            .ra(10, 0, 15).la(5, 0, -20).elbows(20, 15).knees(30, 15).off(0, 0, -0.3F);

    /** Tapa: a cabeça vira e o corpo gira de costas, cambaleando. */
    public static final Clip HIT_SPIN = Clip.build("a_hit_spin")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).root(70, 0, 10).body(-10, 30, 0).head(-15, 70, 15)
                    .ra(-40, 0, 50).la(-30, 0, -40).elbows(40, 30).off(0, 0, -0.15F), Ease.OUT)
            .key(6, Pose.from(DAZED).root(160, 0, 12).off(0, 0, -0.35F))
            .key(10, DAZED)
            .done();

    public static final Clip DAZED_AWAY = Clip.build("a_dazed_away")
            .key(0, DAZED)
            .key(10, Pose.from(DAZED).root(178, 0, -4).head(18, 20, -6))
            .key(20, DAZED)
            .loop()
            .done();

    private static final Pose LYING_FACE_AWAY = new Pose()
            .head(-35, 20, 0)
            .ra(-165, 0, 25).la(-150, 0, -30).elbows(40, 60)
            .rl(0, 0, 6).ll(0, 0, -8).knees(15, 35)
            .root(180, 90, 0)
            .off(0, 0.14F, -0.5F);

    /** Chute nas costas: cai de cara no chão, longe do jogador. */
    public static final Clip FALL_FACE_AWAY = Clip.build("a_fall_face_away")
            .key(0, DAZED)
            .key(2, Pose.from(DAZED).root(180, 30, 0).body(-25, 0, 0).head(-30, 0, 0)
                    .ra(-60, 0, 40).la(-60, 0, -40).elbows(10, 10).knees(10, 30).off(0, 0.1F, -0.45F), Ease.OUT)
            .key(8, LYING_FACE_AWAY, Ease.IN)
            .key(10, Pose.from(LYING_FACE_AWAY).off(0, 0.2F, -0.55F))
            .key(12, LYING_FACE_AWAY)
            .done();

    /** Erguido pela gola: pés fora do chão, mãos no braço do jogador. */
    private static final Pose HANGING = new Pose()
            .body(-6, 0, 0).head(-20, 0, 0)
            .ra(-125, -25, 0).la(-125, 25, 0).elbows(70, 70)
            .rl(8, 0, 4).ll(-6, 0, -4).knees(20, 30)
            .off(0, 0.45F, 0);

    public static final Clip LIFTED = Clip.build("a_lifted")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).body(-10, 0, 0).head(-25, 0, 0)
                    .ra(-110, -25, 0).la(-110, 25, 0).elbows(60, 60), Ease.OUT)
            .key(6, HANGING, Ease.OUT)
            .key(8, Pose.from(HANGING).rl(-20, 0, 4).ll(15, 0, -4))
            .key(10, HANGING)
            .done();

    public static final Clip HELD = Clip.build("a_held")
            .key(0, HANGING)
            .key(5, Pose.from(HANGING).rl(-15, 0, 4).ll(10, 0, -4).knees(35, 20))
            .key(10, HANGING)
            .loop()
            .done();

    /** Arremessado: voa em arco, gira e cai de costas longe. A distância vem da coreografia. */
    public static final Clip THROWN = Clip.build("a_thrown")
            .key(0, HANGING)
            .key(3, Pose.from(HANGING).root(0, -50, 15).pivot(1.0F).body(-20, 10, 0)
                    .ra(-160, 0, 60).la(-150, 0, -60).elbows(10, 20).knees(10, 40).off(0, 1.05F, 0), Ease.OUT)
            .key(7, Pose.from(HANGING).root(-20, -110, 40).pivot(1.0F).body(-10, 20, 0)
                    .ra(-160, 0, 60).la(-150, 0, -60).elbows(20, 20).knees(30, 50).off(0, 0.95F, 0))
            .key(11, LANDED_FAR, Ease.IN)
            .key(13, Pose.from(LANDED_FAR).off(0, 0.35F, -0.5F).knees(40, 60))
            .key(15, LANDED_FAR, Ease.IN)
            .key(16, Pose.from(LANDED_FAR).off(0, 0.2F, -0.45F))
            .key(18, LANDED_FAR)
            .done();

    private static final Pose LYING_SWEPT = Pose.from(LYING_BACK).off(0, 0.14F, -0.2F).knees(30, 50);

    /** Rasteira: as pernas saem do chão e ele cai de costas no lugar. */
    public static final Clip SWEPT = Clip.build("a_swept")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).root(0, -55, 0).pivot(0.9F).body(-15, 0, 0).head(-20, 0, 0)
                    .ra(-120, 0, 50).la(-120, 0, -50).elbows(20, 20)
                    .rl(-60, 0, 5).ll(-50, 0, -5).knees(10, 20).off(0, 0.55F, 0), Ease.OUT)
            .key(6, LYING_SWEPT, Ease.IN)
            .key(8, Pose.from(LYING_SWEPT).off(0, 0.25F, -0.22F))
            .key(10, LYING_SWEPT)
            .done();

    public static final Clip LYING_HOLD = Clip.build("a_lying_hold")
            .key(0, LYING_SWEPT)
            .key(10, Pose.from(LYING_SWEPT).head(-5, 25, 0).knees(35, 45))
            .key(20, LYING_SWEPT)
            .loop()
            .done();

    /** Levantado do chão pela gola até ficar pendurado. */
    public static final Clip PICKED_UP = Clip.build("a_picked_up")
            .key(0, LYING_SWEPT)
            .key(4, Pose.from(HANGING).root(0, -45, 0).pivot(0.2F).off(0, 0.25F, -0.1F).knees(40, 50))
            .key(8, HANGING, Ease.OUT)
            .key(10, Pose.from(HANGING).rl(-20, 0, 4).ll(15, 0, -4))
            .key(12, HANGING)
            .done();

    /** Recua assustado vendo o jogador vir correndo. */
    public static final Clip FLINCH_BACK = Clip.build("a_flinch_back")
            .key(0, GUARD)
            .key(3, Pose.from(GUARD).body(-12, -5, 0).head(5, -5, 0)
                    .ra(-70, -30, 0).la(-75, 30, 0).elbows(110, 110)
                    .rl(25, 0, 5).ll(-5, 0, -5).knees(30, 15), Ease.OUT)
            .key(7, Pose.from(GUARD).body(5, -5, 0).ra(-60, -30, 0).la(-65, 30, 0).elbows(115, 115)
                    .rl(-10, 0, 5).ll(20, 0, -5).knees(20, 40))
            .key(11, GUARD)
            .done();

    /** Clipe que um ator toca quando o atual termina (sem ter sido derrotado). */
    public static Clip followUp(Clip finished) {
        if (finished == LAUNCH_UP || finished == AIR_HOVER) return AIR_HOVER;
        if (finished == HIT_SPIN || finished == DAZED_AWAY) return DAZED_AWAY;
        if (finished == LIFTED || finished == PICKED_UP || finished == HELD) return HELD;
        if (finished == SWEPT || finished == LYING_HOLD) return LYING_HOLD;
        return GUARD_IDLE;
    }
}
