package com.madarataijutsu.choreo;

import com.madarataijutsu.anim.Clip;
import com.madarataijutsu.anim.Ease;
import com.madarataijutsu.anim.Pose;

/**
 * Animações dos adversários virtuais. O "frente" do ator é sempre a direção do
 * jogador. Quedas terminam deitadas e são mantidas (não fazem loop).
 */
public final class ActorClips {

    private ActorClips() {
    }

    public static final Pose GUARD = new Pose()
            .ra(-50, -25, 10)
            .la(-55, 25, -10)
            .rl(10, 0, 5)
            .ll(-10, 0, -5)
            .root(0, 5, 0);

    public static final Clip GUARD_IDLE = Clip.build("a_guard_idle")
            .key(0, GUARD)
            .key(10, Pose.from(GUARD).ra(-46, -25, 12).la(-51, 25, -12).off(0, -0.015F, 0))
            .key(20, GUARD)
            .loop()
            .done();

    /** Aproximação caminhando (a distância é animada pela coreografia). */
    public static final Clip ADVANCE = Clip.build("a_advance")
            .key(0, GUARD)
            .key(3, Pose.from(GUARD).rl(-30, 0, 3).ll(25, 0, -3).root(0, 8, 0))
            .key(6, Pose.from(GUARD).rl(25, 0, 3).ll(-30, 0, -3).root(0, 8, 0))
            .key(9, Pose.from(GUARD).rl(-30, 0, 3).ll(25, 0, -3).root(0, 8, 0))
            .key(12, GUARD)
            .done();

    /** Soco de direita contra o jogador. Golpe chega: tick 6. */
    public static final Clip PUNCH = Clip.build("a_punch")
            .key(0, GUARD)
            .key(3, Pose.from(GUARD).ra(-40, 15, 25).body(0, 15, 0).root(8, 5, 0))
            .key(6, Pose.from(GUARD).ra(-92, -5, 0).body(0, -25, 0).root(0, 10, 0).off(0, 0, 0.3F), Ease.OUT)
            .key(8, Pose.from(GUARD).ra(-90, -5, 0).body(0, -22, 0).root(0, 10, 0).off(0, 0, 0.28F))
            .key(13, GUARD)
            .done();

    /** Chute frontal contra o jogador. Golpe chega: tick 6. */
    public static final Clip KICK = Clip.build("a_kick")
            .key(0, GUARD)
            .key(3, Pose.from(GUARD).rl(-45, 0, 0).root(0, -4, 0))
            .key(6, Pose.from(GUARD).rl(-90, 0, 0).ll(8, 0, 0).root(0, -10, 0).off(0, 0.04F, 0.22F), Ease.OUT)
            .key(8, Pose.from(GUARD).rl(-86, 0, 0).ll(8, 0, 0).root(0, -9, 0).off(0, 0.04F, 0.2F))
            .key(13, GUARD)
            .done();

    /** Bloqueio alto; recua levemente com o impacto. */
    public static final Clip BLOCK = Clip.build("a_block")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).ra(-112, -45, 0).la(-112, 45, 0).head(10, 0, 0).root(0, 8, 0), Ease.OUT)
            .key(4, Pose.from(GUARD).ra(-110, -45, 0).la(-110, 45, 0).head(10, 0, 0).root(0, 2, 0)
                    .off(0, 0, -0.15F))
            .key(9, GUARD)
            .done();

    /** Reação a golpe no rosto. */
    public static final Clip HIT = Clip.build("a_hit")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).head(-25, 15, 0).root(0, -15, 0).off(0, 0, -0.25F)
                    .ra(-20, 0, 25).la(-20, 0, -25), Ease.OUT)
            .key(6, Pose.from(GUARD).head(-10, 8, 0).root(0, -8, 0).off(0, 0, -0.2F)
                    .ra(-30, 0, 15).la(-30, 0, -15))
            .key(12, GUARD)
            .done();

    /** Reação a golpe no corpo (curva-se para frente). */
    public static final Clip HIT_BODY = Clip.build("a_hit_body")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).head(20, 0, 0).root(0, 25, 0).off(0, -0.02F, -0.2F)
                    .ra(-40, -40, 0).la(-40, 40, 0), Ease.OUT)
            .key(7, Pose.from(GUARD).head(15, 0, 0).root(0, 20, 0).off(0, -0.02F, -0.18F)
                    .ra(-40, -40, 0).la(-40, 40, 0))
            .key(13, GUARD)
            .done();

    /** Cambaleio forte (desequilíbrio). */
    public static final Clip STAGGER = Clip.build("a_stagger")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).root(15, -20, 8).head(-20, 10, 5).off(0, 0, -0.45F)
                    .ra(-10, 0, 40).la(-15, 0, -35).rl(-20, 0, 8), Ease.OUT)
            .key(6, Pose.from(GUARD).root(-10, -12, -6).head(-5, -5, 0).off(0, 0, -0.5F)
                    .ra(-25, 0, 30).la(-20, 0, -30).ll(-25, 0, -8))
            .key(10, Pose.from(GUARD).root(4, -5, 0).off(0, 0, -0.35F))
            .key(16, GUARD)
            .done();

    /** Esquiva do ator (usada em trocas de golpes). */
    public static final Clip DODGE = Clip.build("a_dodge")
            .key(0, GUARD)
            .key(3, Pose.from(GUARD).root(0, 5, 20).off(0.4F, 0, 0), Ease.OUT)
            .key(5, Pose.from(GUARD).root(0, 5, 18).off(0.38F, 0, 0))
            .key(9, GUARD)
            .done();

    private static final Pose LYING_BACK = new Pose()
            .ra(-160, 0, 20).la(-160, 0, -20)
            .rl(0, 0, 8).ll(0, 0, -8)
            .root(0, -90, 0)
            .off(0, 0.12F, -0.6F);

    /** Queda de costas. Termina deitado e permanece assim. */
    public static final Clip FALL_BACK = Clip.build("a_fall_back")
            .key(0, GUARD)
            .key(3, Pose.from(GUARD).root(0, -25, 0).head(-25, 0, 0).off(0, 0, -0.3F)
                    .ra(-120, 0, 30).la(-120, 0, -30), Ease.OUT)
            .key(9, LYING_BACK, Ease.IN)
            .key(11, Pose.from(LYING_BACK).off(0, 0.17F, -0.62F))
            .key(13, LYING_BACK)
            .done();

    private static final Pose LYING_FRONT = new Pose()
            .head(-30, 20, 0)
            .ra(-170, 0, 25).la(-170, 0, -25)
            .rl(0, 0, 6).ll(0, 0, -10)
            .root(15, 90, 0)
            .off(0, 0.12F, 0.15F);

    /** Queda de bruços. */
    public static final Clip FALL_FORWARD = Clip.build("a_fall_forward")
            .key(0, GUARD)
            .key(3, Pose.from(GUARD).root(0, 30, 0).head(20, 0, 0).ra(-30, -40, 0).la(-30, 40, 0)
                    .off(0, -0.03F, -0.1F), Ease.OUT)
            .key(9, LYING_FRONT, Ease.IN)
            .key(11, Pose.from(LYING_FRONT).off(0, 0.16F, 0.15F))
            .key(13, LYING_FRONT)
            .done();

    private static final Pose LYING_SPUN = Pose.from(LYING_BACK).root(200, -90, 0).off(0.2F, 0.12F, -0.8F)
            .head(0, 30, 0).rl(0, 0, 20).ll(0, 0, -3);

    /** Lançado girando (após chute giratório). */
    public static final Clip FALL_SPIN = Clip.build("a_fall_spin")
            .key(0, GUARD)
            .key(4, Pose.from(GUARD).root(120, -30, 15).off(0.1F, 0.3F, -0.5F)
                    .ra(-100, 0, 60).la(-100, 0, -60), Ease.OUT)
            .key(10, LYING_SPUN, Ease.IN)
            .key(12, Pose.from(LYING_SPUN).off(0.2F, 0.18F, -0.82F))
            .key(14, LYING_SPUN)
            .done();
}
