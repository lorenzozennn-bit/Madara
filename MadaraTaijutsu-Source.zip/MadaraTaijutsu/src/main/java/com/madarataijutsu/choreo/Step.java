package com.madarataijutsu.choreo;

import com.madarataijutsu.anim.Clip;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Uma etapa da coreografia, disparada por um clique do jogador. */
public final class Step {

    public final int duration;
    public final Clip playerClip;
    /** Índice do adversário que o jogador deve encarar, ou -1 para manter. */
    public final int face;
    public final int turnTicks;
    private final List<ActorAction> actions = new ArrayList<ActorAction>();

    public Step(int duration, Clip playerClip, int face) {
        this(duration, playerClip, face, 4);
    }

    public Step(int duration, Clip playerClip, int face, int turnTicks) {
        if (duration <= 0) throw new IllegalArgumentException("duração inválida");
        this.duration = duration;
        this.playerClip = playerClip;
        this.face = face;
        this.turnTicks = turnTicks;
    }

    public List<ActorAction> actions() {
        return Collections.unmodifiableList(actions);
    }

    /** Adversário executa um clipe. */
    public Step act(int actor, Clip clip, int delay) {
        actions.add(new ActorAction(actor, clip, delay, Float.NaN, 0, ImpactType.NONE, false));
        return this;
    }

    /** Adversário executa um clipe com efeito de impacto. */
    public Step act(int actor, Clip clip, int delay, ImpactType impact) {
        actions.add(new ActorAction(actor, clip, delay, Float.NaN, 0, impact, false));
        return this;
    }

    /** Adversário é derrotado: toca a queda e permanece caído. */
    public Step defeat(int actor, Clip fall, int delay, ImpactType impact, float knockRadius) {
        actions.add(new ActorAction(actor, fall, delay, knockRadius, 8, impact, true));
        return this;
    }

    /** Adversário muda de distância (aproximação ou recuo). */
    public Step move(int actor, float radius, int delay, int ticks) {
        actions.add(new ActorAction(actor, null, delay, radius, ticks, ImpactType.NONE, false));
        return this;
    }

    /** Efeito sem clipe (ex.: bloqueio do jogador, golpe no vazio). */
    public Step fx(int actor, ImpactType impact, int delay) {
        actions.add(new ActorAction(actor, null, delay, Float.NaN, 0, impact, false));
        return this;
    }

    /** Aproximação caminhando até a distância indicada. */
    public Step approach(int actor, float radius, int delay) {
        actions.add(new ActorAction(actor, ActorClips.ADVANCE, delay, radius, 12, ImpactType.NONE, false));
        return this;
    }
}
