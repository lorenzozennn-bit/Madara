package com.madarataijutsu.choreo;

/** Efeito audiovisual disparado no instante de uma ação. */
public enum ImpactType {
    /** Nenhum efeito. */
    NONE,
    /** Golpe do jogador acerta o adversário. */
    HIT,
    /** Golpe forte (som crítico + partículas). */
    HEAVY,
    /** Adversário bloqueia o golpe do jogador. */
    ACTOR_BLOCK,
    /** Jogador bloqueia o golpe do adversário. */
    PLAYER_BLOCK,
    /** Golpe passa no vazio (esquiva). */
    MISS
}
