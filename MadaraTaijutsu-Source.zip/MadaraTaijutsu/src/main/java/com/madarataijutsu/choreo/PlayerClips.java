package com.madarataijutsu.choreo;

import com.madarataijutsu.anim.Clip;
import com.madarataijutsu.anim.Ease;
import com.madarataijutsu.anim.Pose;

/**
 * Animações do jogador (terceira pessoa) com esqueleto articulado: cotovelos,
 * joelhos e cintura. Base: guarda com o lado esquerdo à frente, joelhos
 * flexionados, mãos na altura do queixo.
 *
 * Tempos em ticks (20 = 1 s). O frame de impacto de cada golpe está anotado;
 * as coreografias sincronizam as reações dos adversários nele.
 */
public final class PlayerClips {

    private PlayerClips() {
    }

    /**
     * Postura arrogante (sem guarda): corpo ereto e de perfil, queixo erguido,
     * braços relaxados ao lado do corpo — o adversário não merece guarda.
     */
    public static final Pose GUARD = new Pose()
            .root(-25, 0, 0)
            .body(-4, 12, 0)
            .head(-12, -14, 0)
            .la(6, 0, -7).ra(4, 0, 8)
            .elbows(14, 12)
            .ll(-12, 0, -4).rl(8, 0, 6)
            .knees(6, 10);

    private static final Pose GUARD_BREATH = Pose.from(GUARD)
            .body(-5, 12, 0).head(-13, -14, 0)
            .la(5, 0, -8)
            .knees(8, 12);

    public static final Clip GUARD_IDLE = Clip.build("p_guard_idle")
            .key(0, GUARD)
            .key(12, GUARD_BREATH)
            .key(24, GUARD)
            .loop()
            .done();

    /** Mão direita relaxada (enquanto a outra golpeia). */
    private static Pose rearHandGuard(Pose p) {
        return p.ra(6, 0, 8).elbows(14, p.get(Pose.L_ELBOW));
    }

    private static Pose leadHandGuard(Pose p) {
        return p.la(6, 0, -8).elbows(p.get(Pose.R_ELBOW), 12);
    }

    /** Jab de esquerda. Impacto: tick 2. */
    public static final Clip JAB_L = Clip.build("p_jab_l")
            .key(0, GUARD)
            .key(2, rearHandGuard(Pose.from(GUARD).root(-36, 0, 0).body(14, 32, 0).head(-4, -26, 0)
                    .la(-90, 6, 0).elbows(125, 0).off(0, 0, 0.15F).knees(28, 38)), Ease.OUT)
            .key(4, rearHandGuard(Pose.from(GUARD).root(-36, 0, 0).body(14, 30, 0).head(-4, -25, 0)
                    .la(-88, 6, 0).elbows(125, 5).off(0, 0, 0.14F).knees(28, 38)))
            .key(8, GUARD)
            .done();

    /** Direto de direita (giro do quadril). Impacto: tick 2. */
    public static final Clip CROSS_R = Clip.build("p_cross_r")
            .key(0, GUARD)
            .key(2, leadHandGuard(Pose.from(GUARD).root(-8, 0, 0).body(16, -22, 0).head(-4, 10, 0)
                    .ra(-90, -6, 0).elbows(0, 110).off(0, 0, 0.3F)
                    .rl(12, -25, 6).knees(15, 38)), Ease.OUT)
            .key(4, leadHandGuard(Pose.from(GUARD).root(-8, 0, 0).body(16, -20, 0).head(-4, 10, 0)
                    .ra(-88, -6, 0).elbows(5, 110).off(0, 0, 0.28F)
                    .rl(12, -25, 6).knees(15, 38)))
            .key(9, GUARD)
            .done();

    /** Gancho de esquerda (braço em 90°, giro do tronco). Impacto: tick 3. */
    public static final Clip HOOK_L = Clip.build("p_hook_l")
            .key(0, GUARD)
            .key(1, Pose.from(GUARD).body(10, 40, 0).la(-40, 10, -45).elbows(125, 95))
            .key(3, rearHandGuard(Pose.from(GUARD).root(-20, 0, 0).body(14, -45, 0).head(-4, 25, 0)
                    .la(-35, 0, -80).elbows(125, 90).off(0, 0, 0.3F).knees(30, 42)), Ease.OUT)
            .key(5, rearHandGuard(Pose.from(GUARD).root(-20, 0, 0).body(14, -48, 0).head(-4, 26, 0)
                    .la(-35, 0, -78).elbows(125, 90).off(0, 0, 0.29F).knees(30, 42)))
            .key(10, GUARD)
            .done();

    /** Gancho de direita. Impacto: tick 3. */
    public static final Clip HOOK_R = Clip.build("p_hook_r")
            .key(0, GUARD)
            .key(1, Pose.from(GUARD).body(10, -15, 0).ra(-20, -10, 60).elbows(95, 85))
            .key(3, leadHandGuard(Pose.from(GUARD).root(-5, 0, 0).body(14, 50, 0).head(-4, -45, 0)
                    .ra(-35, 0, 80).elbows(90, 110).off(0, 0, 0.32F).rl(10, -20, 6).knees(18, 40)), Ease.OUT)
            .key(5, leadHandGuard(Pose.from(GUARD).root(-5, 0, 0).body(14, 53, 0).head(-4, -47, 0)
                    .ra(-35, 0, 78).elbows(90, 110).off(0, 0, 0.31F).rl(10, -20, 6).knees(18, 40)))
            .key(10, GUARD)
            .done();

    /** Uppercut de direita saindo de baixo. Impacto: tick 3. */
    public static final Clip UPPERCUT_R = Clip.build("p_uppercut_r")
            .key(0, GUARD)
            .key(1, leadHandGuard(Pose.from(GUARD).root(-15, 0, 0).body(28, -15, 0).head(-20, 0, 0)
                    .ra(-5, 0, 15).elbows(110, 110).knees(65, 65).off(0, 0, 0.08F)))
            .key(3, leadHandGuard(Pose.from(GUARD).root(-8, 0, 0).body(2, -30, 0).head(-10, 20, 0)
                    .ra(-95, -15, 0).elbows(75, 110).knees(5, 15).rl(10, 0, 6)
                    .off(0, 0.1F, 0.3F)), Ease.OUT)
            .key(5, leadHandGuard(Pose.from(GUARD).root(-8, 0, 0).body(2, -28, 0).head(-10, 20, 0)
                    .ra(-100, -15, 0).elbows(70, 110).knees(8, 18).rl(10, 0, 6)
                    .off(0, 0.05F, 0.29F)))
            .key(11, GUARD)
            .done();

    /** Cotovelada horizontal de direita. Impacto: tick 2. */
    public static final Clip ELBOW_R = Clip.build("p_elbow_r")
            .key(0, GUARD)
            .key(2, leadHandGuard(Pose.from(GUARD).root(15, 0, 0).body(12, 70, 0).head(-4, -80, 0)
                    .ra(0, 0, 88).elbows(150, 110).off(0, 0, 0.3F).rl(10, -25, 6).knees(20, 40)), Ease.OUT)
            .key(4, leadHandGuard(Pose.from(GUARD).root(15, 0, 0).body(12, 72, 0).head(-4, -82, 0)
                    .ra(0, 0, 86).elbows(150, 110).off(0, 0, 0.29F).rl(10, -25, 6).knees(20, 40)))
            .key(9, GUARD)
            .done();

    /** Joelhada de direita puxando o oponente pela nuca. Impacto: tick 3. */
    public static final Clip KNEE_R = Clip.build("p_knee_r")
            .key(0, GUARD)
            .key(1, Pose.from(GUARD).body(12, 0, 0).la(-110, 10, 0).ra(-110, -10, 0).elbows(30, 30)
                    .off(0, 0, 0.1F))
            .key(3, Pose.from(GUARD).root(-15, 0, 0).body(25, 0, 0).head(10, -10, 0)
                    .la(-75, 15, 0).ra(-75, -15, 0).elbows(75, 75)
                    .rl(-105, 0, 0).ll(0, 0, -4).knees(125, 10).off(0, 0.04F, 0.2F), Ease.OUT)
            .key(5, Pose.from(GUARD).root(-15, 0, 0).body(22, 0, 0).head(8, -10, 0)
                    .la(-75, 15, 0).ra(-75, -15, 0).elbows(75, 75)
                    .rl(-100, 0, 0).ll(0, 0, -4).knees(120, 12).off(0, 0.03F, 0.18F))
            .key(10, GUARD)
            .done();

    /** Chute frontal de direita (engatilha e estica). Impacto: tick 3. */
    public static final Clip FRONT_KICK_R = Clip.build("p_front_kick_r")
            .key(0, GUARD)
            .key(1, Pose.from(GUARD).root(-15, 0, 0).body(0, 10, 0).rl(-85, 0, 0).ll(-5, 0, -4).knees(110, 22))
            .key(3, Pose.from(GUARD).root(-15, 0, 0).body(-14, 10, 0).head(10, -10, 0)
                    .rl(-92, 0, 0).ll(0, 0, -4).knees(0, 18).off(0, 0, 0.22F), Ease.OUT)
            .key(5, Pose.from(GUARD).root(-15, 0, 0).body(-12, 10, 0).head(10, -10, 0)
                    .rl(-90, 0, 0).ll(0, 0, -4).knees(5, 18).off(0, 0, 0.21F))
            .key(7, Pose.from(GUARD).root(-15, 0, 0).body(0, 10, 0).rl(-80, 0, 0).ll(-5, 0, -4).knees(105, 22)
                    .off(0, 0, 0.1F))
            .key(10, GUARD)
            .done();

    /** Chute lateral de direita (corpo de perfil, tronco inclinado para longe). Impacto: tick 4. */
    public static final Clip SIDE_KICK_R = Clip.build("p_side_kick_r")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).root(75, 0, 0).body(5, 0, 15).head(0, 55, -10)
                    .rl(-30, 0, 55).ll(0, 0, -4).knees(120, 25))
            .key(4, Pose.from(GUARD).root(88, 0, 0).body(0, 0, 32).head(0, 60, -25)
                    .la(-40, 20, -40).ra(-20, -25, 25).elbows(110, 90)
                    .rl(0, 0, 88).ll(0, 0, -4).knees(0, 22).off(0, 0.04F, 0.18F), Ease.OUT)
            .key(7, Pose.from(GUARD).root(88, 0, 0).body(0, 0, 30).head(0, 60, -24)
                    .la(-40, 20, -40).ra(-20, -25, 25).elbows(110, 90)
                    .rl(0, 0, 85).ll(0, 0, -4).knees(5, 22).off(0, 0.04F, 0.17F))
            .key(9, Pose.from(GUARD).root(75, 0, 0).body(5, 0, 15).head(0, 55, -10)
                    .rl(-30, 0, 55).ll(0, 0, -4).knees(115, 25))
            .key(13, GUARD)
            .done();

    /** Chute giratório (360°) com a perna direita. Impacto: tick 6. */
    public static final Clip SPIN_KICK = Clip.build("p_spin_kick")
            .key(0, GUARD)
            .key(3, Pose.from(GUARD).yaw(-150).body(5, 0, 10).head(0, 0, 0)
                    .rl(-30, 0, 50).ll(0, 0, -4).knees(100, 30).off(0, 0.05F, 0.05F))
            .key(6, Pose.from(GUARD).root(-272, 0, 0).body(0, 0, 32).head(0, 62, -25)
                    .la(-30, 20, -50).ra(-20, -20, 30).elbows(110, 90)
                    .rl(0, 0, 88).ll(0, 0, -4).knees(0, 25).off(0, 0.08F, 0.2F), Ease.OUT)
            .key(8, Pose.from(GUARD).root(-300, 0, 0).body(0, 0, 26).head(0, 55, -20)
                    .la(-30, 20, -50).ra(-20, -20, 30).elbows(110, 90)
                    .rl(0, 0, 75).ll(0, 0, -4).knees(30, 25).off(0, 0.06F, 0.2F))
            .key(13, Pose.from(GUARD).yaw(-390))
            .done();

    /** Chute giratório saltado (acrobático). Impacto: tick 8. */
    public static final Clip JUMP_SPIN_KICK = Clip.build("p_jump_spin_kick")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).body(20, 15, 0).la(-20, 0, -20).ra(-20, 0, 20).elbows(40, 40).knees(70, 70))
            .key(5, Pose.from(GUARD).yaw(-160).body(0, 0, 10).head(0, 0, 0)
                    .la(-150, 0, -30).ra(-150, 0, 30).elbows(30, 30)
                    .rl(-60, 0, 30).ll(-70, 0, -10).knees(110, 120).off(0, 0.8F, 0.15F), Ease.OUT)
            .key(8, Pose.from(GUARD).root(-272, 0, 0).body(0, 0, 32).head(0, 62, -25)
                    .la(-30, 20, -60).ra(-20, -20, 40).elbows(110, 90)
                    .rl(0, 0, 90).ll(-60, 0, -10).knees(0, 110).off(0, 0.85F, 0.3F), Ease.OUT)
            .key(11, Pose.from(GUARD).root(-340, 0, 0).body(5, 0, 10).head(0, 20, 0)
                    .rl(-40, 0, 20).ll(-40, 0, -10).knees(80, 80).off(0, 0.35F, 0.3F))
            .key(13, Pose.from(GUARD).yaw(-390).knees(70, 70).off(0, 0, 0.25F), Ease.IN)
            .key(17, Pose.from(GUARD).yaw(-390))
            .done();

    /** Esquiva lateral para a esquerda (desce e inclina). */
    public static final Clip DODGE_LEFT = Clip.build("p_dodge_left")
            .key(0, GUARD)
            .key(3, Pose.from(GUARD).root(-30, 0, -18).body(15, 15, -15).head(0, -12, 15)
                    .knees(60, 50).off(-0.5F, 0, -0.05F), Ease.OUT)
            .key(7, Pose.from(GUARD).root(-30, 0, -16).body(15, 15, -13).head(0, -12, 13)
                    .knees(58, 48).off(-0.48F, 0, -0.05F))
            .key(11, GUARD)
            .done();

    /** Esquiva lateral para a direita. */
    public static final Clip DODGE_RIGHT = Clip.build("p_dodge_right")
            .key(0, GUARD)
            .key(3, Pose.from(GUARD).root(-30, 0, 18).body(15, 15, 15).head(0, -12, -15)
                    .knees(50, 60).off(0.5F, 0, -0.05F), Ease.OUT)
            .key(7, Pose.from(GUARD).root(-30, 0, 16).body(15, 15, 13).head(0, -12, -13)
                    .knees(48, 58).off(0.48F, 0, -0.05F))
            .key(11, GUARD)
            .done();

    /** Esquiva inclinando o tronco para trás (joelhos dobrados). */
    public static final Clip LEAN_BACK = Clip.build("p_lean_back")
            .key(0, GUARD)
            .key(3, Pose.from(GUARD).body(-40, 10, 0).head(25, -10, 0)
                    .la(-30, 0, -45).ra(-30, 0, 45).elbows(40, 40)
                    .ll(-35, 0, -4).rl(10, 0, 6).knees(55, 70).off(0, 0, -0.1F), Ease.OUT)
            .key(7, Pose.from(GUARD).body(-38, 10, 0).head(23, -10, 0)
                    .la(-30, 0, -45).ra(-30, 0, 45).elbows(40, 40)
                    .ll(-35, 0, -4).rl(10, 0, 6).knees(55, 70).off(0, 0, -0.1F))
            .key(11, GUARD)
            .done();

    /** Bloqueio alto com os antebraços na frente do rosto. Contato: tick 2. */
    public static final Clip BLOCK = Clip.build("p_block")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).root(-15, 0, 0).body(15, 0, 0).head(12, -15, 0)
                    .la(-80, 25, 0).ra(-80, -25, 0).elbows(105, 105).knees(40, 40), Ease.OUT)
            .key(3, Pose.from(GUARD).root(-15, 0, 0).body(10, 0, 0).head(12, -15, 0)
                    .la(-80, 25, 0).ra(-80, -25, 0).elbows(105, 105).knees(45, 45).off(0, 0, -0.14F))
            .key(6, Pose.from(GUARD).root(-15, 0, 0).body(12, 0, 0).head(12, -15, 0)
                    .la(-80, 25, 0).ra(-80, -25, 0).elbows(105, 105).knees(42, 42).off(0, 0, -0.12F))
            .key(10, GUARD)
            .done();

    /** Mortal para trás (esquiva acrobática). */
    public static final Clip BACKFLIP = Clip.build("p_backflip")
            .key(0, GUARD)
            .key(3, Pose.from(GUARD).body(15, 0, 0).head(0, 0, 0).la(-170, 0, -10).ra(-170, 0, 10).elbows(10, 10)
                    .ll(0, 0, -4).rl(0, 0, 4).knees(75, 75))
            .key(7, Pose.from(GUARD).root(-30, -180, 0).pivot(0.7F).body(20, 0, 0).head(10, 0, 0)
                    .la(-60, 0, -15).ra(-60, 0, 15).elbows(60, 60)
                    .ll(-110, 0, -4).rl(-110, 0, 4).knees(140, 140).off(0, 0.95F, -0.35F), Ease.LINEAR)
            .key(11, Pose.from(GUARD).root(-30, -340, 0).pivot(0.7F).knees(80, 80).off(0, 0.15F, -0.6F),
                    Ease.LINEAR)
            .key(13, Pose.from(GUARD).root(-30, -360, 0).pivot(0.7F).knees(70, 70).off(0, 0, -0.6F))
            .key(17, Pose.from(GUARD).root(-30, -360, 0).pivot(0.7F))
            .done();

    /** Postura de vitória: ereta, queixo erguido, mão direita estendida à frente. */
    public static final Pose VICTORY_POSE = new Pose()
            .head(-10, 0, 0)
            .ra(-62, -8, 4).elbows(25, 10)
            .la(4, 0, -6)
            .rl(0, 0, 3).ll(0, 0, -3)
            .knees(3, 3);

    public static final Clip VICTORY = Clip.build("p_victory")
            .key(0, GUARD)
            .key(5, Pose.from(GUARD).body(0, 0, 0).knees(15, 15).off(0, 0, -0.1F))
            .key(14, VICTORY_POSE)
            .key(40, Pose.from(VICTORY_POSE).ra(-64, -8, 4))
            .done();

    /**
     * Salto com chute giratório no ar (combo do 1v1): agacha, sobe até ~2 blocos,
     * gira 360° e acerta com a perna direita estendida. Impacto: tick 8.
     */
    public static final Clip AIR_KICK = Clip.build("p_air_kick")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).body(25, 15, 0).head(-25, -15, 0)
                    .la(10, 0, -25).ra(10, 0, 25).elbows(20, 20).knees(85, 85).off(0, 0, 0.05F), Ease.OUT)
            .key(5, Pose.from(GUARD).yaw(-130).body(5, 0, 0).head(-30, 0, 0)
                    .la(-160, 0, -25).ra(-160, 0, 25).elbows(20, 20)
                    .rl(-40, 0, 20).ll(-80, 0, -10).knees(100, 120).off(0, 1.7F, 0.1F), Ease.OUT)
            .key(8, Pose.from(GUARD).root(-272, 0, 0).body(0, 0, 32).head(-20, 62, -25)
                    .la(-30, 20, -60).ra(-20, -20, 40).elbows(110, 90)
                    .rl(0, 0, 92).ll(-70, 0, -10).knees(0, 115).off(0, 2.15F, 0.25F), Ease.OUT)
            .key(10, Pose.from(GUARD).root(-305, 0, 0).body(0, 0, 25).head(-10, 50, -20)
                    .la(-30, 20, -60).ra(-20, -20, 40).elbows(110, 90)
                    .rl(0, 0, 80).ll(-70, 0, -10).knees(20, 115).off(0, 2.05F, 0.25F))
            .key(14, Pose.from(GUARD).root(-370, 0, 0).body(5, 5, 0).head(-5, -10, 0)
                    .la(-90, 0, -40).ra(-90, 0, 40).elbows(30, 30)
                    .rl(-50, 0, 10).ll(-60, 0, -10).knees(90, 90).off(0, 0.7F, 0.2F), Ease.IN)
            .key(16, Pose.from(GUARD).yaw(-390).body(30, 15, 0).knees(95, 95).off(0, 0, 0.15F), Ease.IN)
            .key(21, Pose.from(GUARD).yaw(-390))
            .done();

    // ------------------------------------------------------- golpes humilhantes

    /** Desvio mínimo: só inclina a cabeça e o tronco, mãos continuam baixas. */
    public static final Clip SLIP = Clip.build("p_slip")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).root(-25, 0, -10).body(-2, 12, -12).head(-14, -18, -18)
                    .off(-0.22F, 0, -0.04F), Ease.OUT)
            .key(7, Pose.from(GUARD).root(-25, 0, -9).body(-2, 12, -11).head(-14, -18, -16)
                    .off(-0.2F, 0, -0.04F))
            .key(10, GUARD)
            .done();

    /** Tapa com as costas da mão esquerda. Impacto: tick 3. */
    public static final Clip BACKHAND_L = Clip.build("p_backhand_l")
            .key(0, GUARD)
            .key(2, rearHandGuard(Pose.from(GUARD).root(-15, 0, 0).body(-2, 30, 0)
                    .la(-85, 75, 0).elbows(14, 70)))
            .key(4, rearHandGuard(Pose.from(GUARD).root(-25, 0, 0).body(-2, -25, 0).head(-12, 5, 0)
                    .la(-88, -45, 0).elbows(14, 8).off(0, 0, 0.12F)), Ease.OUT)
            .key(7, rearHandGuard(Pose.from(GUARD).root(-25, 0, 0).body(-3, -28, 0).head(-12, 5, 0)
                    .la(-70, -60, 0).elbows(14, 10).off(0, 0, 0.1F)))
            .key(12, GUARD)
            .done();

    /** Golpe de palma no peito, corpo ereto. Impacto: tick 2. */
    public static final Clip PALM_R = Clip.build("p_palm_r")
            .key(0, GUARD)
            .key(2, leadHandGuard(Pose.from(GUARD).root(-5, 0, 0).body(4, -25, 0).head(-12, 12, 0)
                    .ra(-85, -5, 0).elbows(5, 12).rl(10, -15, 6).knees(8, 20).off(0, 0, 0.25F)), Ease.OUT)
            .key(5, leadHandGuard(Pose.from(GUARD).root(-5, 0, 0).body(4, -23, 0).head(-12, 12, 0)
                    .ra(-83, -5, 0).elbows(8, 12).rl(10, -15, 6).knees(8, 20).off(0, 0, 0.23F)))
            .key(10, GUARD)
            .done();

    /** Rasteira baixa girando o corpo. Impacto: tick 5. */
    public static final Clip LOW_SWEEP = Clip.build("p_low_sweep")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).yaw(-60).body(35, 0, 0).head(-30, 0, 0)
                    .la(-70, 0, -30).ra(-70, 0, 30).elbows(30, 30)
                    .ll(-70, 0, -10).rl(-40, 0, 30).knees(130, 100), Ease.OUT)
            .key(5, Pose.from(GUARD).yaw(-250).body(40, 0, 10).head(-35, 40, 0)
                    .la(-80, 0, -40).ra(-80, 0, 40).elbows(20, 20)
                    .ll(-75, 0, -10).rl(-10, 0, 85).knees(0, 135), Ease.OUT)
            .key(8, Pose.from(GUARD).yaw(-330).body(35, 0, 5).head(-30, 10, 0)
                    .la(-70, 0, -30).ra(-70, 0, 30).elbows(30, 30)
                    .ll(-70, 0, -10).rl(-30, 0, 40).knees(80, 130))
            .key(13, Pose.from(GUARD).yaw(-385))
            .done();

    /** Agarra pela gola com a mão direita e ergue o adversário. Segurando a partir do tick 6. */
    public static final Clip GRAB_LIFT = Clip.build("p_grab_lift")
            .key(0, GUARD)
            .key(2, leadHandGuard(Pose.from(GUARD).root(0, 0, 0).body(6, -22, 0).head(-10, 10, 0)
                    .ra(-88, -6, 0).elbows(20, 12).knees(15, 20).off(0, 0, 0.15F)), Ease.OUT)
            .key(6, leadHandGuard(Pose.from(GUARD).root(0, 0, 0).body(-8, -18, 0).head(-25, 10, 0)
                    .ra(-135, -6, 0).elbows(15, 12).knees(4, 8).off(0, 0, 0.12F)), Ease.OUT)
            .key(10, leadHandGuard(Pose.from(GUARD).root(0, 0, 0).body(-9, -18, 0).head(-26, 10, 0)
                    .ra(-138, -6, 0).elbows(12, 12).knees(4, 8).off(0, 0, 0.12F)))
            .done();

    /** Arremessa o adversário segurado para longe. Soltura: tick 5. */
    public static final Clip THROW_R = Clip.build("p_throw_r")
            .key(0, leadHandGuard(Pose.from(GUARD).root(0, 0, 0).body(-9, -18, 0).head(-26, 10, 0)
                    .ra(-138, -6, 0).elbows(12, 12).knees(4, 8).off(0, 0, 0.12F)))
            .key(3, leadHandGuard(Pose.from(GUARD).root(20, 0, 0).body(-12, 35, 0).head(-20, -20, 0)
                    .ra(-160, 20, 20).elbows(25, 12).knees(20, 25).off(0, 0, 0.0F)))
            .key(5, leadHandGuard(Pose.from(GUARD).root(-10, 0, 0).body(15, -50, 0).head(-10, 40, 0)
                    .ra(-70, -40, 0).elbows(0, 12).rl(15, -25, 6).knees(10, 35).off(0, 0, 0.3F)), Ease.OUT)
            .key(8, leadHandGuard(Pose.from(GUARD).root(-10, 0, 0).body(12, -52, 0).head(-12, 40, 0)
                    .ra(-40, -40, 0).elbows(5, 12).rl(15, -25, 6).knees(10, 35).off(0, 0, 0.28F)))
            .key(14, GUARD)
            .done();

    /** Abaixa, agarra o adversário caído pela gola e o ergue. Segurando a partir do tick 7. */
    public static final Clip GRAB_FROM_GROUND = Clip.build("p_grab_from_ground")
            .key(0, GUARD)
            .key(3, leadHandGuard(Pose.from(GUARD).root(0, 0, 0).body(55, -15, 0).head(-40, 10, 0)
                    .ra(-55, -6, 0).elbows(10, 12).ll(-30, 0, -4).rl(20, 0, 6).knees(45, 40)
                    .off(0, 0, 0.2F)), Ease.OUT)
            .key(7, leadHandGuard(Pose.from(GUARD).root(0, 0, 0).body(-8, -18, 0).head(-25, 10, 0)
                    .ra(-135, -6, 0).elbows(15, 12).knees(4, 8).off(0, 0, 0.12F)))
            .key(10, leadHandGuard(Pose.from(GUARD).root(0, 0, 0).body(-9, -18, 0).head(-26, 10, 0)
                    .ra(-138, -6, 0).elbows(12, 12).knees(4, 8).off(0, 0, 0.12F)))
            .done();

    /** Passada da corrida ninja: tronco inclinado, braços estendidos para trás. */
    private static Pose runStride(float side) {
        return Pose.from(GUARD).root(0, 0, 0)
                .body(32, 0, 0).head(-32, 0, 0)
                .la(60, 0, -12).ra(60, 0, 12).elbows(5, 5)
                .rl(side > 0 ? -55 : 40, 0, 4).ll(side > 0 ? 40 : -55, 0, -4)
                .knees(side > 0 ? 70 : 35, side > 0 ? 35 : 70)
                .off(0, 0.06F, 0);
    }

    /** Corrida ninja em direção ao adversário (o deslocamento vem da coreografia). */
    public static final Clip NINJA_RUN = Clip.build("p_ninja_run")
            .key(0, Pose.from(GUARD).root(0, 0, 0).body(25, 0, 0).head(-25, 0, 0)
                    .la(30, 0, -10).ra(30, 0, 10).knees(40, 40))
            .key(2, runStride(1), Ease.OUT)
            .key(4.5F, Pose.from(runStride(1)).off(0, 0.12F, 0))
            .key(7, runStride(-1))
            .key(9.5F, Pose.from(runStride(-1)).off(0, 0.12F, 0))
            .key(12, runStride(1))
            .key(14, Pose.from(GUARD).root(-15, 0, 0).body(15, 5, 0).head(-20, -5, 0).knees(30, 35))
            .done();
}
