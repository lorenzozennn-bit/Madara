package com.madarataijutsu.choreo;

import com.madarataijutsu.anim.Clip;
import com.madarataijutsu.anim.Ease;
import com.madarataijutsu.anim.Pose;

/**
 * Animações do jogador (terceira pessoa) com esqueleto articulado: cotovelos,
 * joelhos e cintura. Base: guarda com o lado esquerdo à frente, joelhos
 * flexionados, mãos na altura do queixo.
 *
 * Tempos em ticks (20 = 1 s). O frame de impacto de cada golpe está anotado;
 * as coreografias sincronizam as reações dos adversários nele.
 */
public final class PlayerClips {

    private PlayerClips() {
    }

    /** Guarda. */
    public static final Pose GUARD = new Pose()
            .root(-30, 0, 0)
            .body(10, 15, 0)
            .head(-6, -12, 0)
            .la(-45, 15, -6).ra(-22, -25, 12)
            .elbows(125, 85)
            .ll(-28, 0, -4).rl(18, 0, 6)
            .knees(30, 32);

    private static final Pose GUARD_BREATH = Pose.from(GUARD)
            .body(12, 15, 0)
            .la(-43, 15, -6).ra(-20, -25, 12)
            .knees(34, 36);

    public static final Clip GUARD_IDLE = Clip.build("p_guard_idle")
            .key(0, GUARD)
            .key(12, GUARD_BREATH)
            .key(24, GUARD)
            .loop()
            .done();

    /** Retaguarda protegendo o queixo (usada durante golpes da outra mão). */
    private static Pose rearHandGuard(Pose p) {
        return p.ra(-22, -25, 12).elbows(125, p.get(Pose.L_ELBOW));
    }

    private static Pose leadHandGuard(Pose p) {
        return p.la(-40, 20, -6).elbows(p.get(Pose.R_ELBOW), 110);
    }

    /** Jab de esquerda. Impacto: tick 2. */
    public static final Clip JAB_L = Clip.build("p_jab_l")
            .key(0, GUARD)
            .key(2, rearHandGuard(Pose.from(GUARD).root(-36, 0, 0).body(14, 32, 0).head(-4, -26, 0)
                    .la(-90, 6, 0).elbows(125, 0).off(0, 0, 0.15F).knees(28, 38)), Ease.OUT)
            .key(4, rearHandGuard(Pose.from(GUARD).root(-36, 0, 0).body(14, 30, 0).head(-4, -25, 0)
                    .la(-88, 6, 0).elbows(125, 5).off(0, 0, 0.14F).knees(28, 38)))
            .key(8, GUARD)
            .done();

    /** Direto de direita (giro do quadril). Impacto: tick 2. */
    public static final Clip CROSS_R = Clip.build("p_cross_r")
            .key(0, GUARD)
            .key(2, leadHandGuard(Pose.from(GUARD).root(-8, 0, 0).body(16, -22, 0).head(-4, 10, 0)
                    .ra(-90, -6, 0).elbows(0, 110).off(0, 0, 0.3F)
                    .rl(12, -25, 6).knees(15, 38)), Ease.OUT)
            .key(4, leadHandGuard(Pose.from(GUARD).root(-8, 0, 0).body(16, -20, 0).head(-4, 10, 0)
                    .ra(-88, -6, 0).elbows(5, 110).off(0, 0, 0.28F)
                    .rl(12, -25, 6).knees(15, 38)))
            .key(9, GUARD)
            .done();

    /** Gancho de esquerda (braço em 90°, giro do tronco). Impacto: tick 3. */
    public static final Clip HOOK_L = Clip.build("p_hook_l")
            .key(0, GUARD)
            .key(1, Pose.from(GUARD).body(10, 40, 0).la(-40, 10, -45).elbows(125, 95))
            .key(3, rearHandGuard(Pose.from(GUARD).root(-20, 0, 0).body(14, -45, 0).head(-4, 25, 0)
                    .la(-35, 0, -80).elbows(125, 90).off(0, 0, 0.3F).knees(30, 42)), Ease.OUT)
            .key(5, rearHandGuard(Pose.from(GUARD).root(-20, 0, 0).body(14, -48, 0).head(-4, 26, 0)
                    .la(-35, 0, -78).elbows(125, 90).off(0, 0, 0.29F).knees(30, 42)))
            .key(10, GUARD)
            .done();

    /** Gancho de direita. Impacto: tick 3. */
    public static final Clip HOOK_R = Clip.build("p_hook_r")
            .key(0, GUARD)
            .key(1, Pose.from(GUARD).body(10, -15, 0).ra(-20, -10, 60).elbows(95, 85))
            .key(3, leadHandGuard(Pose.from(GUARD).root(-5, 0, 0).body(14, 50, 0).head(-4, -45, 0)
                    .ra(-35, 0, 80).elbows(90, 110).off(0, 0, 0.32F).rl(10, -20, 6).knees(18, 40)), Ease.OUT)
            .key(5, leadHandGuard(Pose.from(GUARD).root(-5, 0, 0).body(14, 53, 0).head(-4, -47, 0)
                    .ra(-35, 0, 78).elbows(90, 110).off(0, 0, 0.31F).rl(10, -20, 6).knees(18, 40)))
            .key(10, GUARD)
            .done();

    /** Uppercut de direita saindo de baixo. Impacto: tick 3. */
    public static final Clip UPPERCUT_R = Clip.build("p_uppercut_r")
            .key(0, GUARD)
            .key(1, leadHandGuard(Pose.from(GUARD).root(-15, 0, 0).body(28, -15, 0).head(-20, 0, 0)
                    .ra(-5, 0, 15).elbows(110, 110).knees(65, 65).off(0, 0, 0.08F)))
            .key(3, leadHandGuard(Pose.from(GUARD).root(-8, 0, 0).body(2, -30, 0).head(-10, 20, 0)
                    .ra(-95, -15, 0).elbows(75, 110).knees(5, 15).rl(10, 0, 6)
                    .off(0, 0.1F, 0.3F)), Ease.OUT)
            .key(5, leadHandGuard(Pose.from(GUARD).root(-8, 0, 0).body(2, -28, 0).head(-10, 20, 0)
                    .ra(-100, -15, 0).elbows(70, 110).knees(8, 18).rl(10, 0, 6)
                    .off(0, 0.05F, 0.29F)))
            .key(11, GUARD)
            .done();

    /** Cotovelada horizontal de direita. Impacto: tick 2. */
    public static final Clip ELBOW_R = Clip.build("p_elbow_r")
            .key(0, GUARD)
            .key(2, leadHandGuard(Pose.from(GUARD).root(15, 0, 0).body(12, 70, 0).head(-4, -80, 0)
                    .ra(0, 0, 88).elbows(150, 110).off(0, 0, 0.3F).rl(10, -25, 6).knees(20, 40)), Ease.OUT)
            .key(4, leadHandGuard(Pose.from(GUARD).root(15, 0, 0).body(12, 72, 0).head(-4, -82, 0)
                    .ra(0, 0, 86).elbows(150, 110).off(0, 0, 0.29F).rl(10, -25, 6).knees(20, 40)))
            .key(9, GUARD)
            .done();

    /** Joelhada de direita puxando o oponente pela nuca. Impacto: tick 3. */
    public static final Clip KNEE_R = Clip.build("p_knee_r")
            .key(0, GUARD)
            .key(1, Pose.from(GUARD).body(12, 0, 0).la(-110, 10, 0).ra(-110, -10, 0).elbows(30, 30)
                    .off(0, 0, 0.1F))
            .key(3, Pose.from(GUARD).root(-15, 0, 0).body(25, 0, 0).head(10, -10, 0)
                    .la(-75, 15, 0).ra(-75, -15, 0).elbows(75, 75)
                    .rl(-105, 0, 0).ll(0, 0, -4).knees(125, 10).off(0, 0.04F, 0.2F), Ease.OUT)
            .key(5, Pose.from(GUARD).root(-15, 0, 0).body(22, 0, 0).head(8, -10, 0)
                    .la(-75, 15, 0).ra(-75, -15, 0).elbows(75, 75)
                    .rl(-100, 0, 0).ll(0, 0, -4).knees(120, 12).off(0, 0.03F, 0.18F))
            .key(10, GUARD)
            .done();

    /** Chute frontal de direita (engatilha e estica). Impacto: tick 3. */
    public static final Clip FRONT_KICK_R = Clip.build("p_front_kick_r")
            .key(0, GUARD)
            .key(1, Pose.from(GUARD).root(-15, 0, 0).body(0, 10, 0).rl(-85, 0, 0).ll(-5, 0, -4).knees(110, 22))
            .key(3, Pose.from(GUARD).root(-15, 0, 0).body(-14, 10, 0).head(10, -10, 0)
                    .rl(-92, 0, 0).ll(0, 0, -4).knees(0, 18).off(0, 0, 0.22F), Ease.OUT)
            .key(5, Pose.from(GUARD).root(-15, 0, 0).body(-12, 10, 0).head(10, -10, 0)
                    .rl(-90, 0, 0).ll(0, 0, -4).knees(5, 18).off(0, 0, 0.21F))
            .key(7, Pose.from(GUARD).root(-15, 0, 0).body(0, 10, 0).rl(-80, 0, 0).ll(-5, 0, -4).knees(105, 22)
                    .off(0, 0, 0.1F))
            .key(10, GUARD)
            .done();

    /** Chute lateral de direita (corpo de perfil, tronco inclinado para longe). Impacto: tick 4. */
    public static final Clip SIDE_KICK_R = Clip.build("p_side_kick_r")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).root(75, 0, 0).body(5, 0, 15).head(0, 55, -10)
                    .rl(-30, 0, 55).ll(0, 0, -4).knees(120, 25))
            .key(4, Pose.from(GUARD).root(88, 0, 0).body(0, 0, 32).head(0, 60, -25)
                    .la(-40, 20, -40).ra(-20, -25, 25).elbows(110, 90)
                    .rl(0, 0, 88).ll(0, 0, -4).knees(0, 22).off(0, 0.04F, 0.18F), Ease.OUT)
            .key(7, Pose.from(GUARD).root(88, 0, 0).body(0, 0, 30).head(0, 60, -24)
                    .la(-40, 20, -40).ra(-20, -25, 25).elbows(110, 90)
                    .rl(0, 0, 85).ll(0, 0, -4).knees(5, 22).off(0, 0.04F, 0.17F))
            .key(9, Pose.from(GUARD).root(75, 0, 0).body(5, 0, 15).head(0, 55, -10)
                    .rl(-30, 0, 55).ll(0, 0, -4).knees(115, 25))
            .key(13, GUARD)
            .done();

    /** Chute giratório (360°) com a perna direita. Impacto: tick 6. */
    public static final Clip SPIN_KICK = Clip.build("p_spin_kick")
            .key(0, GUARD)
            .key(3, Pose.from(GUARD).yaw(-150).body(5, 0, 10).head(0, 0, 0)
                    .rl(-30, 0, 50).ll(0, 0, -4).knees(100, 30).off(0, 0.05F, 0.05F))
            .key(6, Pose.from(GUARD).root(-272, 0, 0).body(0, 0, 32).head(0, 62, -25)
                    .la(-30, 20, -50).ra(-20, -20, 30).elbows(110, 90)
                    .rl(0, 0, 88).ll(0, 0, -4).knees(0, 25).off(0, 0.08F, 0.2F), Ease.OUT)
            .key(8, Pose.from(GUARD).root(-300, 0, 0).body(0, 0, 26).head(0, 55, -20)
                    .la(-30, 20, -50).ra(-20, -20, 30).elbows(110, 90)
                    .rl(0, 0, 75).ll(0, 0, -4).knees(30, 25).off(0, 0.06F, 0.2F))
            .key(13, Pose.from(GUARD).yaw(-390))
            .done();

    /** Chute giratório saltado (acrobático). Impacto: tick 8. */
    public static final Clip JUMP_SPIN_KICK = Clip.build("p_jump_spin_kick")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).body(20, 15, 0).la(-20, 0, -20).ra(-20, 0, 20).elbows(40, 40).knees(70, 70))
            .key(5, Pose.from(GUARD).yaw(-160).body(0, 0, 10).head(0, 0, 0)
                    .la(-150, 0, -30).ra(-150, 0, 30).elbows(30, 30)
                    .rl(-60, 0, 30).ll(-70, 0, -10).knees(110, 120).off(0, 0.8F, 0.15F), Ease.OUT)
            .key(8, Pose.from(GUARD).root(-272, 0, 0).body(0, 0, 32).head(0, 62, -25)
                    .la(-30, 20, -60).ra(-20, -20, 40).elbows(110, 90)
                    .rl(0, 0, 90).ll(-60, 0, -10).knees(0, 110).off(0, 0.85F, 0.3F), Ease.OUT)
            .key(11, Pose.from(GUARD).root(-340, 0, 0).body(5, 0, 10).head(0, 20, 0)
                    .rl(-40, 0, 20).ll(-40, 0, -10).knees(80, 80).off(0, 0.35F, 0.3F))
            .key(13, Pose.from(GUARD).yaw(-390).knees(70, 70).off(0, 0, 0.25F), Ease.IN)
            .key(17, Pose.from(GUARD).yaw(-390))
            .done();

    /** Esquiva lateral para a esquerda (desce e inclina). */
    public static final Clip DODGE_LEFT = Clip.build("p_dodge_left")
            .key(0, GUARD)
            .key(3, Pose.from(GUARD).root(-30, 0, -18).body(15, 15, -15).head(0, -12, 15)
                    .knees(60, 50).off(-0.5F, 0, -0.05F), Ease.OUT)
            .key(7, Pose.from(GUARD).root(-30, 0, -16).body(15, 15, -13).head(0, -12, 13)
                    .knees(58, 48).off(-0.48F, 0, -0.05F))
            .key(11, GUARD)
            .done();

    /** Esquiva lateral para a direita. */
    public static final Clip DODGE_RIGHT = Clip.build("p_dodge_right")
            .key(0, GUARD)
            .key(3, Pose.from(GUARD).root(-30, 0, 18).body(15, 15, 15).head(0, -12, -15)
                    .knees(50, 60).off(0.5F, 0, -0.05F), Ease.OUT)
            .key(7, Pose.from(GUARD).root(-30, 0, 16).body(15, 15, 13).head(0, -12, -13)
                    .knees(48, 58).off(0.48F, 0, -0.05F))
            .key(11, GUARD)
            .done();

    /** Esquiva inclinando o tronco para trás (joelhos dobrados). */
    public static final Clip LEAN_BACK = Clip.build("p_lean_back")
            .key(0, GUARD)
            .key(3, Pose.from(GUARD).body(-40, 10, 0).head(25, -10, 0)
                    .la(-30, 0, -45).ra(-30, 0, 45).elbows(40, 40)
                    .ll(-35, 0, -4).rl(10, 0, 6).knees(55, 70).off(0, 0, -0.1F), Ease.OUT)
            .key(7, Pose.from(GUARD).body(-38, 10, 0).head(23, -10, 0)
                    .la(-30, 0, -45).ra(-30, 0, 45).elbows(40, 40)
                    .ll(-35, 0, -4).rl(10, 0, 6).knees(55, 70).off(0, 0, -0.1F))
            .key(11, GUARD)
            .done();

    /** Bloqueio alto com os antebraços na frente do rosto. Contato: tick 2. */
    public static final Clip BLOCK = Clip.build("p_block")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).root(-15, 0, 0).body(15, 0, 0).head(12, -15, 0)
                    .la(-80, 25, 0).ra(-80, -25, 0).elbows(105, 105).knees(40, 40), Ease.OUT)
            .key(3, Pose.from(GUARD).root(-15, 0, 0).body(10, 0, 0).head(12, -15, 0)
                    .la(-80, 25, 0).ra(-80, -25, 0).elbows(105, 105).knees(45, 45).off(0, 0, -0.14F))
            .key(6, Pose.from(GUARD).root(-15, 0, 0).body(12, 0, 0).head(12, -15, 0)
                    .la(-80, 25, 0).ra(-80, -25, 0).elbows(105, 105).knees(42, 42).off(0, 0, -0.12F))
            .key(10, GUARD)
            .done();

    /** Mortal para trás (esquiva acrobática). */
    public static final Clip BACKFLIP = Clip.build("p_backflip")
            .key(0, GUARD)
            .key(3, Pose.from(GUARD).body(15, 0, 0).head(0, 0, 0).la(-170, 0, -10).ra(-170, 0, 10).elbows(10, 10)
                    .ll(0, 0, -4).rl(0, 0, 4).knees(75, 75))
            .key(7, Pose.from(GUARD).root(-30, -180, 0).pivot(0.7F).body(20, 0, 0).head(10, 0, 0)
                    .la(-60, 0, -15).ra(-60, 0, 15).elbows(60, 60)
                    .ll(-110, 0, -4).rl(-110, 0, 4).knees(140, 140).off(0, 0.95F, -0.35F), Ease.LINEAR)
            .key(11, Pose.from(GUARD).root(-30, -340, 0).pivot(0.7F).knees(80, 80).off(0, 0.15F, -0.6F),
                    Ease.LINEAR)
            .key(13, Pose.from(GUARD).root(-30, -360, 0).pivot(0.7F).knees(70, 70).off(0, 0, -0.6F))
            .key(17, Pose.from(GUARD).root(-30, -360, 0).pivot(0.7F))
            .done();

    /** Postura de vitória: ereta, queixo erguido, mão direita estendida à frente. */
    public static final Pose VICTORY_POSE = new Pose()
            .head(-10, 0, 0)
            .ra(-62, -8, 4).elbows(25, 10)
            .la(4, 0, -6)
            .rl(0, 0, 3).ll(0, 0, -3)
            .knees(3, 3);

    public static final Clip VICTORY = Clip.build("p_victory")
            .key(0, GUARD)
            .key(5, Pose.from(GUARD).body(0, 0, 0).knees(15, 15).off(0, 0, -0.1F))
            .key(14, VICTORY_POSE)
            .key(40, Pose.from(VICTORY_POSE).ra(-64, -8, 4))
            .done();
}
