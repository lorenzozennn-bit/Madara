package com.madarataijutsu.choreo;

import com.madarataijutsu.anim.Clip;
import com.madarataijutsu.anim.Ease;
import com.madarataijutsu.anim.Pose;

/**
 * Biblioteca de animações do jogador (terceira pessoa), inspiradas no taijutsu
 * do Madara: base lateral com o ombro esquerdo à frente, golpes curtos e
 * explosivos, giros e esquivas com inclinação do corpo inteiro.
 *
 * Tempos em ticks (20 ticks = 1 segundo). O "frame de impacto" de cada golpe
 * está documentado ao lado; as coreografias sincronizam as reações nele.
 */
public final class PlayerClips {

    private PlayerClips() {
    }

    /** Guarda: corpo virado 25° para a direita, cabeça olhando o alvo. */
    public static final Pose GUARD = new Pose()
            .head(0, -25, 0)
            .ra(-60, -30, 5)
            .la(-80, 20, -5)
            .rl(18, 0, 6)
            .ll(-18, 0, -6)
            .root(-25, 4, 0);

    private static final Pose GUARD_BREATH = Pose.from(GUARD)
            .ra(-56, -30, 6)
            .la(-76, 20, -6)
            .off(0, -0.015F, 0);

    public static final Clip GUARD_IDLE = Clip.build("p_guard_idle")
            .key(0, GUARD)
            .key(12, GUARD_BREATH)
            .key(24, GUARD)
            .loop()
            .done();

    /** Jab de esquerda. Impacto: tick 2. */
    public static final Clip JAB_L = Clip.build("p_jab_l")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).la(-92, 5, 0).body(0, 18, 0).root(-35, 8, 0).off(0, 0, 0.18F), Ease.OUT)
            .key(4, Pose.from(GUARD).la(-90, 5, 0).body(0, 16, 0).root(-34, 8, 0).off(0, 0, 0.17F))
            .key(8, GUARD)
            .done();

    /** Direto de direita. Impacto: tick 2. */
    public static final Clip CROSS_R = Clip.build("p_cross_r")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).ra(-92, -5, 0).la(-70, 30, -5).body(0, -25, 0)
                    .rl(25, 0, 6).ll(-25, 0, -6).root(-5, 10, 0).off(0, 0, 0.3F), Ease.OUT)
            .key(4, Pose.from(GUARD).ra(-90, -5, 0).la(-70, 30, -5).body(0, -23, 0)
                    .rl(25, 0, 6).ll(-25, 0, -6).root(-6, 10, 0).off(0, 0, 0.28F))
            .key(9, GUARD)
            .done();

    /** Gancho de esquerda. Impacto: tick 3. */
    public static final Clip HOOK_L = Clip.build("p_hook_l")
            .key(0, GUARD)
            .key(1, Pose.from(GUARD).la(-60, -20, -35).body(0, -10, 0).root(-18, 4, 0))
            .key(3, Pose.from(GUARD).la(-90, 55, 0).body(0, 30, 0).root(-42, 7, 0).off(0, 0, 0.15F), Ease.OUT)
            .key(5, Pose.from(GUARD).la(-88, 58, 0).body(0, 32, 0).root(-44, 7, 0).off(0, 0, 0.14F))
            .key(10, GUARD)
            .done();

    /** Gancho de direita. Impacto: tick 3. */
    public static final Clip HOOK_R = Clip.build("p_hook_r")
            .key(0, GUARD)
            .key(1, Pose.from(GUARD).ra(-60, 25, 35).body(0, 10, 0).root(-30, 4, 0))
            .key(3, Pose.from(GUARD).ra(-90, -55, 0).body(0, -30, 0).root(-2, 7, 0).off(0, 0, 0.2F), Ease.OUT)
            .key(5, Pose.from(GUARD).ra(-88, -58, 0).body(0, -32, 0).root(0, 7, 0).off(0, 0, 0.19F))
            .key(10, GUARD)
            .done();

    /** Uppercut de direita com pequeno salto. Impacto: tick 3. */
    public static final Clip UPPERCUT_R = Clip.build("p_uppercut_r")
            .key(0, GUARD)
            .key(1, Pose.from(GUARD).ra(-20, -10, 12).root(-15, 15, 0).off(0, -0.03F, 0.08F))
            .key(3, Pose.from(GUARD).ra(-165, -15, 0).body(0, -20, 0).head(-15, -10, 0)
                    .root(-10, -10, 0).off(0, 0.18F, 0.25F), Ease.OUT)
            .key(5, Pose.from(GUARD).ra(-160, -15, 0).body(0, -18, 0).head(-12, -10, 0)
                    .root(-10, -8, 0).off(0, 0.12F, 0.24F))
            .key(11, GUARD)
            .done();

    /** Cotovelada horizontal de direita. Impacto: tick 2. */
    public static final Clip ELBOW_R = Clip.build("p_elbow_r")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).ra(-95, -80, 0).la(-80, 20, -5).body(0, -35, 0)
                    .root(10, 5, 0).off(0, 0, 0.25F), Ease.OUT)
            .key(4, Pose.from(GUARD).ra(-95, -82, 0).la(-80, 20, -5).body(0, -36, 0)
                    .root(11, 5, 0).off(0, 0, 0.24F))
            .key(9, GUARD)
            .done();

    /** Joelhada de direita puxando o oponente. Impacto: tick 3. */
    public static final Clip KNEE_R = Clip.build("p_knee_r")
            .key(0, GUARD)
            .key(1, Pose.from(GUARD).ra(-100, -10, 0).la(-100, 10, 0).root(-10, 8, 0).off(0, 0, 0.1F))
            .key(3, Pose.from(GUARD).ra(-60, -10, 0).la(-60, 10, 0).rl(-110, 0, 0).ll(5, 0, 0)
                    .root(-10, 12, 0).off(0, 0.06F, 0.22F), Ease.OUT)
            .key(5, Pose.from(GUARD).ra(-62, -10, 0).la(-62, 10, 0).rl(-105, 0, 0).ll(5, 0, 0)
                    .root(-10, 10, 0).off(0, 0.04F, 0.2F))
            .key(10, GUARD)
            .done();

    /** Chute frontal de direita. Impacto: tick 3. */
    public static final Clip FRONT_KICK_R = Clip.build("p_front_kick_r")
            .key(0, GUARD)
            .key(1, Pose.from(GUARD).rl(-50, 0, 0).root(-10, -5, 0))
            .key(3, Pose.from(GUARD).rl(-95, 0, 0).ll(8, 0, 0).root(-10, -12, 0).off(0, 0.05F, 0.25F), Ease.OUT)
            .key(5, Pose.from(GUARD).rl(-92, 0, 0).ll(8, 0, 0).root(-10, -11, 0).off(0, 0.05F, 0.24F))
            .key(10, GUARD)
            .done();

    /** Chute lateral de direita (corpo de perfil). Impacto: tick 4. */
    public static final Clip SIDE_KICK_R = Clip.build("p_side_kick_r")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).yaw(80).head(0, 55, 0).rl(-40, 0, 40).ra(-40, -20, 30).la(-50, 20, -20))
            .key(4, Pose.from(GUARD).root(90, 0, -20).head(0, 60, 0).rl(-5, 0, 88).ll(0, 0, -5)
                    .ra(-30, 0, 25).la(-80, 30, -10).off(0, 0.05F, 0.2F), Ease.OUT)
            .key(7, Pose.from(GUARD).root(90, 0, -18).head(0, 60, 0).rl(-5, 0, 85).ll(0, 0, -5)
                    .ra(-30, 0, 25).la(-80, 30, -10).off(0, 0.05F, 0.19F))
            .key(12, GUARD)
            .done();

    /** Chute giratório (360°) com a perna direita. Impacto: tick 6. */
    public static final Clip SPIN_KICK = Clip.build("p_spin_kick")
            .key(0, GUARD)
            .key(3, Pose.from(GUARD).yaw(-140).head(0, 0, 0).rl(-30, 0, 40).off(0, 0.08F, 0.05F))
            .key(6, Pose.from(GUARD).root(-270, 0, -20).head(0, 60, 0).rl(-5, 0, 88).ll(0, 0, -5)
                    .ra(-20, 0, 40).la(-40, 0, -30).off(0, 0.15F, 0.2F), Ease.OUT)
            .key(8, Pose.from(GUARD).root(-290, 0, -15).head(0, 55, 0).rl(-5, 0, 80).ll(0, 0, -5)
                    .ra(-20, 0, 40).la(-40, 0, -30).off(0, 0.12F, 0.2F))
            .key(13, Pose.from(GUARD).yaw(-385))
            .done();

    /** Chute giratório saltado (acrobático). Impacto: tick 8. */
    public static final Clip JUMP_SPIN_KICK = Clip.build("p_jump_spin_kick")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).root(-25, 12, 0).ra(-20, 0, 20).la(-20, 0, -20).off(0, -0.04F, 0))
            .key(5, Pose.from(GUARD).root(-160, 0, 0).head(0, 0, 0).rl(-80, 0, 20).ll(-90, 0, -10)
                    .ra(-120, 0, 30).la(-120, 0, -30).off(0, 0.75F, 0.15F), Ease.OUT)
            .key(8, Pose.from(GUARD).root(-270, 0, -25).head(0, 60, 0).rl(-5, 0, 90).ll(-40, 0, -10)
                    .ra(-20, 0, 50).la(-40, 0, -40).off(0, 0.85F, 0.3F), Ease.OUT)
            .key(11, Pose.from(GUARD).root(-340, 0, -10).head(0, 30, 0).rl(-30, 0, 20).ll(-30, 0, -10)
                    .off(0, 0.35F, 0.3F))
            .key(13, Pose.from(GUARD).yaw(-385).off(0, 0, 0.25F), Ease.IN)
            .key(17, Pose.from(GUARD).yaw(-385))
            .done();

    /** Esquiva lateral para a esquerda. */
    public static final Clip DODGE_LEFT = Clip.build("p_dodge_left")
            .key(0, GUARD)
            .key(3, Pose.from(GUARD).root(-25, 6, -22).off(-0.55F, 0, -0.05F)
                    .ra(-90, -30, 5).la(-95, 20, -5).head(0, -25, -10), Ease.OUT)
            .key(7, Pose.from(GUARD).root(-25, 6, -20).off(-0.52F, 0, -0.05F)
                    .ra(-90, -30, 5).la(-95, 20, -5).head(0, -25, -10))
            .key(11, GUARD)
            .done();

    /** Esquiva lateral para a direita. */
    public static final Clip DODGE_RIGHT = Clip.build("p_dodge_right")
            .key(0, GUARD)
            .key(3, Pose.from(GUARD).root(-25, 6, 22).off(0.55F, 0, -0.05F)
                    .ra(-95, -30, 5).la(-90, 20, -5).head(0, -25, 10), Ease.OUT)
            .key(7, Pose.from(GUARD).root(-25, 6, 20).off(0.52F, 0, -0.05F)
                    .ra(-95, -30, 5).la(-90, 20, -5).head(0, -25, 10))
            .key(11, GUARD)
            .done();

    /** Esquiva inclinando o corpo para trás. */
    public static final Clip LEAN_BACK = Clip.build("p_lean_back")
            .key(0, GUARD)
            .key(3, Pose.from(GUARD).root(-25, -35, 0).head(20, -25, 0)
                    .ra(-25, 0, 40).la(-25, 0, -40).rl(-10, 0, 6).ll(-25, 0, -6), Ease.OUT)
            .key(7, Pose.from(GUARD).root(-25, -33, 0).head(18, -25, 0)
                    .ra(-25, 0, 40).la(-25, 0, -40).rl(-10, 0, 6).ll(-25, 0, -6))
            .key(11, GUARD)
            .done();

    /** Bloqueio alto com os dois antebraços. Contato: tick 2. */
    public static final Clip BLOCK = Clip.build("p_block")
            .key(0, GUARD)
            .key(2, Pose.from(GUARD).ra(-115, -45, 0).la(-118, 45, 0).head(10, -10, 0)
                    .root(-10, 6, 0), Ease.OUT)
            .key(3, Pose.from(GUARD).ra(-112, -45, 0).la(-115, 45, 0).head(10, -10, 0)
                    .root(-10, 2, 0).off(0, 0, -0.14F))
            .key(6, Pose.from(GUARD).ra(-112, -45, 0).la(-115, 45, 0).head(10, -10, 0)
                    .root(-10, 3, 0).off(0, 0, -0.12F))
            .key(10, GUARD)
            .done();

    /** Mortal para trás (esquiva acrobática). */
    public static final Clip BACKFLIP = Clip.build("p_backflip")
            .key(0, GUARD)
            .key(3, Pose.from(GUARD).root(-25, 10, 0).ra(-170, 0, 10).la(-170, 0, -10).off(0, -0.03F, 0))
            .key(7, Pose.from(GUARD).root(-25, -180, 0).pivot(0.9F).rl(-100, 0, 0).ll(-100, 0, 0)
                    .ra(-60, 0, 10).la(-60, 0, -10).off(0, 0.9F, -0.5F), Ease.LINEAR)
            .key(11, Pose.from(GUARD).root(-25, -360, 0).pivot(0.9F).off(0, 0, -0.85F), Ease.LINEAR)
            .key(13, Pose.from(GUARD).root(-25, -360, 0).pivot(0.9F).off(0, -0.02F, -0.8F))
            .key(17, Pose.from(GUARD).root(-25, -360, 0).pivot(0.9F))
            .done();

    /** Pose final de vitória: postura ereta, queixo erguido, mão direita estendida. */
    public static final Pose VICTORY_POSE = new Pose()
            .head(-10, 0, 0)
            .ra(-70, -10, 0)
            .la(5, 0, -8)
            .rl(0, 0, 3)
            .ll(0, 0, -3)
            .root(0, 0, 0);

    public static final Clip VICTORY = Clip.build("p_victory")
            .key(0, GUARD)
            .key(5, Pose.from(GUARD).root(-25, -4, 0).off(0, 0, -0.1F))
            .key(14, VICTORY_POSE)
            .key(40, Pose.from(VICTORY_POSE).ra(-72, -10, 0))
            .done();
}
