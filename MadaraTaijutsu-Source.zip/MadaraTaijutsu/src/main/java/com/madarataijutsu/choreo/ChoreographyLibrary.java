package com.madarataijutsu.choreo;

import com.madarataijutsu.anim.Clip;
import com.madarataijutsu.mode.TaijutsuMode;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

import static com.madarataijutsu.choreo.ImpactType.ACTOR_BLOCK;
import static com.madarataijutsu.choreo.ImpactType.HEAVY;
import static com.madarataijutsu.choreo.ImpactType.HIT;
import static com.madarataijutsu.choreo.ImpactType.MISS;
import static com.madarataijutsu.choreo.ImpactType.PLAYER_BLOCK;

/**
 * Gerenciador de coreografias: uma sequência própria para cada modo.
 *
 * Distâncias (blocos): 1.4 alcance de soco, 1.6 alcance de chute,
 * 2.0+ adversário empurrado, 2.6+ lançado ao chão.
 */
public final class ChoreographyLibrary {

    private static final Map<TaijutsuMode, Choreography> CACHE = new EnumMap<TaijutsuMode, Choreography>(TaijutsuMode.class);

    private ChoreographyLibrary() {
    }

    public static synchronized Choreography get(TaijutsuMode mode) {
        Choreography c = CACHE.get(mode);
        if (c == null) {
            c = create(mode);
            CACHE.put(mode, c);
        }
        return c;
    }

    private static Choreography create(TaijutsuMode mode) {
        switch (mode) {
            case ONE_V_TWO: return oneVsTwo();
            case ONE_V_THREE: return oneVsThree();
            case ONE_V_FOUR: return oneVsFour();
            case ONE_V_FIVE: return oneVsFive();
            case ONE_V_ONE:
            default: return oneVsOne();
        }
    }

    private static Step s(int duration, Clip player, int face) {
        return new Step(duration, player, face, 3);
    }

    private static Step turn(int duration, Clip player, int face, int turnTicks) {
        return new Step(duration, player, face, turnTicks);
    }

    // ------------------------------------------------------------------ 1v1
    /** Combate técnico: jabs, diretos, ganchos, chutes, bloqueios, esquivas e contra-ataques. */
    private static Choreography oneVsOne() {
        List<Step> st = new ArrayList<Step>();
        st.add(s(14, null, 0).approach(0, 1.4F, 0));
        st.add(s(10, PlayerClips.JAB_L, 0).act(0, ActorClips.BLOCK, 1, ACTOR_BLOCK));
        st.add(s(10, PlayerClips.CROSS_R, 0).act(0, ActorClips.HIT, 2, HIT));
        st.add(s(14, PlayerClips.LEAN_BACK, 0).act(0, ActorClips.PUNCH, 0).fx(0, MISS, 6));
        st.add(s(12, PlayerClips.HOOK_L, 0).act(0, ActorClips.HIT, 3, HIT));
        st.add(s(13, PlayerClips.BLOCK, 0).act(0, ActorClips.KICK, 0).fx(0, PLAYER_BLOCK, 6));
        st.add(s(12, PlayerClips.FRONT_KICK_R, 0).act(0, ActorClips.STAGGER, 3, HEAVY).move(0, 2.0F, 3, 6));
        st.add(s(14, PlayerClips.DODGE_RIGHT, 0).move(0, 1.4F, 0, 5).act(0, ActorClips.PUNCH, 0).fx(0, MISS, 6));
        st.add(s(10, PlayerClips.JAB_L, 0).act(0, ActorClips.HIT, 2, HIT));
        st.add(s(12, PlayerClips.UPPERCUT_R, 0).act(0, ActorClips.STAGGER, 3, HEAVY).move(0, 1.7F, 3, 6));
        st.add(s(18, PlayerClips.SPIN_KICK, 0).defeat(0, ActorClips.FALL_SPIN, 6, HEAVY, 2.9F));
        return new Choreography(TaijutsuMode.ONE_V_ONE, new float[]{0F}, 3.0F, st);
    }

    // ------------------------------------------------------------------ 1v2
    /** Alternância: frente e costas, desvios laterais e chutes no segundo adversário. */
    private static Choreography oneVsTwo() {
        List<Step> st = new ArrayList<Step>();
        st.add(s(14, null, 0).approach(0, 1.4F, 0).approach(1, 1.6F, 2));
        st.add(s(10, PlayerClips.JAB_L, 0).act(0, ActorClips.HIT, 2, HIT));
        st.add(turn(14, PlayerClips.DODGE_LEFT, 1, 3).act(1, ActorClips.PUNCH, 0).fx(1, MISS, 6));
        st.add(s(11, PlayerClips.ELBOW_R, 1).move(1, 1.4F, 0, 3).act(1, ActorClips.HIT, 2, HIT));
        st.add(turn(11, PlayerClips.CROSS_R, 0, 2).act(0, ActorClips.BLOCK, 1, ACTOR_BLOCK));
        st.add(turn(14, PlayerClips.SIDE_KICK_R, 1, 2).act(1, ActorClips.STAGGER, 4, HEAVY).move(1, 2.1F, 4, 6));
        st.add(turn(14, PlayerClips.LEAN_BACK, 0, 3).act(0, ActorClips.KICK, 0).fx(0, MISS, 6));
        st.add(s(12, PlayerClips.HOOK_R, 0).act(0, ActorClips.HIT, 3, HIT));
        st.add(turn(13, PlayerClips.BLOCK, 1, 3).move(1, 1.4F, 0, 5).act(1, ActorClips.PUNCH, 0).fx(1, PLAYER_BLOCK, 6));
        st.add(s(12, PlayerClips.UPPERCUT_R, 1).act(1, ActorClips.HIT, 3, HEAVY));
        st.add(turn(13, PlayerClips.FRONT_KICK_R, 0, 2).defeat(0, ActorClips.FALL_BACK, 3, HEAVY, 2.7F));
        st.add(turn(18, PlayerClips.SPIN_KICK, 1, 3).defeat(1, ActorClips.FALL_SPIN, 6, HEAVY, 2.9F));
        return new Choreography(TaijutsuMode.ONE_V_TWO, new float[]{0F, 180F}, 3.0F, st);
    }

    // ------------------------------------------------------------------ 1v3
    /** Mobilidade: ataques multidirecionais, cotoveladas, giros e esquivas coordenadas. */
    private static Choreography oneVsThree() {
        List<Step> st = new ArrayList<Step>();
        // Etapa 1: o primeiro adversário avança.
        st.add(s(14, null, 0).approach(0, 1.4F, 0));
        // Etapa 2: soco do jogador, o adversário reage.
        st.add(s(10, PlayerClips.CROSS_R, 0).act(0, ActorClips.HIT, 2, HIT));
        // Etapa 3: o segundo adversário ataca, o jogador esquiva.
        st.add(turn(14, PlayerClips.DODGE_LEFT, 1, 3).move(1, 1.5F, 0, 5).act(1, ActorClips.PUNCH, 0).fx(1, MISS, 6));
        // Etapa 4: contra-ataque com chute.
        st.add(s(12, PlayerClips.FRONT_KICK_R, 1).act(1, ActorClips.STAGGER, 3, HEAVY).move(1, 2.1F, 3, 6));
        // Etapa 5: o terceiro adversário se aproxima.
        st.add(turn(14, null, 2, 4).approach(2, 1.6F, 0));
        // Etapa 6: giro atingindo o terceiro adversário.
        st.add(s(16, PlayerClips.SPIN_KICK, 2).act(2, ActorClips.STAGGER, 6, HEAVY).move(2, 2.0F, 6, 6));
        // Etapa 7+: sequência coordenada com os restantes.
        st.add(turn(11, PlayerClips.ELBOW_R, 0, 2).act(0, ActorClips.HIT, 2, HIT).move(1, 1.5F, 2, 8));
        st.add(turn(12, PlayerClips.HOOK_L, 1, 2).act(1, ActorClips.BLOCK, 2, ACTOR_BLOCK).move(2, 1.5F, 0, 8));
        st.add(s(14, PlayerClips.BLOCK, 1).act(1, ActorClips.KICK, 0).act(2, ActorClips.PUNCH, 0)
                .fx(1, PLAYER_BLOCK, 6).fx(2, MISS, 6));
        st.add(turn(12, PlayerClips.UPPERCUT_R, 2, 2).defeat(2, ActorClips.FALL_BACK, 3, HEAVY, 2.6F));
        st.add(turn(14, PlayerClips.SIDE_KICK_R, 0, 2).act(0, ActorClips.STAGGER, 4, HEAVY).move(0, 1.9F, 4, 6));
        st.add(turn(11, PlayerClips.KNEE_R, 1, 2).act(1, ActorClips.HIT_BODY, 3, HIT));
        st.add(turn(12, PlayerClips.HOOK_R, 0, 2).move(0, 1.4F, 0, 3).defeat(0, ActorClips.FALL_FORWARD, 3, HEAVY, 1.9F));
        // Etapa final: giro derruba o último adversário.
        st.add(turn(18, PlayerClips.SPIN_KICK, 1, 3).defeat(1, ActorClips.FALL_SPIN, 6, HEAVY, 2.9F));
        return new Choreography(TaijutsuMode.ONE_V_THREE, new float[]{0F, 120F, 240F}, 3.0F, st);
    }

    // ------------------------------------------------------------------ 1v4
    /** Combate avançado: giros corporais, acrobacias, contra-ataques em sequência. */
    private static Choreography oneVsFour() {
        List<Step> st = new ArrayList<Step>();
        st.add(s(18, null, 0).approach(0, 1.4F, 0).approach(1, 1.6F, 2).approach(2, 1.6F, 4).approach(3, 1.6F, 6));
        st.add(s(10, PlayerClips.JAB_L, 0).act(0, ActorClips.HIT, 2, HIT));
        st.add(s(11, PlayerClips.CROSS_R, 0).act(0, ActorClips.STAGGER, 2, HEAVY).move(0, 2.0F, 2, 6));
        st.add(turn(13, PlayerClips.BLOCK, 1, 3).move(1, 1.4F, 0, 4).act(1, ActorClips.PUNCH, 0).fx(1, PLAYER_BLOCK, 6));
        st.add(s(11, PlayerClips.ELBOW_R, 1).act(1, ActorClips.HIT, 2, HIT));
        st.add(turn(18, PlayerClips.BACKFLIP, 2, 3).act(2, ActorClips.KICK, 0).fx(2, MISS, 6));
        st.add(s(12, PlayerClips.FRONT_KICK_R, 2).act(2, ActorClips.STAGGER, 3, HEAVY).move(2, 2.1F, 3, 6));
        st.add(turn(14, PlayerClips.LEAN_BACK, 3, 3).move(3, 1.4F, 0, 4).act(3, ActorClips.PUNCH, 0).fx(3, MISS, 6));
        st.add(s(12, PlayerClips.HOOK_L, 3).act(3, ActorClips.HIT, 3, HIT));
        st.add(turn(14, PlayerClips.SIDE_KICK_R, 0, 2).move(0, 1.6F, 0, 3).act(0, ActorClips.STAGGER, 4, HEAVY).move(0, 2.0F, 4, 6));
        st.add(turn(15, PlayerClips.DODGE_RIGHT, 1, 3).move(2, 1.5F, 0, 5).act(1, ActorClips.KICK, 0)
                .act(2, ActorClips.PUNCH, 1).fx(1, MISS, 6).fx(2, MISS, 7));
        st.add(s(12, PlayerClips.UPPERCUT_R, 1).defeat(1, ActorClips.FALL_BACK, 3, HEAVY, 2.6F));
        st.add(turn(12, PlayerClips.HOOK_R, 2, 2).act(2, ActorClips.HIT, 3, HIT));
        st.add(s(18, PlayerClips.JUMP_SPIN_KICK, 2).defeat(2, ActorClips.FALL_SPIN, 8, HEAVY, 3.0F));
        st.add(turn(11, PlayerClips.KNEE_R, 3, 2).move(3, 1.4F, 0, 3).act(3, ActorClips.HIT_BODY, 3, HIT));
        st.add(s(11, PlayerClips.ELBOW_R, 3).defeat(3, ActorClips.FALL_FORWARD, 2, HEAVY, 1.8F));
        st.add(turn(18, PlayerClips.SPIN_KICK, 0, 3).move(0, 1.6F, 0, 4).defeat(0, ActorClips.FALL_BACK, 6, HEAVY, 2.9F));
        return new Choreography(TaijutsuMode.ONE_V_FOUR, new float[]{0F, 90F, 180F, 270F}, 3.0F, st);
    }

    // ------------------------------------------------------------------ 1v5
    /** Cinematográfico: ataques coordenados, mudanças rápidas de direção, finalização dupla. */
    private static Choreography oneVsFive() {
        List<Step> st = new ArrayList<Step>();
        st.add(s(20, null, 0).approach(0, 1.4F, 0).approach(1, 1.7F, 2).approach(2, 1.8F, 4)
                .approach(3, 1.8F, 6).approach(4, 1.7F, 7));
        st.add(s(10, PlayerClips.JAB_L, 0).act(0, ActorClips.HIT, 2, HIT));
        st.add(s(12, PlayerClips.HOOK_R, 0).act(0, ActorClips.STAGGER, 3, HEAVY).move(0, 2.1F, 3, 6));
        st.add(turn(14, PlayerClips.LEAN_BACK, 1, 3).move(1, 1.4F, 0, 4).act(1, ActorClips.PUNCH, 0).fx(1, MISS, 6));
        st.add(s(11, PlayerClips.ELBOW_R, 1).act(1, ActorClips.HIT, 2, HIT));
        st.add(turn(15, PlayerClips.DODGE_LEFT, 4, 3).move(4, 1.5F, 0, 4).move(3, 1.5F, 0, 4)
                .act(4, ActorClips.KICK, 0).act(3, ActorClips.PUNCH, 1).fx(4, MISS, 6).fx(3, MISS, 7));
        st.add(s(12, PlayerClips.FRONT_KICK_R, 4).act(4, ActorClips.STAGGER, 3, HEAVY).move(4, 2.1F, 3, 6));
        st.add(turn(16, PlayerClips.SPIN_KICK, 3, 2).act(3, ActorClips.STAGGER, 6, HEAVY).move(3, 2.0F, 6, 6));
        st.add(turn(13, PlayerClips.BLOCK, 2, 3).move(2, 1.4F, 0, 4).act(2, ActorClips.PUNCH, 0).fx(2, PLAYER_BLOCK, 6));
        st.add(s(12, PlayerClips.UPPERCUT_R, 2).defeat(2, ActorClips.FALL_BACK, 3, HEAVY, 2.6F));
        st.add(turn(14, PlayerClips.SIDE_KICK_R, 1, 2).move(1, 1.6F, 0, 3).defeat(1, ActorClips.FALL_SPIN, 4, HEAVY, 2.8F));
        st.add(turn(18, PlayerClips.BACKFLIP, 0, 3).move(0, 1.4F, 0, 4).act(0, ActorClips.PUNCH, 0).fx(0, MISS, 6));
        st.add(s(11, PlayerClips.CROSS_R, 0).move(0, 1.3F, 0, 3).act(0, ActorClips.HIT, 2, HIT));
        st.add(turn(12, PlayerClips.HOOK_L, 4, 2).move(4, 1.4F, 0, 3).act(4, ActorClips.HIT, 3, HIT));
        st.add(turn(14, PlayerClips.BLOCK, 3, 3).move(3, 1.5F, 0, 4).act(3, ActorClips.KICK, 0).act(4, ActorClips.PUNCH, 1)
                .fx(3, PLAYER_BLOCK, 6).fx(4, MISS, 7));
        st.add(s(11, PlayerClips.KNEE_R, 3).act(3, ActorClips.HIT_BODY, 3, HIT));
        st.add(s(11, PlayerClips.ELBOW_R, 3).defeat(3, ActorClips.FALL_FORWARD, 2, HEAVY, 1.8F));
        st.add(turn(12, PlayerClips.FRONT_KICK_R, 4, 2).act(4, ActorClips.STAGGER, 3, HEAVY).move(4, 1.6F, 3, 4));
        // Finalização: chute giratório saltado derruba os dois últimos adversários.
        st.add(turn(22, PlayerClips.JUMP_SPIN_KICK, 0, 3).move(0, 1.6F, 0, 4).move(4, 1.6F, 0, 4)
                .defeat(4, ActorClips.FALL_SPIN, 6, HEAVY, 3.0F)
                .defeat(0, ActorClips.FALL_BACK, 8, HEAVY, 3.1F));
        return new Choreography(TaijutsuMode.ONE_V_FIVE, new float[]{0F, 72F, 144F, 216F, 288F}, 3.0F, st);
    }
}
