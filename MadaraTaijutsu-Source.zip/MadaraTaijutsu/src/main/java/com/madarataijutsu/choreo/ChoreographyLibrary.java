package com.madarataijutsu.choreo;

import com.madarataijutsu.anim.Clip;
import com.madarataijutsu.mode.TaijutsuMode;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import static com.madarataijutsu.choreo.ImpactType.ACTOR_BLOCK;
import static com.madarataijutsu.choreo.ImpactType.HEAVY;
import static com.madarataijutsu.choreo.ImpactType.HIT;
import static com.madarataijutsu.choreo.ImpactType.MISS;
import static com.madarataijutsu.choreo.ImpactType.PLAYER_BLOCK;

/**
 * Gerenciador de coreografias: uma sequência própria para cada modo.
 *
 * Distâncias (blocos): 1.4 alcance de soco, 1.6 alcance de chute,
 * 2.0+ adversário empurrado, 2.6+ lançado ao chão.
 */
public final class ChoreographyLibrary {

    private static final Map<TaijutsuMode, List<Choreography>> CACHE =
            new EnumMap<TaijutsuMode, List<Choreography>>(TaijutsuMode.class);

    private ChoreographyLibrary() {
    }

    /** Todas as variações de um modo. */
    public static synchronized List<Choreography> variants(TaijutsuMode mode) {
        List<Choreography> list = CACHE.get(mode);
        if (list == null) {
            list = Collections.unmodifiableList(create(mode));
            CACHE.put(mode, list);
        }
        return list;
    }

    /** Primeira variação (usada em testes e na pré-visualização). */
    public static Choreography get(TaijutsuMode mode) {
        return variants(mode).get(0);
    }

    /**
     * Sorteia uma variação diferente da anterior (quando houver mais de uma).
     * @param previous índice da última variação usada, ou -1
     * @return índice sorteado
     */
    public static int pickIndex(TaijutsuMode mode, Random random, int previous) {
        int n = variants(mode).size();
        if (n <= 1) return 0;
        int i = random.nextInt(n - (previous >= 0 && previous < n ? 1 : 0));
        if (previous >= 0 && previous < n && i >= previous) i++;
        return i;
    }

    private static List<Choreography> create(TaijutsuMode mode) {
        List<Choreography> list = new ArrayList<Choreography>();
        switch (mode) {
            case ONE_V_TWO: list.add(oneVsTwo()); break;
            case ONE_V_THREE: list.add(oneVsThree()); break;
            case ONE_V_FOUR: list.add(oneVsFour()); break;
            case ONE_V_FIVE: list.add(oneVsFive()); break;
            case ONE_V_ONE:
            default:
                list.add(oneVsOneLaunch());
                list.add(oneVsOneSlap());
                list.add(oneVsOneGrab());
                list.add(oneVsOneSweep());
                break;
        }
        return list;
    }

    private static Step s(int duration, Clip player, int face) {
        return new Step(duration, player, face, 3);
    }

    private static Step turn(int duration, Clip player, int face, int turnTicks) {
        return new Step(duration, player, face, turnTicks);
    }

    // ------------------------------------------------------------------ 1v1
    // Quatro combos curtos e humilhantes, sorteados a cada ativação.

    private static final float[] SOLO = {0F};
    /** No 1v1 o adversário começa longe: o jogador vai até ele correndo. */
    private static final float SOLO_START = 5.0F;

    /** Corrida ninja até o adversário, que recua assustado. Distância final: ~1.5 bloco. */
    private static Step run() {
        return s(12, PlayerClips.NINJA_RUN, 0).advance(3.6F, 1, 9)
                .act(0, ActorClips.FLINCH_BACK, 3).move(0, 5.1F, 3, 6);
    }

    /** Lançamento: corre -> soco no rosto -> uppercut que o lança reto para cima -> chute giratório no ar. */
    private static Choreography oneVsOneLaunch() {
        List<Step> st = new ArrayList<Step>();
        st.add(run());
        st.add(s(9, PlayerClips.CROSS_R, 0).advance(3.75F, 0, 3).act(0, ActorClips.HIT, 2, HIT));
        st.add(s(8, PlayerClips.UPPERCUT_R, 0).advance(3.8F, 0, 3).act(0, ActorClips.LAUNCH_UP, 3, HEAVY).chain());
        st.add(s(24, PlayerClips.AIR_KICK, 0).defeat(0, ActorClips.FLY_AWAY, 8, HEAVY, 12.0F, 11));
        return new Choreography(TaijutsuMode.ONE_V_ONE, "Lan\u00e7amento", SOLO, SOLO_START, st);
    }

    /** Tapa: corre -> desvia só com a cabeça -> tapa que o vira de costas -> chute nas costas. */
    private static Choreography oneVsOneSlap() {
        List<Step> st = new ArrayList<Step>();
        st.add(run());
        st.add(s(13, PlayerClips.SLIP, 0).advance(3.65F, 0, 3).act(0, ActorClips.PUNCH, 0).fx(0, MISS, 6));
        st.add(s(12, PlayerClips.BACKHAND_L, 0).advance(3.8F, 0, 3).act(0, ActorClips.HIT_SPIN, 4, HIT));
        st.add(s(18, PlayerClips.FRONT_KICK_R, 0).advance(4.0F, 0, 3)
                .defeat(0, ActorClips.FALL_FACE_AWAY, 3, HEAVY, 8.0F, 8));
        return new Choreography(TaijutsuMode.ONE_V_ONE, "Tapa", SOLO, SOLO_START, st);
    }

    /** Agarrão: corre -> desvia do soco -> agarra pela gola e ergue -> arremessa longe. */
    private static Choreography oneVsOneGrab() {
        List<Step> st = new ArrayList<Step>();
        st.add(run());
        st.add(s(13, PlayerClips.DODGE_RIGHT, 0).advance(3.65F, 0, 3).act(0, ActorClips.PUNCH, 0).fx(0, MISS, 6));
        st.add(s(10, PlayerClips.GRAB_LIFT, 0).advance(3.85F, 0, 3).move(0, 4.7F, 1, 3)
                .act(0, ActorClips.LIFTED, 2, HIT).chain());
        st.add(s(20, PlayerClips.THROW_R, 0).defeat(0, ActorClips.THROWN, 5, HEAVY, 11.0F, 12));
        return new Choreography(TaijutsuMode.ONE_V_ONE, "Agarr\u00e3o", SOLO, SOLO_START, st);
    }

    /** Rasteira: corre -> palma no peito -> rasteira quando ele avança -> ergue do chão e arremessa. */
    private static Choreography oneVsOneSweep() {
        List<Step> st = new ArrayList<Step>();
        st.add(run());
        st.add(s(11, PlayerClips.PALM_R, 0).advance(3.75F, 0, 3).act(0, ActorClips.STAGGER, 2, HIT)
                .move(0, 5.6F, 2, 6));
        st.add(s(15, PlayerClips.LOW_SWEEP, 0).advance(3.95F, 0, 4).move(0, 5.25F, 0, 5)
                .act(0, ActorClips.PUNCH, 0).act(0, ActorClips.SWEPT, 5, HEAVY));
        st.add(s(10, PlayerClips.GRAB_FROM_GROUND, 0).advance(4.15F, 0, 4).move(0, 5.0F, 3, 5)
                .act(0, ActorClips.PICKED_UP, 3).chain());
        st.add(s(20, PlayerClips.THROW_R, 0).defeat(0, ActorClips.THROWN, 5, HEAVY, 11.5F, 12));
        return new Choreography(TaijutsuMode.ONE_V_ONE, "Rasteira", SOLO, SOLO_START, st);
    }

    // ------------------------------------------------------------------ 1v2
    /** Alternância: frente e costas, desvios laterais e chutes no segundo adversário. */
    private static Choreography oneVsTwo() {
        List<Step> st = new ArrayList<Step>();
        st.add(s(14, null, 0).approach(0, 1.4F, 0).approach(1, 1.6F, 2));
        st.add(s(10, PlayerClips.JAB_L, 0).act(0, ActorClips.HIT, 2, HIT));
        st.add(turn(14, PlayerClips.DODGE_LEFT, 1, 3).act(1, ActorClips.PUNCH, 0).fx(1, MISS, 6));
        st.add(s(11, PlayerClips.ELBOW_R, 1).move(1, 1.4F, 0, 3).act(1, ActorClips.HIT, 2, HIT));
        st.add(turn(11, PlayerClips.CROSS_R, 0, 2).act(0, ActorClips.BLOCK, 1, ACTOR_BLOCK));
        st.add(turn(14, PlayerClips.SIDE_KICK_R, 1, 2).act(1, ActorClips.STAGGER, 4, HEAVY).move(1, 2.1F, 4, 6));
        st.add(turn(14, PlayerClips.LEAN_BACK, 0, 3).act(0, ActorClips.KICK, 0).fx(0, MISS, 6));
        st.add(s(12, PlayerClips.HOOK_R, 0).act(0, ActorClips.HIT, 3, HIT));
        st.add(turn(13, PlayerClips.BLOCK, 1, 3).move(1, 1.4F, 0, 5).act(1, ActorClips.PUNCH, 0).fx(1, PLAYER_BLOCK, 6));
        st.add(s(12, PlayerClips.UPPERCUT_R, 1).act(1, ActorClips.HIT, 3, HEAVY));
        st.add(turn(13, PlayerClips.FRONT_KICK_R, 0, 2).defeat(0, ActorClips.FALL_BACK, 3, HEAVY, 2.7F));
        st.add(turn(18, PlayerClips.SPIN_KICK, 1, 3).defeat(1, ActorClips.FALL_SPIN, 6, HEAVY, 2.9F));
        return new Choreography(TaijutsuMode.ONE_V_TWO, new float[]{0F, 180F}, 3.0F, st);
    }

    // ------------------------------------------------------------------ 1v3
    /** Mobilidade: ataques multidirecionais, cotoveladas, giros e esquivas coordenadas. */
    private static Choreography oneVsThree() {
        List<Step> st = new ArrayList<Step>();
        // Etapa 1: o primeiro adversário avança.
        st.add(s(14, null, 0).approach(0, 1.4F, 0));
        // Etapa 2: soco do jogador, o adversário reage.
        st.add(s(10, PlayerClips.CROSS_R, 0).act(0, ActorClips.HIT, 2, HIT));
        // Etapa 3: o segundo adversário ataca, o jogador esquiva.
        st.add(turn(14, PlayerClips.DODGE_LEFT, 1, 3).move(1, 1.5F, 0, 5).act(1, ActorClips.PUNCH, 0).fx(1, MISS, 6));
        // Etapa 4: contra-ataque com chute.
        st.add(s(12, PlayerClips.FRONT_KICK_R, 1).act(1, ActorClips.STAGGER, 3, HEAVY).move(1, 2.1F, 3, 6));
        // Etapa 5: o terceiro adversário se aproxima.
        st.add(turn(14, null, 2, 4).approach(2, 1.6F, 0));
        // Etapa 6: giro atingindo o terceiro adversário.
        st.add(s(16, PlayerClips.SPIN_KICK, 2).act(2, ActorClips.STAGGER, 6, HEAVY).move(2, 2.0F, 6, 6));
        // Etapa 7+: sequência coordenada com os restantes.
        st.add(turn(11, PlayerClips.ELBOW_R, 0, 2).act(0, ActorClips.HIT, 2, HIT).move(1, 1.5F, 2, 8));
        st.add(turn(12, PlayerClips.HOOK_L, 1, 2).act(1, ActorClips.BLOCK, 2, ACTOR_BLOCK).move(2, 1.5F, 0, 8));
        st.add(s(14, PlayerClips.BLOCK, 1).act(1, ActorClips.KICK, 0).act(2, ActorClips.PUNCH, 0)
                .fx(1, PLAYER_BLOCK, 6).fx(2, MISS, 6));
        st.add(turn(12, PlayerClips.UPPERCUT_R, 2, 2).defeat(2, ActorClips.FALL_BACK, 3, HEAVY, 2.6F));
        st.add(turn(14, PlayerClips.SIDE_KICK_R, 0, 2).act(0, ActorClips.STAGGER, 4, HEAVY).move(0, 1.9F, 4, 6));
        st.add(turn(11, PlayerClips.KNEE_R, 1, 2).act(1, ActorClips.HIT_BODY, 3, HIT));
        st.add(turn(12, PlayerClips.HOOK_R, 0, 2).move(0, 1.4F, 0, 3).defeat(0, ActorClips.FALL_FORWARD, 3, HEAVY, 1.9F));
        // Etapa final: giro derruba o último adversário.
        st.add(turn(18, PlayerClips.SPIN_KICK, 1, 3).defeat(1, ActorClips.FALL_SPIN, 6, HEAVY, 2.9F));
        return new Choreography(TaijutsuMode.ONE_V_THREE, new float[]{0F, 120F, 240F}, 3.0F, st);
    }

    // ------------------------------------------------------------------ 1v4
    /** Combate avançado: giros corporais, acrobacias, contra-ataques em sequência. */
    private static Choreography oneVsFour() {
        List<Step> st = new ArrayList<Step>();
        st.add(s(18, null, 0).approach(0, 1.4F, 0).approach(1, 1.6F, 2).approach(2, 1.6F, 4).approach(3, 1.6F, 6));
        st.add(s(10, PlayerClips.JAB_L, 0).act(0, ActorClips.HIT, 2, HIT));
        st.add(s(11, PlayerClips.CROSS_R, 0).act(0, ActorClips.STAGGER, 2, HEAVY).move(0, 2.0F, 2, 6));
        st.add(turn(13, PlayerClips.BLOCK, 1, 3).move(1, 1.4F, 0, 4).act(1, ActorClips.PUNCH, 0).fx(1, PLAYER_BLOCK, 6));
        st.add(s(11, PlayerClips.ELBOW_R, 1).act(1, ActorClips.HIT, 2, HIT));
        st.add(turn(18, PlayerClips.BACKFLIP, 2, 3).act(2, ActorClips.KICK, 0).fx(2, MISS, 6));
        st.add(s(12, PlayerClips.FRONT_KICK_R, 2).act(2, ActorClips.STAGGER, 3, HEAVY).move(2, 2.1F, 3, 6));
        st.add(turn(14, PlayerClips.LEAN_BACK, 3, 3).move(3, 1.4F, 0, 4).act(3, ActorClips.PUNCH, 0).fx(3, MISS, 6));
        st.add(s(12, PlayerClips.HOOK_L, 3).act(3, ActorClips.HIT, 3, HIT));
        st.add(turn(14, PlayerClips.SIDE_KICK_R, 0, 2).move(0, 1.6F, 0, 3).act(0, ActorClips.STAGGER, 4, HEAVY).move(0, 2.0F, 4, 6));
        st.add(turn(15, PlayerClips.DODGE_RIGHT, 1, 3).move(2, 1.5F, 0, 5).act(1, ActorClips.KICK, 0)
                .act(2, ActorClips.PUNCH, 1).fx(1, MISS, 6).fx(2, MISS, 7));
        st.add(s(12, PlayerClips.UPPERCUT_R, 1).defeat(1, ActorClips.FALL_BACK, 3, HEAVY, 2.6F));
        st.add(turn(12, PlayerClips.HOOK_R, 2, 2).act(2, ActorClips.HIT, 3, HIT));
        st.add(s(18, PlayerClips.JUMP_SPIN_KICK, 2).defeat(2, ActorClips.FALL_SPIN, 8, HEAVY, 3.0F));
        st.add(turn(11, PlayerClips.KNEE_R, 3, 2).move(3, 1.4F, 0, 3).act(3, ActorClips.HIT_BODY, 3, HIT));
        st.add(s(11, PlayerClips.ELBOW_R, 3).defeat(3, ActorClips.FALL_FORWARD, 2, HEAVY, 1.8F));
        st.add(turn(18, PlayerClips.SPIN_KICK, 0, 3).move(0, 1.6F, 0, 4).defeat(0, ActorClips.FALL_BACK, 6, HEAVY, 2.9F));
        return new Choreography(TaijutsuMode.ONE_V_FOUR, new float[]{0F, 90F, 180F, 270F}, 3.0F, st);
    }

    // ------------------------------------------------------------------ 1v5
    /** Cinematográfico: ataques coordenados, mudanças rápidas de direção, finalização dupla. */
    private static Choreography oneVsFive() {
        List<Step> st = new ArrayList<Step>();
        st.add(s(20, null, 0).approach(0, 1.4F, 0).approach(1, 1.7F, 2).approach(2, 1.8F, 4)
                .approach(3, 1.8F, 6).approach(4, 1.7F, 7));
        st.add(s(10, PlayerClips.JAB_L, 0).act(0, ActorClips.HIT, 2, HIT));
        st.add(s(12, PlayerClips.HOOK_R, 0).act(0, ActorClips.STAGGER, 3, HEAVY).move(0, 2.1F, 3, 6));
        st.add(turn(14, PlayerClips.LEAN_BACK, 1, 3).move(1, 1.4F, 0, 4).act(1, ActorClips.PUNCH, 0).fx(1, MISS, 6));
        st.add(s(11, PlayerClips.ELBOW_R, 1).act(1, ActorClips.HIT, 2, HIT));
        st.add(turn(15, PlayerClips.DODGE_LEFT, 4, 3).move(4, 1.5F, 0, 4).move(3, 1.5F, 0, 4)
                .act(4, ActorClips.KICK, 0).act(3, ActorClips.PUNCH, 1).fx(4, MISS, 6).fx(3, MISS, 7));
        st.add(s(12, PlayerClips.FRONT_KICK_R, 4).act(4, ActorClips.STAGGER, 3, HEAVY).move(4, 2.1F, 3, 6));
        st.add(turn(16, PlayerClips.SPIN_KICK, 3, 2).act(3, ActorClips.STAGGER, 6, HEAVY).move(3, 2.0F, 6, 6));
        st.add(turn(13, PlayerClips.BLOCK, 2, 3).move(2, 1.4F, 0, 4).act(2, ActorClips.PUNCH, 0).fx(2, PLAYER_BLOCK, 6));
        st.add(s(12, PlayerClips.UPPERCUT_R, 2).defeat(2, ActorClips.FALL_BACK, 3, HEAVY, 2.6F));
        st.add(turn(14, PlayerClips.SIDE_KICK_R, 1, 2).move(1, 1.6F, 0, 3).defeat(1, ActorClips.FALL_SPIN, 4, HEAVY, 2.8F));
        st.add(turn(18, PlayerClips.BACKFLIP, 0, 3).move(0, 1.4F, 0, 4).act(0, ActorClips.PUNCH, 0).fx(0, MISS, 6));
        st.add(s(11, PlayerClips.CROSS_R, 0).move(0, 1.45F, 0, 3).act(0, ActorClips.HIT, 2, HIT));
        st.add(turn(12, PlayerClips.HOOK_L, 4, 2).move(4, 1.4F, 0, 3).act(4, ActorClips.HIT, 3, HIT));
        st.add(turn(14, PlayerClips.BLOCK, 3, 3).move(3, 1.5F, 0, 4).act(3, ActorClips.KICK, 0).act(4, ActorClips.PUNCH, 1)
                .fx(3, PLAYER_BLOCK, 6).fx(4, MISS, 7));
        st.add(s(11, PlayerClips.KNEE_R, 3).act(3, ActorClips.HIT_BODY, 3, HIT));
        st.add(s(11, PlayerClips.ELBOW_R, 3).defeat(3, ActorClips.FALL_FORWARD, 2, HEAVY, 1.8F));
        st.add(turn(12, PlayerClips.FRONT_KICK_R, 4, 2).act(4, ActorClips.STAGGER, 3, HEAVY).move(4, 1.6F, 3, 4));
        // Finalização: chute giratório saltado derruba os dois últimos adversários.
        st.add(turn(22, PlayerClips.JUMP_SPIN_KICK, 0, 3).move(0, 1.6F, 0, 4).move(4, 1.6F, 0, 4)
                .defeat(4, ActorClips.FALL_SPIN, 6, HEAVY, 3.0F)
                .defeat(0, ActorClips.FALL_BACK, 8, HEAVY, 3.1F));
        return new Choreography(TaijutsuMode.ONE_V_FIVE, new float[]{0F, 72F, 144F, 216F, 288F}, 3.0F, st);
    }
}
