package com.madarataijutsu.choreo;

import com.madarataijutsu.anim.Clip;
import com.madarataijutsu.mode.TaijutsuMode;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import static com.madarataijutsu.choreo.ImpactType.HEAVY;
import static com.madarataijutsu.choreo.ImpactType.HIT;
import static com.madarataijutsu.choreo.ImpactType.MISS;

/**
 * Gerenciador de coreografias.
 *
 * Estilo: ofensivo. Cada clique dispara uma RAJADA de 2-3 golpes encadeados
 * (socos e chutes) e o adversário reage a cada um. Os golpes se sobrepõem
 * levemente (o próximo começa logo após o impacto do anterior) para fluir.
 *
 * Distâncias em blocos. No 1v1 o jogador corre até o adversário e o pressiona:
 * os raios são medidos da posição real e o jogador avança junto.
 */
public final class ChoreographyLibrary {

    private static final Map<TaijutsuMode, List<Choreography>> CACHE =
            new EnumMap<TaijutsuMode, List<Choreography>>(TaijutsuMode.class);

    private ChoreographyLibrary() {
    }

    /** Todas as variações de um modo. */
    public static synchronized List<Choreography> variants(TaijutsuMode mode) {
        List<Choreography> list = CACHE.get(mode);
        if (list == null) {
            list = Collections.unmodifiableList(create(mode));
            CACHE.put(mode, list);
        }
        return list;
    }

    /** Primeira variação (testes e pré-visualização). */
    public static Choreography get(TaijutsuMode mode) {
        return variants(mode).get(0);
    }

    /** Sorteia uma variação diferente da anterior (quando houver mais de uma). */
    public static int pickIndex(TaijutsuMode mode, Random random, int previous) {
        int n = variants(mode).size();
        if (n <= 1) return 0;
        boolean valid = previous >= 0 && previous < n;
        int i = random.nextInt(n - (valid ? 1 : 0));
        if (valid && i >= previous) i++;
        return i;
    }

    private static List<Choreography> create(TaijutsuMode mode) {
        List<Choreography> list = new ArrayList<Choreography>();
        switch (mode) {
            case ONE_V_TWO: list.add(oneVsTwo()); break;
            case ONE_V_THREE: list.add(oneVsThree()); break;
            case ONE_V_FOUR: list.add(oneVsFour()); break;
            case ONE_V_FIVE: list.add(oneVsFive()); break;
            case ONE_V_ONE:
            default:
                list.add(soloLaunch());
                list.add(soloStorm());
                list.add(soloKicks());
                list.add(soloHumiliation());
                break;
        }
        return list;
    }

    // =================================================================== golpes

    /** Dados de cada golpe: frame de impacto, duração total, reação padrão e empurrão. */
    private static final class Strike {
        final int impact;
        final int full;
        final Clip reaction;
        final ImpactType type;
        final float push;

        Strike(int impact, int full, Clip reaction, ImpactType type, float push) {
            this.impact = impact;
            this.full = full;
            this.reaction = reaction;
            this.type = type;
            this.push = push;
        }
    }

    private static final Map<Clip, Strike> STRIKES = new HashMap<Clip, Strike>();

    static {
        STRIKES.put(PlayerClips.JAB_L, new Strike(2, 8, ActorClips.HIT, HIT, 0.1F));
        STRIKES.put(PlayerClips.CROSS_R, new Strike(2, 9, ActorClips.HIT, HIT, 0.15F));
        STRIKES.put(PlayerClips.HOOK_L, new Strike(3, 10, ActorClips.HIT, HIT, 0.12F));
        STRIKES.put(PlayerClips.HOOK_R, new Strike(3, 10, ActorClips.HIT, HIT, 0.12F));
        STRIKES.put(PlayerClips.UPPERCUT_R, new Strike(3, 11, ActorClips.HIT, HEAVY, 0.15F));
        STRIKES.put(PlayerClips.ELBOW_R, new Strike(2, 9, ActorClips.HIT, HEAVY, 0.12F));
        STRIKES.put(PlayerClips.KNEE_R, new Strike(3, 10, ActorClips.HIT_BODY, HEAVY, 0.1F));
        STRIKES.put(PlayerClips.PALM_R, new Strike(2, 10, ActorClips.STAGGER, HIT, 0.35F));
        STRIKES.put(PlayerClips.BACKHAND_L, new Strike(4, 12, ActorClips.HIT, HIT, 0.1F));
        STRIKES.put(PlayerClips.LOW_KICK_R, new Strike(3, 9, ActorClips.HIT_BODY, HIT, 0.1F));
        STRIKES.put(PlayerClips.FRONT_KICK_R, new Strike(3, 10, ActorClips.STAGGER, HEAVY, 0.4F));
        STRIKES.put(PlayerClips.ROUNDHOUSE_R, new Strike(4, 11, ActorClips.STAGGER, HEAVY, 0.35F));
        STRIKES.put(PlayerClips.SIDE_KICK_R, new Strike(4, 13, ActorClips.STAGGER, HEAVY, 0.55F));
        STRIKES.put(PlayerClips.SPIN_KICK, new Strike(6, 13, ActorClips.STAGGER, HEAVY, 0.5F));
        STRIKES.put(PlayerClips.JUMP_SPIN_KICK, new Strike(8, 17, ActorClips.STAGGER, HEAVY, 0.5F));
    }

    private static Strike info(Clip c) {
        Strike s = STRIKES.get(c);
        if (s == null) throw new IllegalArgumentException("golpe sem dados: " + c.name);
        return s;
    }

    /** Distância de contato para cada golpe. */
    private static final float REACH = 1.4F;

    // ===================================================== construtor de lutas

    /**
     * Monta uma luta acompanhando a distância de cada adversário, para que todos
     * os golpes conectem: o alvo é trazido para o alcance (ou, no 1v1, o
     * jogador avança até ele) e é empurrado a cada impacto.
     */
    private static final class Fight {
        final TaijutsuMode mode;
        final float[] angles;
        final float[] r;
        final boolean pressing;
        final List<Step> st = new ArrayList<Step>();
        float adv;
        int face = 0;

        Fight(TaijutsuMode mode, float[] angles, float start, boolean pressing) {
            this.mode = mode;
            this.angles = angles;
            this.r = new float[angles.length];
            for (int i = 0; i < r.length; i++) r[i] = start;
            this.pressing = pressing;
        }

        private float dist(int t) {
            return r[t] - (pressing && t == 0 ? adv : 0.0F);
        }

        /** Garante o alcance antes do golpe (o jogador avança no 1v1; o ator vem nos demais). */
        private void engage(Step s, int t, float reach, int ticks) {
            if (Math.abs(dist(t) - reach) < 0.05F) return;
            if (pressing && t == 0) {
                adv = r[t] - reach;
                s.advance(adv, 0, ticks);
            } else {
                boolean far = Math.abs(r[t] - reach) > 0.35F;
                r[t] = reach;
                // Distâncias maiores: o adversário volta caminhando para a luta.
                s.move(t, reach, 0, far ? Math.max(ticks, 5) : ticks);
                if (far) s.act(t, ActorClips.ADVANCE, 0);
            }
        }

        private Step step(int duration, Clip playerClip, int target) {
            int turn = target == face ? 3 : 2;
            face = target;
            return new Step(duration, playerClip, target, turn);
        }

        /** Corrida ninja até o adversário 0 (1v1). */
        Fight run() {
            Step s = step(12, PlayerClips.NINJA_RUN, 0);
            r[0] += 0.1F;
            adv = r[0] - 1.5F;
            s.advance(adv, 1, 9).act(0, ActorClips.FLINCH_BACK, 3).move(0, r[0], 3, 6);
            st.add(s);
            return this;
        }

        /** Todos os adversários avançam até a distância indicada. */
        Fight approachAll(float radius) {
            Step s = step(14 + 2 * angles.length, null, 0);
            for (int i = 0; i < angles.length; i++) {
                r[i] = radius;
                s.approach(i, radius, i * 2);
            }
            st.add(s);
            return this;
        }

        /** Rajada de golpes no alvo: os primeiros encadeiam sozinhos, o último espera o clique. */
        Fight flurry(int target, Clip... clips) {
            for (int i = 0; i < clips.length; i++) {
                strike(target, clips[i], i < clips.length - 1);
            }
            return this;
        }

        Fight strike(int target, Clip clip, boolean chain) {
            Strike k = info(clip);
            int dur = chain ? Math.max(5, k.impact + 3) : k.full;
            Step s = step(dur, clip, target);
            engage(s, target, REACH, Math.min(3, k.impact));
            s.act(target, k.reaction, k.impact, k.type);
            if (k.push > 0) {
                r[target] += k.push;
                s.move(target, r[target], k.impact, 5);
                if (pressing && target == 0) {
                    adv += k.push;
                    s.advance(adv, k.impact, 6);
                }
            }
            if (chain) s.chain();
            st.add(s);
            return this;
        }

        /** O alvo ataca e o jogador se esquiva (o jogador continua no ataque logo depois). */
        Fight dodge(int target, Clip playerClip, Clip attack) {
            Step s = step(12, playerClip, target);
            engage(s, target, 1.5F, 3);
            s.act(target, attack, 0).fx(target, MISS, 6);
            st.add(s);
            return this;
        }

        /** Golpe final: o alvo é derrotado e arremessado. */
        Fight finish(int target, Clip clip, Clip fall, float throwDistance, int flightTicks) {
            Strike k = info(clip);
            Step s = step(k.full + 6, clip, target);
            engage(s, target, REACH, Math.min(3, k.impact));
            r[target] += throwDistance;
            s.defeat(target, fall, k.impact, HEAVY, r[target], flightTicks);
            st.add(s);
            return this;
        }

        /** Uppercut que lança o alvo reto para cima + salto com chute giratório no ar. */
        Fight launchFinish(int target) {
            Step up = step(8, PlayerClips.UPPERCUT_R, target);
            engage(up, target, 1.3F, 3);
            up.act(target, ActorClips.LAUNCH_UP, 3, HEAVY).chain();
            st.add(up);
            Step kick = step(24, PlayerClips.AIR_KICK, target);
            r[target] += 7.5F;
            kick.defeat(target, ActorClips.FLY_AWAY, 8, HEAVY, r[target], 11);
            st.add(kick);
            return this;
        }

        Choreography done(String name, float start) {
            return new Choreography(mode, name, angles, start, st);
        }
    }

    // =================================================================== 1v1

    private static final float[] SOLO = {0F};
    private static final float SOLO_START = 5.0F;

    private static Fight solo() {
        return new Fight(TaijutsuMode.ONE_V_ONE, SOLO, SOLO_START, true).run();
    }

    /** Lançamento: jab-direto-gancho, chute baixo + frontal, direto e uppercut que lança, chute aéreo. */
    private static Choreography soloLaunch() {
        return solo()
                .flurry(0, PlayerClips.JAB_L, PlayerClips.CROSS_R, PlayerClips.HOOK_L)
                .flurry(0, PlayerClips.LOW_KICK_R, PlayerClips.HOOK_R, PlayerClips.FRONT_KICK_R)
                .strike(0, PlayerClips.CROSS_R, true)
                .launchFinish(0)
                .done("Lançamento", SOLO_START);
    }

    /** Tempestade: rajadas de socos e cotovelada, joelhada, chute circular e giratório final. */
    private static Choreography soloStorm() {
        return solo()
                .flurry(0, PlayerClips.JAB_L, PlayerClips.JAB_L, PlayerClips.CROSS_R)
                .flurry(0, PlayerClips.HOOK_R, PlayerClips.ELBOW_R, PlayerClips.KNEE_R)
                .flurry(0, PlayerClips.HOOK_L, PlayerClips.UPPERCUT_R, PlayerClips.ROUNDHOUSE_R)
                .finish(0, PlayerClips.SPIN_KICK, ActorClips.FALL_SPIN, 6.5F, 10)
                .done("Tempestade", SOLO_START);
    }

    /** Chutes: frontal-baixo-circular, chute lateral, socos e chute giratório saltado. */
    private static Choreography soloKicks() {
        return solo()
                .flurry(0, PlayerClips.FRONT_KICK_R, PlayerClips.LOW_KICK_R, PlayerClips.ROUNDHOUSE_R)
                .flurry(0, PlayerClips.LOW_KICK_R, PlayerClips.SIDE_KICK_R)
                .flurry(0, PlayerClips.JAB_L, PlayerClips.CROSS_R, PlayerClips.ROUNDHOUSE_R)
                .finish(0, PlayerClips.JUMP_SPIN_KICK, ActorClips.FALL_SPIN, 7.0F, 11)
                .done("Chutes", SOLO_START);
    }

    /** Humilhação: desvia sem guarda, tapa, rajada, e o derruba com o chute giratório. */
    private static Choreography soloHumiliation() {
        return solo()
                .dodge(0, PlayerClips.SLIP, ActorClips.PUNCH)
                .flurry(0, PlayerClips.BACKHAND_L, PlayerClips.PALM_R)
                .flurry(0, PlayerClips.JAB_L, PlayerClips.HOOK_R, PlayerClips.LOW_KICK_R, PlayerClips.ROUNDHOUSE_R)
                .dodge(0, PlayerClips.LEAN_BACK, ActorClips.KICK)
                .flurry(0, PlayerClips.CROSS_R, PlayerClips.ELBOW_R, PlayerClips.FRONT_KICK_R)
                .finish(0, PlayerClips.SPIN_KICK, ActorClips.FALL_BACK, 6.0F, 9)
                .done("Humilhação", SOLO_START);
    }

    // ============================================================ 1v2 .. 1v5

    private static Choreography oneVsTwo() {
        Fight f = new Fight(TaijutsuMode.ONE_V_TWO, new float[]{0F, 180F}, 3.0F, false).approachAll(1.6F);
        f.flurry(0, PlayerClips.JAB_L, PlayerClips.CROSS_R, PlayerClips.HOOK_L)
                .dodge(1, PlayerClips.DODGE_LEFT, ActorClips.PUNCH)
                .flurry(1, PlayerClips.ELBOW_R, PlayerClips.KNEE_R, PlayerClips.SIDE_KICK_R)
                .flurry(0, PlayerClips.LOW_KICK_R, PlayerClips.HOOK_R, PlayerClips.ROUNDHOUSE_R)
                .flurry(1, PlayerClips.JAB_L, PlayerClips.CROSS_R, PlayerClips.FRONT_KICK_R)
                .strike(0, PlayerClips.UPPERCUT_R, true)
                .finish(0, PlayerClips.ROUNDHOUSE_R, ActorClips.FALL_BACK, 3.5F, 8)
                .strike(1, PlayerClips.HOOK_L, true)
                .finish(1, PlayerClips.SPIN_KICK, ActorClips.FALL_SPIN, 4.5F, 9);
        return f.done(TaijutsuMode.ONE_V_TWO.label, 3.0F);
    }

    private static Choreography oneVsThree() {
        Fight f = new Fight(TaijutsuMode.ONE_V_THREE, new float[]{0F, 120F, 240F}, 3.0F, false).approachAll(1.6F);
        f.flurry(0, PlayerClips.JAB_L, PlayerClips.CROSS_R, PlayerClips.HOOK_L)
                .dodge(1, PlayerClips.DODGE_LEFT, ActorClips.PUNCH)
                .flurry(1, PlayerClips.HOOK_R, PlayerClips.FRONT_KICK_R)
                .flurry(2, PlayerClips.LOW_KICK_R, PlayerClips.ROUNDHOUSE_R)
                .flurry(0, PlayerClips.ELBOW_R, PlayerClips.KNEE_R, PlayerClips.SIDE_KICK_R)
                .dodge(2, PlayerClips.LEAN_BACK, ActorClips.KICK)
                .flurry(2, PlayerClips.JAB_L, PlayerClips.CROSS_R)
                .finish(2, PlayerClips.UPPERCUT_R, ActorClips.FALL_BACK, 3.0F, 8)
                .flurry(1, PlayerClips.JAB_L, PlayerClips.HOOK_R, PlayerClips.ROUNDHOUSE_R)
                .finish(1, PlayerClips.SIDE_KICK_R, ActorClips.FALL_SPIN, 4.0F, 9)
                .flurry(0, PlayerClips.CROSS_R, PlayerClips.HOOK_L)
                .finish(0, PlayerClips.SPIN_KICK, ActorClips.FALL_SPIN, 5.0F, 10);
        return f.done(TaijutsuMode.ONE_V_THREE.label, 3.0F);
    }

    private static Choreography oneVsFour() {
        Fight f = new Fight(TaijutsuMode.ONE_V_FOUR, new float[]{0F, 90F, 180F, 270F}, 3.0F, false).approachAll(1.6F);
        f.flurry(0, PlayerClips.JAB_L, PlayerClips.CROSS_R, PlayerClips.ROUNDHOUSE_R)
                .flurry(1, PlayerClips.HOOK_L, PlayerClips.ELBOW_R, PlayerClips.FRONT_KICK_R)
                .dodge(2, PlayerClips.BACKFLIP, ActorClips.KICK)
                .flurry(2, PlayerClips.LOW_KICK_R, PlayerClips.SIDE_KICK_R)
                .flurry(3, PlayerClips.JAB_L, PlayerClips.HOOK_R, PlayerClips.KNEE_R)
                .finish(3, PlayerClips.ELBOW_R, ActorClips.FALL_FORWARD, 1.2F, 6)
                .flurry(0, PlayerClips.CROSS_R, PlayerClips.HOOK_L)
                .finish(0, PlayerClips.ROUNDHOUSE_R, ActorClips.FALL_BACK, 3.5F, 8)
                .dodge(1, PlayerClips.DODGE_RIGHT, ActorClips.PUNCH)
                .flurry(1, PlayerClips.LOW_KICK_R, PlayerClips.CROSS_R)
                .finish(1, PlayerClips.UPPERCUT_R, ActorClips.FALL_BACK, 3.0F, 8)
                .flurry(2, PlayerClips.JAB_L, PlayerClips.CROSS_R, PlayerClips.HOOK_R)
                .finish(2, PlayerClips.JUMP_SPIN_KICK, ActorClips.FALL_SPIN, 5.0F, 10);
        return f.done(TaijutsuMode.ONE_V_FOUR.label, 3.0F);
    }

    private static Choreography oneVsFive() {
        Fight f = new Fight(TaijutsuMode.ONE_V_FIVE, new float[]{0F, 72F, 144F, 216F, 288F}, 3.0F, false)
                .approachAll(1.7F);
        f.flurry(0, PlayerClips.JAB_L, PlayerClips.CROSS_R, PlayerClips.HOOK_L)
                .flurry(1, PlayerClips.ELBOW_R, PlayerClips.ROUNDHOUSE_R)
                .dodge(4, PlayerClips.DODGE_LEFT, ActorClips.KICK)
                .flurry(4, PlayerClips.LOW_KICK_R, PlayerClips.FRONT_KICK_R)
                .flurry(3, PlayerClips.HOOK_R, PlayerClips.SPIN_KICK)
                .flurry(2, PlayerClips.JAB_L, PlayerClips.CROSS_R)
                .finish(2, PlayerClips.UPPERCUT_R, ActorClips.FALL_BACK, 3.0F, 8)
                .flurry(1, PlayerClips.HOOK_L, PlayerClips.KNEE_R)
                .finish(1, PlayerClips.SIDE_KICK_R, ActorClips.FALL_SPIN, 4.0F, 9)
                .dodge(0, PlayerClips.BACKFLIP, ActorClips.PUNCH)
                .flurry(0, PlayerClips.CROSS_R, PlayerClips.LOW_KICK_R, PlayerClips.HOOK_R)
                .finish(0, PlayerClips.ROUNDHOUSE_R, ActorClips.FALL_BACK, 3.5F, 8)
                .flurry(3, PlayerClips.JAB_L, PlayerClips.ELBOW_R)
                .finish(3, PlayerClips.KNEE_R, ActorClips.FALL_FORWARD, 1.2F, 6)
                .flurry(4, PlayerClips.JAB_L, PlayerClips.CROSS_R, PlayerClips.HOOK_L)
                .finish(4, PlayerClips.JUMP_SPIN_KICK, ActorClips.FALL_SPIN, 5.5F, 11);
        return f.done(TaijutsuMode.ONE_V_FIVE.label, 3.0F);
    }

    /** Usado por {@link Choreography} em testes: lista de golpes com dados. */
    static boolean isStrike(Clip c) {
        return STRIKES.containsKey(c);
    }
}
