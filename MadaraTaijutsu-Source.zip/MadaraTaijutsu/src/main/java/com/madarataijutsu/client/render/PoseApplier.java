package com.madarataijutsu.client.render;

import com.madarataijutsu.anim.Pose;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.util.math.MathHelper;

/**
 * Aplica uma {@link Pose} às partes de um ModelPlayer, incluindo as camadas
 * externas da skin (chapéu, jaqueta, mangas, calças), que copiam os ângulos
 * das partes internas.
 */
public final class PoseApplier {

    private static final float DEG = (float) (Math.PI / 180.0);

    private PoseApplier() {
    }

    public static void apply(ModelPlayer m, Pose p, float armPivotY) {
        set(m.bipedHead, p, Pose.HEAD, 0.0F, 0.0F, 0.0F, 0.0F);
        set(m.bipedBody, p, Pose.BODY, 0.0F, 0.0F, 0.0F, 0.0F);

        // Torção do tronco leva os ombros junto (mesma regra do ModelBiped vanilla).
        float bodyYaw = p.get(Pose.BODY + 1) * DEG;
        float cos = MathHelper.cos(bodyYaw);
        float sin = MathHelper.sin(bodyYaw);
        set(m.bipedRightArm, p, Pose.R_ARM, -cos * 5.0F, armPivotY, sin * 5.0F, bodyYaw);
        set(m.bipedLeftArm, p, Pose.L_ARM, cos * 5.0F, armPivotY, -sin * 5.0F, bodyYaw);

        set(m.bipedRightLeg, p, Pose.R_LEG, -1.9F, 12.0F, 0.0F, 0.0F);
        set(m.bipedLeftLeg, p, Pose.L_LEG, 1.9F, 12.0F, 0.0F, 0.0F);

        ModelBase.copyModelAngles(m.bipedHead, m.bipedHeadwear);
        ModelBase.copyModelAngles(m.bipedBody, m.bipedBodyWear);
        ModelBase.copyModelAngles(m.bipedRightArm, m.bipedRightArmwear);
        ModelBase.copyModelAngles(m.bipedLeftArm, m.bipedLeftArmwear);
        ModelBase.copyModelAngles(m.bipedRightLeg, m.bipedRightLegwear);
        ModelBase.copyModelAngles(m.bipedLeftLeg, m.bipedLeftLegwear);
    }

    private static void set(ModelRenderer r, Pose p, int base, float px, float py, float pz, float extraYaw) {
        r.rotationPointX = px;
        r.rotationPointY = py;
        r.rotationPointZ = pz;
        r.rotateAngleX = p.get(base) * DEG;
        r.rotateAngleY = p.get(base + 1) * DEG + extraYaw;
        r.rotateAngleZ = p.get(base + 2) * DEG;
    }
}
