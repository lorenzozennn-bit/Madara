package com.madarataijutsu.client;

import com.madarataijutsu.choreo.ImpactType;
import com.madarataijutsu.combat.SceneFx;
import com.madarataijutsu.combat.VirtualActor;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;

/**
 * Efeitos locais da cena: sons e partículas tocados apenas no cliente
 * (WorldClient), sem pacotes e sem efeito no servidor.
 */
final class ClientSceneFx implements SceneFx {

    private final TaijutsuSession session;
    private final double[] pos = new double[3];

    ClientSceneFx(TaijutsuSession session) {
        this.session = session;
    }

    @Override
    public void onImpact(VirtualActor actor, ImpactType type) {
        Minecraft mc = Minecraft.getMinecraft();
        WorldClient world = mc.world;
        EntityPlayer player = mc.player;
        if (world == null || player == null) return;

        session.actorWorldPos(actor, 0.0F, pos);
        double hx = (pos[0] + player.posX) * 0.5;
        double hy = player.posY + 1.3;
        double hz = (pos[2] + player.posZ) * 0.5;
        float pitch = 0.9F + world.rand.nextFloat() * 0.25F;

        switch (type) {
            case HIT:
                play(world, hx, hy, hz, SoundEvents.ENTITY_PLAYER_ATTACK_STRONG, 0.8F, pitch);
                burst(world, EnumParticleTypes.CRIT, pos[0], pos[1] + 1.4, pos[2], 6);
                break;
            case HEAVY:
                play(world, hx, hy, hz, SoundEvents.ENTITY_PLAYER_ATTACK_CRIT, 1.0F, pitch * 0.9F);
                play(world, hx, hy, hz, SoundEvents.ENTITY_PLAYER_ATTACK_KNOCKBACK, 0.7F, pitch);
                burst(world, EnumParticleTypes.CRIT, pos[0], pos[1] + 1.2, pos[2], 14);
                world.spawnParticle(EnumParticleTypes.SWEEP_ATTACK, hx, hy - 0.2, hz, 0.0, 0.0, 0.0);
                break;
            case ACTOR_BLOCK:
            case PLAYER_BLOCK:
                play(world, hx, hy, hz, SoundEvents.ITEM_SHIELD_BLOCK, 0.6F, 1.2F + world.rand.nextFloat() * 0.2F);
                break;
            case MISS:
                play(world, hx, hy, hz, SoundEvents.ENTITY_PLAYER_ATTACK_NODAMAGE, 0.7F, 1.3F);
                break;
            case NONE:
            default:
                break;
        }
    }

    @Override
    public void onActorDefeated(VirtualActor actor) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.world == null || mc.player == null) return;
        session.actorWorldPos(actor, 0.0F, pos);
        play(mc.world, pos[0], pos[1], pos[2], SoundEvents.ENTITY_PLAYER_BIG_FALL, 0.9F, 0.8F);
    }

    @Override
    public void onVictory() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.world == null || mc.player == null) return;
        EntityPlayer p = mc.player;
        play(mc.world, p.posX, p.posY, p.posZ, SoundEvents.ENTITY_PLAYER_LEVELUP, 0.35F, 0.6F);
    }

    private static void play(WorldClient world, double x, double y, double z, SoundEvent sound, float volume, float pitch) {
        world.playSound(x, y, z, sound, SoundCategory.PLAYERS, volume, pitch, false);
    }

    private static void burst(WorldClient world, EnumParticleTypes type, double x, double y, double z, int count) {
        for (int i = 0; i < count; i++) {
            double vx = (world.rand.nextDouble() - 0.5) * 0.6;
            double vy = world.rand.nextDouble() * 0.4;
            double vz = (world.rand.nextDouble() - 0.5) * 0.6;
            world.spawnParticle(type, x, y, z, vx, vy, vz);
        }
    }
}
