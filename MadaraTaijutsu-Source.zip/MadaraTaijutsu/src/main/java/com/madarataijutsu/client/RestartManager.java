package com.madarataijutsu.client;

import net.minecraft.client.Minecraft;

/**
 * Gerenciador de reinício: descarta os atores anteriores, reinicia a máquina
 * de estados com o número de adversários do modo atual e reposiciona todos
 * em volta do jogador, à frente da câmera. Nada no mundo real é alterado.
 */
final class RestartManager {

    private RestartManager() {
    }

    static void rebuild(TaijutsuSession session) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.player == null) return;
        session.machine().stop();
        session.resetArena(mc);
    }
}
