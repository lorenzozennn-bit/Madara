package com.madarataijutsu.client;

import com.madarataijutsu.client.render.TaijutsuPlayerRenderer;
import com.madarataijutsu.client.render.VirtualActorRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.gui.inventory.GuiContainerCreative;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.event.world.WorldEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Mouse;

/** Eventos do cliente: ticks, teclas, clique, renderização do jogador e dos atores. */
public final class ClientEventHandler {

    private final VirtualActorRenderer actorRenderer = new VirtualActorRenderer();
    private TaijutsuPlayerRenderer rendererWide;
    private TaijutsuPlayerRenderer rendererSlim;
    private final double[] advanceOffset = new double[2];

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.player != null && mc.world != null) {
            KeyBindings.poll(mc);
        }
        TaijutsuSession.get().clientTick(mc);
    }

    /**
     * Clique esquerdo. O evento não é cancelado e não consome o KeyBinding de
     * ataque, então socos reais, mineração e interações vanilla continuam.
     */
    @SubscribeEvent
    public void onMouse(InputEvent.MouseInputEvent event) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.currentScreen != null || mc.player == null) return;
        if (Mouse.getEventButton() == 0 && Mouse.getEventButtonState()) {
            TaijutsuSession.get().onLeftClick();
        }
    }

    /**
     * Substitui apenas o DESENHO do jogador local por um renderizador próprio
     * enquanto o Taijutsu está ativo. Posição, hitbox e física não são tocadas.
     * Prioridade HIGHEST para cancelar antes que outros mods empilhem matrizes.
     */
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public void onRenderPlayerPre(RenderPlayerEvent.Pre event) {
        if (event.getRenderer() instanceof TaijutsuPlayerRenderer) return; // nosso próprio desenho
        TaijutsuSession session = TaijutsuSession.get();
        if (!session.isEnabled()) return;
        EntityPlayer player = event.getEntityPlayer();
        Minecraft mc = Minecraft.getMinecraft();
        if (player != mc.player || !(player instanceof AbstractClientPlayer)) return;
        // Prévia do jogador no inventário: mantém o desenho vanilla.
        if (mc.currentScreen instanceof GuiInventory || mc.currentScreen instanceof GuiContainerCreative) return;

        AbstractClientPlayer acp = (AbstractClientPlayer) player;
        TaijutsuPlayerRenderer renderer = rendererFor(mc, "slim".equals(acp.getSkinType()));
        event.setCanceled(true);
        float partial = event.getPartialRenderTick();
        session.playerAdvanceOffset(partial, advanceOffset);
        renderer.renderPosed(acp, event.getX() + advanceOffset[0], event.getY(), event.getZ() + advanceOffset[1], partial,
                session.machine().player().pose(session.now(partial), renderer.poseBuffer()),
                session.playerRenderYaw(partial));
    }

    @SubscribeEvent
    public void onRenderWorldLast(RenderWorldLastEvent event) {
        TaijutsuSession session = TaijutsuSession.get();
        if (!session.isEnabled()) return;
        actorRenderer.render(session, event.getPartialTicks());
    }

    @SubscribeEvent
    public void onWorldUnload(WorldEvent.Unload event) {
        if (event.getWorld().isRemote) {
            TaijutsuSession.get().deactivate(true);
        }
    }

    private TaijutsuPlayerRenderer rendererFor(Minecraft mc, boolean slim) {
        if (slim) {
            if (rendererSlim == null) rendererSlim = new TaijutsuPlayerRenderer(mc.getRenderManager(), true);
            return rendererSlim;
        }
        if (rendererWide == null) rendererWide = new TaijutsuPlayerRenderer(mc.getRenderManager(), false);
        return rendererWide;
    }
}
