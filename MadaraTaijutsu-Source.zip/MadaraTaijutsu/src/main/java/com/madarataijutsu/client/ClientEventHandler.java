package com.madarataijutsu.client;

import com.madarataijutsu.client.render.TaijutsuPlayerRenderer;
import com.madarataijutsu.client.render.VirtualActorRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.gui.inventory.GuiContainerCreative;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.event.world.WorldEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Mouse;

/** Eventos do cliente: ticks, teclas, clique, renderização do jogador e dos atores. */
public final class ClientEventHandler {

    private final VirtualActorRenderer actorRenderer = new VirtualActorRenderer();
    private TaijutsuPlayerRenderer rendererWide;
    private TaijutsuPlayerRenderer rendererSlim;
    private final double[] advanceOffset = new double[2];
    private final double[] cameraOffset = new double[2];
    private boolean shadowSuppressed;

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.player != null && mc.world != null) {
            KeyBindings.poll(mc);
        }
        TaijutsuSession.get().clientTick(mc);
    }

    /**
     * Clique esquerdo. O evento não é cancelado e não consome o KeyBinding de
     * ataque, então socos reais, mineração e interações vanilla continuam.
     */
    @SubscribeEvent
    public void onMouse(InputEvent.MouseInputEvent event) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.currentScreen != null || mc.player == null) return;
        if (Mouse.getEventButton() == 0 && Mouse.getEventButtonState()) {
            TaijutsuSession.get().onLeftClick();
        }
    }

    /**
     * Substitui apenas o DESENHO do jogador local por um renderizador próprio
     * enquanto o Taijutsu está ativo. Posição, hitbox e física não são tocadas.
     * Prioridade HIGHEST para cancelar antes que outros mods empilhem matrizes.
     */
    @SubscribeEvent(priority = EventPriority.HIGHEST)
    public void onRenderPlayerPre(RenderPlayerEvent.Pre event) {
        if (event.getRenderer() instanceof TaijutsuPlayerRenderer) return; // nosso próprio desenho
        TaijutsuSession session = TaijutsuSession.get();
        if (!session.isEnabled()) return;
        EntityPlayer player = event.getEntityPlayer();
        Minecraft mc = Minecraft.getMinecraft();
        if (player != mc.player || !(player instanceof AbstractClientPlayer)) return;
        // Prévia do jogador no inventário: mantém o desenho vanilla.
        if (mc.currentScreen instanceof GuiInventory || mc.currentScreen instanceof GuiContainerCreative) return;

        // O desenho real é feito em onRenderWorldLast (sem depender do culling da
        // posição real, que fica para trás quando o personagem avança).
        event.setCanceled(true);
        // Sem sombra na posição real do jogador neste quadro.
        if (mc.getRenderManager().isRenderShadow()) {
            mc.getRenderManager().setRenderShadow(false);
            shadowSuppressed = true;
        }
    }

    /** Restaura a sombra para as demais entidades do quadro. */
    @SubscribeEvent
    public void onRenderLivingPre(RenderLivingEvent.Pre<?> event) {
        if (shadowSuppressed && !(event.getEntity() instanceof EntityPlayer && event.getEntity() == Minecraft.getMinecraft().player)) {
            restoreShadow();
        }
    }

    private void restoreShadow() {
        if (shadowSuppressed) {
            Minecraft.getMinecraft().getRenderManager().setRenderShadow(true);
            shadowSuppressed = false;
        }
    }

    /** Desenha o personagem posado na posição visual (posição real + avanço da coreografia). */
    private void renderPosedPlayer(Minecraft mc, TaijutsuSession session, float partial) {
        if (mc.gameSettings.thirdPersonView == 0 || mc.getRenderViewEntity() != mc.player) return;
        // Com o inventário aberto o desenho vanilla é mantido (evita personagem duplicado).
        if (mc.currentScreen instanceof GuiInventory || mc.currentScreen instanceof GuiContainerCreative) return;
        if (!(mc.player instanceof AbstractClientPlayer)) return;
        AbstractClientPlayer acp = mc.player;
        Entity view = mc.getRenderViewEntity();
        double cx = view.lastTickPosX + (view.posX - view.lastTickPosX) * partial;
        double cy = view.lastTickPosY + (view.posY - view.lastTickPosY) * partial;
        double cz = view.lastTickPosZ + (view.posZ - view.lastTickPosZ) * partial;
        session.playerAdvanceOffset(partial, advanceOffset);
        double x = cx + advanceOffset[0];
        double z = cz + advanceOffset[1];

        TaijutsuPlayerRenderer renderer = rendererFor(mc, "slim".equals(acp.getSkinType()));
        RenderHelper.enableStandardItemLighting();
        mc.entityRenderer.enableLightmap();
        int light = mc.world.getCombinedLight(new BlockPos(x, cy + 1.0, z), 0);
        OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, (float) (light % 65536), (float) (light / 65536));
        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
        try {
            renderer.renderPosed(acp, x - cx, cy - cy, z - cz, partial,
                    session.machine().player().pose(session.now(partial), renderer.poseBuffer()),
                    session.playerRenderYaw(partial));
        } finally {
            mc.entityRenderer.disableLightmap();
            RenderHelper.disableStandardItemLighting();
        }
    }

    /**
     * A câmera acompanha o personagem quando ele corre/avança na coreografia.
     * Aplica as rotações da câmera aqui mesmo, depois desloca a visão pelo
     * avanço visual, e zera as rotações do evento para não aplicá-las duas vezes.
     * A posição real do jogador (e a mira) não muda.
     */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void onCameraSetup(EntityViewRenderEvent.CameraSetup event) {
        TaijutsuSession session = TaijutsuSession.get();
        if (!session.isEnabled()) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.getRenderViewEntity() != mc.player || mc.gameSettings.thirdPersonView == 0) return;
        session.playerAdvanceOffset((float) event.getRenderPartialTicks(), cameraOffset);
        if (cameraOffset[0] == 0.0D && cameraOffset[1] == 0.0D) return;
        GlStateManager.rotate(event.getRoll(), 0.0F, 0.0F, 1.0F);
        GlStateManager.rotate(event.getPitch(), 1.0F, 0.0F, 0.0F);
        GlStateManager.rotate(event.getYaw(), 0.0F, 1.0F, 0.0F);
        GlStateManager.translate(-cameraOffset[0], 0.0D, -cameraOffset[1]);
        event.setRoll(0.0F);
        event.setPitch(0.0F);
        event.setYaw(0.0F);
    }

    @SubscribeEvent
    public void onRenderWorldLast(RenderWorldLastEvent event) {
        restoreShadow();
        TaijutsuSession session = TaijutsuSession.get();
        if (!session.isEnabled()) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.player != null && mc.world != null) {
            renderPosedPlayer(mc, session, event.getPartialTicks());
        }
        actorRenderer.render(session, event.getPartialTicks());
    }

    @SubscribeEvent
    public void onWorldUnload(WorldEvent.Unload event) {
        if (event.getWorld().isRemote) {
            TaijutsuSession.get().deactivate(true);
        }
    }

    private TaijutsuPlayerRenderer rendererFor(Minecraft mc, boolean slim) {
        if (slim) {
            if (rendererSlim == null) rendererSlim = new TaijutsuPlayerRenderer(mc.getRenderManager(), true);
            return rendererSlim;
        }
        if (rendererWide == null) rendererWide = new TaijutsuPlayerRenderer(mc.getRenderManager(), false);
        return rendererWide;
    }
}
