package com.madarataijutsu.client;

import com.madarataijutsu.config.TaijutsuConfig;
import com.madarataijutsu.mode.ModeManager;
import com.madarataijutsu.proxy.CommonProxy;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

public class ClientProxy extends CommonProxy {

    @Override
    public void preInit(FMLPreInitializationEvent event) {
        TaijutsuConfig.load(event.getSuggestedConfigurationFile());
        ModeManager.loadFromConfig();
    }

    @Override
    public void init(FMLInitializationEvent event) {
        KeyBindings.register();
        MinecraftForge.EVENT_BUS.register(new ClientEventHandler());
    }
}
