package com.madarataijutsu.client.render;

import com.madarataijutsu.anim.Pose;
import net.minecraft.client.renderer.GlStateManager;

/**
 * Transformação do corpo inteiro (giros, inclinações, saltos, avanços).
 * Deve ser chamada logo após a rotação de direção da entidade e antes do
 * scale(-1, -1, 1) do modelo. É puramente visual.
 */
public final class RootTransform {

    private RootTransform() {
    }

    public static void apply(Pose p) {
        GlStateManager.translate(p.get(Pose.OFF_X), p.get(Pose.OFF_Y), -p.get(Pose.OFF_F));
        float yaw = p.get(Pose.ROOT_YAW);
        if (yaw != 0.0F) {
            GlStateManager.rotate(yaw, 0.0F, 1.0F, 0.0F);
        }
        float pitch = p.get(Pose.ROOT_PITCH);
        float roll = p.get(Pose.ROOT_ROLL);
        if (pitch != 0.0F || roll != 0.0F) {
            float pivot = p.get(Pose.PIVOT_Y);
            GlStateManager.translate(0.0F, pivot, 0.0F);
            if (pitch != 0.0F) GlStateManager.rotate(-pitch, 1.0F, 0.0F, 0.0F);
            if (roll != 0.0F) GlStateManager.rotate(-roll, 0.0F, 0.0F, 1.0F);
            GlStateManager.translate(0.0F, -pivot, 0.0F);
        }
    }
}
