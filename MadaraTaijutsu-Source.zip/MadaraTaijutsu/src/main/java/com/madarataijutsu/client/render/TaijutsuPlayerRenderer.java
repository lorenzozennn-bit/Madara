package com.madarataijutsu.client.render;

import com.madarataijutsu.anim.Pose;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.client.renderer.entity.layers.LayerCustomHead;

import java.util.List;

/**
 * Renderizador próprio do jogador local durante o Taijutsu. É uma instância
 * separada: os renderizadores vanilla nunca são modificados, então desligar o
 * sistema restaura a renderização original automaticamente.
 */
public class TaijutsuPlayerRenderer extends RenderPlayer {

    private final TaijutsuPlayerModel model;
    private final Pose poseBuffer = new Pose();
    private Pose pose;
    private float renderYaw;

    public TaijutsuPlayerRenderer(RenderManager renderManager, boolean smallArms) {
        super(renderManager, smallArms);
        this.model = new TaijutsuPlayerModel(smallArms);
        this.mainModel = this.model;
        // A camada de cabeça (abóbora, crânios) guarda a referência da cabeça do
        // modelo original; recria apontando para a cabeça animada.
        List<?> layers = this.layerRenderers;
        layers.removeIf(layer -> layer instanceof LayerCustomHead);
        this.addLayer(new LayerCustomHead(this.model.bipedHead));
    }

    public Pose poseBuffer() {
        return poseBuffer;
    }

    public void renderPosed(AbstractClientPlayer player, double x, double y, double z, float partialTicks,
                            Pose pose, float yaw) {
        this.pose = pose;
        this.renderYaw = yaw;
        this.model.setPose(pose);
        try {
            this.doRender(player, x, y, z, player.rotationYaw, partialTicks);
        } finally {
            this.model.setPose(null);
            this.pose = null;
        }
    }

    @Override
    protected void applyRotations(AbstractClientPlayer entityLiving, float ageInTicks, float rotationYaw,
                                  float partialTicks) {
        if (pose == null) {
            super.applyRotations(entityLiving, ageInTicks, rotationYaw, partialTicks);
            return;
        }
        GlStateManager.rotate(180.0F - renderYaw, 0.0F, 1.0F, 0.0F);
        RootTransform.apply(pose);
    }
}
