package com.madarataijutsu.client.render;

import com.madarataijutsu.anim.Pose;
import com.madarataijutsu.client.TaijutsuSession;
import com.madarataijutsu.combat.VirtualActor;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;

/**
 * Desenha os adversários virtuais diretamente no RenderWorldLastEvent.
 * Não existem entidades: nada para colidir, mirar, salvar ou sincronizar.
 */
public final class VirtualActorRenderer {

    private static final ResourceLocation STEVE = new ResourceLocation("textures/entity/steve.png");
    private static final ResourceLocation ALEX = new ResourceLocation("textures/entity/alex.png");
    private static final float MODEL_SCALE = 0.0625F;

    private final ActorModel wide = new ActorModel(false);
    private final ActorModel slim = new ActorModel(true);
    private final Pose pose = new Pose();
    private final double[] pos = new double[3];

    public void render(TaijutsuSession session, float partialTicks) {
        Minecraft mc = Minecraft.getMinecraft();
        Entity view = mc.getRenderViewEntity();
        if (view == null || mc.world == null || mc.player == null) return;
        if (session.machine().actors().isEmpty()) return;

        double cx = view.lastTickPosX + (view.posX - view.lastTickPosX) * partialTicks;
        double cy = view.lastTickPosY + (view.posY - view.lastTickPosY) * partialTicks;
        double cz = view.lastTickPosZ + (view.posZ - view.lastTickPosZ) * partialTicks;
        float now = session.now(partialTicks);

        GlStateManager.pushMatrix();
        RenderHelper.enableStandardItemLighting();
        mc.entityRenderer.enableLightmap();
        GlStateManager.enableTexture2D();
        GlStateManager.enableDepth();
        GlStateManager.depthMask(true);
        GlStateManager.enableAlpha();
        GlStateManager.alphaFunc(516, 0.1F);
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA,
                GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA,
                GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        GlStateManager.enableRescaleNormal();
        GlStateManager.disableCull();

        try {
            for (VirtualActor actor : session.machine().actors()) {
                renderActor(mc, session, actor, partialTicks, now, cx, cy, cz);
            }
        } finally {
            GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
            GlStateManager.enableCull();
            GlStateManager.disableRescaleNormal();
            GlStateManager.disableBlend();
            mc.entityRenderer.disableLightmap();
            RenderHelper.disableStandardItemLighting();
            GlStateManager.popMatrix();
        }
    }

    private void renderActor(Minecraft mc, TaijutsuSession session, VirtualActor actor, float partialTicks,
                             float now, double cx, double cy, double cz) {
        session.actorWorldPos(actor, partialTicks, pos);
        actor.pose(now, pose);

        int light = mc.world.getCombinedLight(new BlockPos(pos[0], pos[1] + 1.0, pos[2]), 0);
        OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, (float) (light % 65536), (float) (light / 65536));

        float hurt = actor.hurtAmount(now);
        GlStateManager.color(1.0F, 1.0F - 0.45F * hurt, 1.0F - 0.45F * hurt, 1.0F);

        mc.getTextureManager().bindTexture(actor.slim ? ALEX : STEVE);
        GlStateManager.pushMatrix();
        GlStateManager.translate(pos[0] - cx, pos[1] - cy, pos[2] - cz);
        GlStateManager.rotate(180.0F - session.actorYaw(actor), 0.0F, 1.0F, 0.0F);
        RootTransform.apply(pose);
        GlStateManager.scale(-1.0F, -1.0F, 1.0F);
        GlStateManager.scale(0.9375F, 0.9375F, 0.9375F);
        GlStateManager.translate(0.0F, -1.501F, 0.0F);
        (actor.slim ? slim : wide).renderPosed(pose, MODEL_SCALE);
        GlStateManager.popMatrix();
    }
}
