package com.madarataijutsu.client.render;

import com.madarataijutsu.anim.Pose;
import net.minecraft.client.model.ModelPlayer;

/** Modelo humanoide dos adversários (Steve ou Alex), desenhado sem Entity. */
public class ActorModel extends ModelPlayer {

    private final float armPivotY;

    public ActorModel(boolean smallArms) {
        super(0.0F, smallArms);
        this.armPivotY = smallArms ? 2.5F : 2.0F;
    }

    public void renderPosed(Pose pose, float scale) {
        PoseApplier.apply(this, pose, armPivotY);
        bipedHead.render(scale);
        bipedBody.render(scale);
        bipedRightArm.render(scale);
        bipedLeftArm.render(scale);
        bipedRightLeg.render(scale);
        bipedLeftLeg.render(scale);
        bipedHeadwear.render(scale);
        bipedBodyWear.render(scale);
        bipedRightArmwear.render(scale);
        bipedLeftArmwear.render(scale);
        bipedRightLegwear.render(scale);
        bipedLeftLegwear.render(scale);
    }
}
