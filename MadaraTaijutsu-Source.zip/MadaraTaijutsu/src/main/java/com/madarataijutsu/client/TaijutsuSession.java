package com.madarataijutsu.client;

import com.madarataijutsu.choreo.ChoreographyLibrary;
import com.madarataijutsu.combat.CombatState;
import com.madarataijutsu.combat.CombatStateMachine;
import com.madarataijutsu.combat.VirtualActor;
import com.madarataijutsu.config.TaijutsuConfig;
import com.madarataijutsu.mode.ModeManager;
import com.madarataijutsu.mode.TaijutsuMode;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;

/**
 * Sessão de Taijutsu do jogador local: liga/desliga, relógio da cena, arena
 * e ponte entre a máquina de estados e o Minecraft. Vive somente no cliente.
 */
public final class TaijutsuSession {

    private static final TaijutsuSession INSTANCE = new TaijutsuSession();

    private final CombatStateMachine machine = new CombatStateMachine();
    private final ClientSceneFx fx = new ClientSceneFx(this);

    private boolean enabled;
    private int ticks;
    private float arenaYaw;
    private int savedThirdPerson = -1;
    private World boundWorld;

    private TaijutsuSession() {
        machine.setFx(fx);
    }

    public static TaijutsuSession get() {
        return INSTANCE;
    }

    // ------------------------------------------------------------ comandos

    public void toggle() {
        if (enabled) {
            deactivate(false);
        } else {
            activate();
        }
    }

    private void activate() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.player == null || mc.world == null) return;
        enabled = true;
        boundWorld = mc.world;
        if (TaijutsuConfig.autoThirdPerson() && mc.gameSettings.thirdPersonView == 0) {
            savedThirdPerson = 0;
            mc.gameSettings.thirdPersonView = 1;
        } else {
            savedThirdPerson = -1;
        }
        RestartManager.rebuild(this);
        status("§cTaijutsu ATIVADO §7(" + ModeManager.get().shortName()
                + ") §f- clique esquerdo para lutar");
    }

    /** Desliga o sistema e remove todos os atores. */
    public void deactivate(boolean silent) {
        if (!enabled) return;
        enabled = false;
        machine.stop();
        boundWorld = null;
        Minecraft mc = Minecraft.getMinecraft();
        if (savedThirdPerson >= 0 && mc.gameSettings != null && mc.gameSettings.thirdPersonView == 1) {
            mc.gameSettings.thirdPersonView = savedThirdPerson;
        }
        savedThirdPerson = -1;
        if (!silent) {
            status("§7Taijutsu desativado");
        }
    }

    public void restart() {
        if (!enabled) {
            status("§7Ative o Taijutsu primeiro (tecla " + keyName(KeyBindings.toggle) + ")");
            return;
        }
        RestartManager.rebuild(this);
        status("§eLuta reiniciada §7(" + ModeManager.get().shortName() + ")");
    }

    /** Chamado pelo menu ao confirmar um modo. */
    public void applyMode(TaijutsuMode mode) {
        boolean changed = ModeManager.set(mode);
        if (enabled && (changed || machine.state() == CombatState.VICTORY)) {
            RestartManager.rebuild(this);
        }
        status("§cModo selecionado: §f" + mode.label
                + (enabled ? "" : " §7(tecla " + keyName(KeyBindings.toggle) + " para ativar)"));
    }

    /** Clique esquerdo em jogo. Não cancela nem altera a ação vanilla. */
    void onLeftClick() {
        if (!enabled) return;
        machine.onClick(ticks);
    }

    void clientTick(Minecraft mc) {
        if (!enabled) return;
        if (mc.world == null || mc.player == null || mc.world != boundWorld) {
            // Saiu do mundo ou trocou de dimensão: encerra com segurança.
            deactivate(true);
            return;
        }
        if (mc.isGamePaused()) return;
        CombatState before = machine.state();
        ticks++;
        machine.tick(ticks);
        if (before != CombatState.VICTORY && machine.state() == CombatState.VICTORY) {
            status("§6Vitória! §7Pressione " + keyName(KeyBindings.restart) + " para lutar de novo");
        }
    }

    // ------------------------------------------------------------ uso interno

    void resetArena(Minecraft mc) {
        arenaYaw = mc.player.rotationYaw;
        machine.start(ChoreographyLibrary.get(ModeManager.get()), ticks);
    }

    private static String keyName(KeyBinding kb) {
        return kb == null ? "?" : kb.getDisplayName();
    }

    void status(String msg) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.player != null) {
            mc.player.sendStatusMessage(new TextComponentString(msg), true);
        }
    }

    // ------------------------------------------------------------ leitura

    public boolean isEnabled() {
        return enabled && machine.isActive();
    }

    public CombatStateMachine machine() {
        return machine;
    }

    public float now(float partialTicks) {
        return ticks + partialTicks;
    }

    public float arenaYaw() {
        return arenaYaw;
    }

    /** Direção de mundo (graus Minecraft) para onde o modelo do jogador encara. */
    public float playerRenderYaw(float partialTicks) {
        return arenaYaw + machine.player().facing(now(partialTicks));
    }

    /** Posição de mundo do ator (pés), centrada na posição interpolada do jogador. */
    public void actorWorldPos(VirtualActor actor, float partialTicks, double[] out) {
        Entity p = Minecraft.getMinecraft().player;
        double px = p.lastTickPosX + (p.posX - p.lastTickPosX) * partialTicks;
        double py = p.lastTickPosY + (p.posY - p.lastTickPosY) * partialTicks;
        double pz = p.lastTickPosZ + (p.posZ - p.lastTickPosZ) * partialTicks;
        double w = Math.toRadians(arenaYaw + actor.angle);
        double r = actor.radius(now(partialTicks));
        out[0] = px - Math.sin(w) * r;
        out[1] = py;
        out[2] = pz + Math.cos(w) * r;
    }

    /** Direção de mundo (graus Minecraft) do ator: sempre voltado ao jogador. */
    public float actorYaw(VirtualActor actor) {
        return arenaYaw + actor.angle + 180.0F;
    }
}
