package com.madarataijutsu.client.render;

import com.madarataijutsu.anim.Pose;
import com.madarataijutsu.rig.Mat4;
import com.madarataijutsu.rig.Skeleton;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.entity.Entity;
import net.minecraft.util.EnumHandSide;

/**
 * Modelo do jogador durante o Taijutsu: desenha o esqueleto articulado
 * (cotovelos, joelhos e cintura) com a skin e as camadas externas do jogador.
 */
public class TaijutsuPlayerModel extends ModelPlayer {

    private final boolean slim;
    private final Mat4[] bones = new Mat4[Skeleton.BONES];
    private final boolean[] wear = new boolean[6];
    private Pose pose;

    public TaijutsuPlayerModel(boolean smallArms) {
        super(0.0F, smallArms);
        this.slim = smallArms;
    }

    public void setPose(Pose pose) {
        this.pose = pose;
    }

    @Override
    public void render(Entity entityIn, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw,
                       float headPitch, float scale) {
        if (pose == null) {
            super.render(entityIn, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
            return;
        }
        Skeleton.compute(pose, slim, bones);
        // Respeita as opções de "Partes da skin" do jogador.
        wear[RigRenderer.WEAR_HAT] = bipedHeadwear.showModel;
        wear[RigRenderer.WEAR_JACKET] = bipedBodyWear.showModel;
        wear[RigRenderer.WEAR_R_SLEEVE] = bipedRightArmwear.showModel;
        wear[RigRenderer.WEAR_L_SLEEVE] = bipedLeftArmwear.showModel;
        wear[RigRenderer.WEAR_R_PANTS] = bipedRightLegwear.showModel;
        wear[RigRenderer.WEAR_L_PANTS] = bipedLeftLegwear.showModel;
        RigRenderer.render(bones, slim, scale, wear);
    }

    /** Usado pela camada de item na mão: posiciona o item no fim do antebraço. */
    @Override
    public void postRenderArm(float scale, EnumHandSide side) {
        if (pose == null || bones[0] == null) {
            super.postRenderArm(scale, side);
            return;
        }
        Mat4 anchor = Skeleton.handAnchor(bones, side == EnumHandSide.RIGHT);
        RigRenderer.multMatrix(anchor.withScaledTranslation(scale));
    }
}
