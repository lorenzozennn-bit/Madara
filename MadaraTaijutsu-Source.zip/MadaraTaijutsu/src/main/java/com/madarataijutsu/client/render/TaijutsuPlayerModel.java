package com.madarataijutsu.client.render;

import com.madarataijutsu.anim.Pose;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.entity.Entity;

/**
 * Modelo do jogador usado apenas durante o Taijutsu. Mantém a skin e as
 * camadas externas do ModelPlayer; depois da animação vanilla, sobrepõe a pose
 * coreografada.
 */
public class TaijutsuPlayerModel extends ModelPlayer {

    private final float armPivotY;
    private Pose pose;

    public TaijutsuPlayerModel(boolean smallArms) {
        super(0.0F, smallArms);
        this.armPivotY = smallArms ? 2.5F : 2.0F;
    }

    public void setPose(Pose pose) {
        this.pose = pose;
    }

    @Override
    public void setRotationAngles(float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw,
                                  float headPitch, float scaleFactor, Entity entityIn) {
        super.setRotationAngles(limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scaleFactor, entityIn);
        if (pose != null) {
            PoseApplier.apply(this, pose, armPivotY);
        }
    }
}
