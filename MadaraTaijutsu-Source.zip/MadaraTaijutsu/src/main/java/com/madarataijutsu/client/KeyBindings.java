package com.madarataijutsu.client;

import com.madarataijutsu.client.gui.GuiTaijutsuMenu;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import org.lwjgl.input.Keyboard;

/**
 * Gerenciador de controles: V (ativar/desativar), G (menu), R (reiniciar).
 * As teclas aparecem em Opções > Controles e podem ser alteradas pelo jogador.
 */
public final class KeyBindings {

    public static final String CATEGORY = "key.categories.madarataijutsu";

    public static KeyBinding toggle;
    public static KeyBinding menu;
    public static KeyBinding restart;

    private KeyBindings() {
    }

    static void register() {
        toggle = new KeyBinding("key.madarataijutsu.toggle", KeyConflictContext.IN_GAME, Keyboard.KEY_V, CATEGORY);
        menu = new KeyBinding("key.madarataijutsu.menu", KeyConflictContext.IN_GAME, Keyboard.KEY_G, CATEGORY);
        restart = new KeyBinding("key.madarataijutsu.restart", KeyConflictContext.IN_GAME, Keyboard.KEY_R, CATEGORY);
        ClientRegistry.registerKeyBinding(toggle);
        ClientRegistry.registerKeyBinding(menu);
        ClientRegistry.registerKeyBinding(restart);
    }

    /** Consome os pressionamentos acumulados neste tick. */
    static void poll(Minecraft mc) {
        if (toggle == null) return;
        TaijutsuSession session = TaijutsuSession.get();
        while (toggle.isPressed()) {
            session.toggle();
        }
        while (menu.isPressed()) {
            if (mc.currentScreen == null) {
                mc.displayGuiScreen(new GuiTaijutsuMenu());
            }
        }
        while (restart.isPressed()) {
            session.restart();
        }
    }
}
