package com.madarataijutsu.client.render;

import com.madarataijutsu.rig.BoxMesh;
import com.madarataijutsu.rig.Mat4;
import com.madarataijutsu.rig.Skeleton;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;

import java.nio.FloatBuffer;

/** Desenha o esqueleto articulado com a textura da skin já vinculada. */
public final class RigRenderer {

    /** Camadas externas: chapéu, jaqueta, mangas, calças. */
    public static final int WEAR_HAT = 0, WEAR_JACKET = 1, WEAR_R_SLEEVE = 2, WEAR_L_SLEEVE = 3,
            WEAR_R_PANTS = 4, WEAR_L_PANTS = 5;

    private static final FloatBuffer BUF = BufferUtils.createFloatBuffer(16);
    private static final boolean[] ALL_WEAR = {true, true, true, true, true, true};

    private RigRenderer() {
    }

    public static void multMatrix(Mat4 m) {
        BUF.clear();
        BUF.put(m.m);
        BUF.flip();
        GlStateManager.multMatrix(BUF);
    }

    /**
     * @param scale escala px -> blocos (0.0625 no RenderLivingBase; 1 se a matriz já inclui a escala)
     * @param wear  visibilidade das camadas externas, ou null para todas
     */
    public static void render(Mat4[] bones, boolean slim, float scale, boolean[] wear) {
        boolean[] w = wear == null ? ALL_WEAR : wear;
        for (int i = 0; i < Skeleton.BONES; i++) {
            GlStateManager.pushMatrix();
            if (scale != 1.0F) {
                GlStateManager.scale(scale, scale, scale);
            }
            multMatrix(bones[i]);
            draw(Skeleton.inner(slim, i));
            if (w[wearIndex(i)]) {
                draw(Skeleton.outer(slim, i));
            }
            GlStateManager.popMatrix();
        }
    }

    private static int wearIndex(int bone) {
        switch (bone) {
            case Skeleton.HEAD: return WEAR_HAT;
            case Skeleton.TORSO: return WEAR_JACKET;
            case Skeleton.R_UPPER_ARM:
            case Skeleton.R_FOREARM: return WEAR_R_SLEEVE;
            case Skeleton.L_UPPER_ARM:
            case Skeleton.L_FOREARM: return WEAR_L_SLEEVE;
            case Skeleton.R_THIGH:
            case Skeleton.R_SHIN: return WEAR_R_PANTS;
            default: return WEAR_L_PANTS;
        }
    }

    private static void draw(BoxMesh mesh) {
        Tessellator tess = Tessellator.getInstance();
        BufferBuilder buf = tess.getBuffer();
        buf.begin(GL11.GL_QUADS, DefaultVertexFormats.OLDMODEL_POSITION_TEX_NORMAL);
        for (BoxMesh.Quad q : mesh.quads()) {
            for (int v = 0; v < 4; v++) {
                buf.pos(q.xyz[v * 3], q.xyz[v * 3 + 1], q.xyz[v * 3 + 2])
                        .tex(q.uv[v * 2], q.uv[v * 2 + 1])
                        .normal(q.nx, q.ny, q.nz)
                        .endVertex();
            }
        }
        tess.draw();
    }
}
