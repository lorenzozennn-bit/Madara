package com.madarataijutsu.client.gui;

import com.madarataijutsu.client.TaijutsuSession;
import com.madarataijutsu.mode.ModeManager;
import com.madarataijutsu.mode.TaijutsuMode;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

import java.io.IOException;

/** Menu de seleção de modo (tecla G). */
public class GuiTaijutsuMenu extends GuiScreen {

    private static final int ID_CONFIRM = 100;
    private static final int ID_CANCEL = 101;
    private static final int BUTTON_W = 180;
    private static final int BUTTON_H = 20;
    private static final int SPACING = 23;

    private TaijutsuMode selected;
    private final GuiButton[] modeButtons = new GuiButton[TaijutsuMode.values().length];
    private int top;

    @Override
    public void initGui() {
        if (selected == null) {
            selected = ModeManager.get();
        }
        buttonList.clear();
        int cx = width / 2;
        top = height / 2 - 78;
        TaijutsuMode[] modes = TaijutsuMode.values();
        for (int i = 0; i < modes.length; i++) {
            GuiButton b = new GuiButton(i, cx - BUTTON_W / 2, top + i * SPACING, BUTTON_W, BUTTON_H, "");
            modeButtons[i] = b;
            buttonList.add(b);
        }
        int y = top + modes.length * SPACING + 14;
        buttonList.add(new GuiButton(ID_CONFIRM, cx - BUTTON_W / 2, y, BUTTON_W / 2 - 2, BUTTON_H, "Confirmar"));
        buttonList.add(new GuiButton(ID_CANCEL, cx + 2, y, BUTTON_W / 2 - 2, BUTTON_H, "Cancelar"));
        refreshLabels();
    }

    private void refreshLabels() {
        TaijutsuMode active = ModeManager.get();
        TaijutsuMode[] modes = TaijutsuMode.values();
        for (int i = 0; i < modes.length; i++) {
            TaijutsuMode m = modes[i];
            String text = m.label;
            if (m == selected) {
                text = "§c» §f" + text + " §c«";
            }
            if (m == active) {
                text = text + " §a✔";
            }
            modeButtons[i].displayString = text;
        }
    }

    @Override
    protected void actionPerformed(GuiButton button) throws IOException {
        if (button.id >= 0 && button.id < modeButtons.length) {
            selected = TaijutsuMode.values()[button.id];
            refreshLabels();
        } else if (button.id == ID_CONFIRM) {
            TaijutsuSession.get().applyMode(selected);
            mc.displayGuiScreen(null);
        } else if (button.id == ID_CANCEL) {
            mc.displayGuiScreen(null);
        }
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawDefaultBackground();
        int cx = width / 2;

        drawCenteredString(fontRenderer, "§c§lMADARA TAIJUTSU", cx, top - 40, 0xFFFFFF);
        TaijutsuSession session = TaijutsuSession.get();
        String status = "Modo ativo: §e" + ModeManager.get().shortName()
                + "§r   Taijutsu: " + (session.isEnabled() ? "§aLIGADO" : "§7DESLIGADO");
        drawCenteredString(fontRenderer, status, cx, top - 24, 0xDDDDDD);

        // Destaque do modo selecionado: moldura vermelha atrás do botão.
        int idx = selected.ordinal();
        int bx = cx - BUTTON_W / 2;
        int by = top + idx * SPACING;
        drawRect(bx - 2, by - 2, bx + BUTTON_W + 2, by + BUTTON_H + 2, 0xFFB3121A);

        super.drawScreen(mouseX, mouseY, partialTicks);

        drawCenteredString(fontRenderer, "§7Foco: " + selected.focus, cx,
                top + TaijutsuMode.values().length * SPACING + 2, 0xAAAAAA);
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }
}
