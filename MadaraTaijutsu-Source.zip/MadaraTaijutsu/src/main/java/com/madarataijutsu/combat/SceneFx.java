package com.madarataijutsu.combat;

import com.madarataijutsu.choreo.ImpactType;

/** Ponte entre a lógica da luta (Java puro) e os efeitos do cliente (sons, partículas, mensagens). */
public interface SceneFx {

    void onImpact(VirtualActor actor, ImpactType type);

    void onActorDefeated(VirtualActor actor);

    void onVictory();

    /** Implementação vazia para testes e para quando não há mundo carregado. */
    SceneFx SILENT = new SceneFx() {
        @Override
        public void onImpact(VirtualActor actor, ImpactType type) {
        }

        @Override
        public void onActorDefeated(VirtualActor actor) {
        }

        @Override
        public void onVictory() {
        }
    };
}
