package com.madarataijutsu.combat;

import com.madarataijutsu.choreo.ActorAction;
import com.madarataijutsu.choreo.ActorClips;
import com.madarataijutsu.choreo.ImpactType;

import java.util.List;

/** Controlador de animações dos adversários: aplica as ações do roteiro e mantém a postura neutra. */
final class ActorAnimationController {

    private ActorAnimationController() {
    }

    static void reset(List<VirtualActor> actors, float now, float startRadius) {
        for (VirtualActor a : actors) {
            a.defeated = false;
            a.hurtUntil = -1.0F;
            a.radius.reset(startRadius);
            a.track.snap(ActorClips.GUARD_IDLE, now);
        }
    }

    /** Executa uma ação no instante exato em que ela foi agendada. */
    static void apply(VirtualActor actor, ActorAction action, float at, SceneFx fx) {
        if (actor.defeated && !action.defeat) {
            return;
        }
        if (action.clip != null) {
            actor.track.play(action.clip, at, 2.0F);
        }
        if (action.movesRadius()) {
            actor.radius.moveTo(action.radius, at, action.moveTicks);
        }
        if (action.impact == ImpactType.HIT || action.impact == ImpactType.HEAVY) {
            actor.hurtUntil = at + 5.0F;
        }
        if (action.impact != ImpactType.NONE) {
            fx.onImpact(actor, action.impact);
        }
        if (action.defeat && !actor.defeated) {
            actor.defeated = true;
            fx.onActorDefeated(actor);
        }
    }

    /** Atores que terminaram um golpe voltam à guarda; derrotados permanecem caídos. */
    static void returnToNeutral(List<VirtualActor> actors, float now) {
        for (VirtualActor a : actors) {
            if (!a.defeated && a.track.isFinished(now)) {
                a.track.play(ActorClips.followUp(a.track.clip()), now, 4.0F);
            }
        }
    }
}
