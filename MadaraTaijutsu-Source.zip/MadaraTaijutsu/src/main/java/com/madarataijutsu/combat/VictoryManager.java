package com.madarataijutsu.combat;

import com.madarataijutsu.choreo.ActorClips;
import com.madarataijutsu.choreo.PlayerClips;

import java.util.List;

/**
 * Gerenciador de vitória: decide quando a luta terminou, garante que todos os
 * adversários estejam caídos e coloca o jogador na pose de vitória.
 */
final class VictoryManager {

    private VictoryManager() {
    }

    /** A última etapa terminou? */
    static boolean isFightOver(int stepIndex, int stepCount, float stepElapsed, int lastStepDuration) {
        return stepIndex == stepCount - 1 && stepElapsed >= lastStepDuration;
    }

    static void enterVictory(List<VirtualActor> actors, PlayerAnimationController player, float now, SceneFx fx) {
        for (VirtualActor a : actors) {
            if (!a.defeated) {
                // Proteção: nenhuma coreografia deveria chegar aqui, mas o estado final é garantido.
                a.defeated = true;
                a.track.play(ActorClips.FALL_BACK, now, 2.0F);
                fx.onActorDefeated(a);
            }
        }
        player.play(PlayerClips.VICTORY, now, 4.0F);
        fx.onVictory();
    }
}
