package com.madarataijutsu.mode;

/** Os cinco modos de taijutsu e o número de adversários de cada um. */
public enum TaijutsuMode {
    ONE_V_ONE(1, "Taijutsu 1v1", "Combate técnico"),
    ONE_V_TWO(2, "Taijutsu 1v2", "Alternância entre alvos"),
    ONE_V_THREE(3, "Taijutsu 1v3", "Mobilidade"),
    ONE_V_FOUR(4, "Taijutsu 1v4", "Combate avançado"),
    ONE_V_FIVE(5, "Taijutsu 1v5", "Coreografia cinematográfica");

    public final int opponents;
    public final String label;
    public final String focus;

    TaijutsuMode(int opponents, String label, String focus) {
        this.opponents = opponents;
        this.label = label;
        this.focus = focus;
    }

    public String shortName() {
        return "1v" + opponents;
    }

    public static TaijutsuMode byOpponents(int n) {
        for (TaijutsuMode m : values()) {
            if (m.opponents == n) return m;
        }
        return ONE_V_ONE;
    }
}
