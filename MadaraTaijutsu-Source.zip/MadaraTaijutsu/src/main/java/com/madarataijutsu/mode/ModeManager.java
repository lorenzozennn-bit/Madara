package com.madarataijutsu.mode;

import com.madarataijutsu.config.TaijutsuConfig;

/** Gerenciador de modos: modo atual, carregado e salvo pela configuração. */
public final class ModeManager {

    private static TaijutsuMode current = TaijutsuMode.ONE_V_ONE;

    private ModeManager() {
    }

    public static void loadFromConfig() {
        current = TaijutsuConfig.getMode();
    }

    public static TaijutsuMode get() {
        return current;
    }

    /** Define e salva. Retorna true se o modo mudou. */
    public static boolean set(TaijutsuMode mode) {
        if (mode == null) return false;
        boolean changed = mode != current;
        current = mode;
        TaijutsuConfig.setMode(mode);
        return changed;
    }
}
