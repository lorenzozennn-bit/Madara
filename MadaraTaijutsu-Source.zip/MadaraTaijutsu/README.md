# Madara Taijutsu Cinematic — Forge 1.12.2

Mod **client-side** de lutas cinematográficas de taijutsu em terceira pessoa contra
adversários virtuais (1v1 a 1v5), inspirado na agilidade do Madara na Quarta Guerra Ninja.

- Mod ID: `madarataijutsu` · Versão: 1.0.0 · Minecraft 1.12.2 · Forge 14.23.5.2847 (roda também no 2860) · Java 8
- Sem dependências além do Forge. Independente de Epic Fight e Mo' Bends.

## Controles (alteráveis em Opções → Controles → "Madara Taijutsu")

| Tecla | Ação |
|---|---|
| **V** | Liga/desliga o Taijutsu (liga a câmera em 3ª pessoa automaticamente) |
| **G** | Menu **MADARA TAIJUTSU**: escolha 1v1…1v5 e confirme |
| **R** | Reinicia a luta (adversários de volta, em pé, nas posições iniciais) |
| **Botão esquerdo** | Avança a coreografia uma etapa por clique |

O clique esquerdo **não é cancelado**: socos reais, mineração e interações continuam normais.
Cliques rápidos ficam numa fila de 1 e só disparam quando o golpe atual já percorreu 70%.
Ao fim, todos os adversários ficam caídos, o jogador faz a pose de vitória e só **R** recomeça.

## Modos

| Modo | Etapas | Foco |
|---|---|---|
| 1v1 | 11 | jab, direto, gancho, chutes, bloqueio, esquivas, finalização com chute giratório |
| 1v2 | 12 | frente/costas, desvios laterais, chute lateral no segundo, finalização dupla |
| 1v3 | 14 | segue o roteiro do pedido (avanço → soco → esquiva → chute → giro …) |
| 1v4 | 17 | mortal para trás, ataques coordenados, chute giratório saltado |
| 1v5 | 19 | ataques simultâneos, mudanças rápidas de direção, finalização derrubando os dois últimos |

## Arquitetura

```
com.madarataijutsu
├─ MadaraTaijutsu            classe principal (@Mod, clientSideOnly)
├─ proxy/CommonProxy, client/ClientProxy
├─ config/TaijutsuConfig      persistência (config/madarataijutsu.cfg)
├─ mode/TaijutsuMode, ModeManager   gerenciador de modos
├─ client/KeyBindings          gerenciador de controles (V/G/R)
├─ client/gui/GuiTaijutsuMenu  interface gráfica (GuiScreen)
├─ client/TaijutsuSession      sessão: liga/desliga, relógio, arena
├─ client/RestartManager       gerenciador de reinício
├─ client/ClientSceneFx        sons/partículas só no cliente
├─ anim/*                      sistema de keyframes (Pose, Keyframe, Ease, Clip, AnimTrack, ScalarTrack)
├─ choreo/PlayerClips, ActorClips   animações do jogador e dos adversários
├─ choreo/ChoreographyLibrary  gerenciador de coreografias (5 sequências)
├─ combat/CombatStateMachine   máquina de estados (INACTIVE → READY → PLAYING → VICTORY)
├─ combat/PlayerAnimationController, ActorAnimationController, VictoryManager
└─ client/render/*             renderizador do jogador, modelo, renderizador dos atores
```

Decisões técnicas:
- **Adversários não são entidades.** São desenhados no `RenderWorldLastEvent` com o `ModelPlayer`
  vanilla e as skins Steve/Alex. Não há hitbox, colisão, dano, drops, IA, pacotes nem dados salvos.
- **O jogador só muda visualmente.** Enquanto ativo, o desenho do jogador local é feito por um
  `RenderPlayer` próprio (instância separada, com a skin e as camadas externas). Os renderizadores
  vanilla nunca são alterados, então desligar com V restaura tudo na hora. Posição, hitbox, alcance,
  dano e física não são tocados.
- **Suavidade:** tempo contínuo `ticks + partialTicks`, curvas de easing por keyframe e crossfade
  automático entre clipes (com correção de giros de 360°).
- **Segurança:** ao sair do mundo, trocar de dimensão ou descarregar o mundo, a sessão é encerrada.

## Como obter o JAR

### Opção A — GitHub Actions (sem instalar nada)
1. Crie um repositório no GitHub e envie esta pasta inteira (incluindo `.github/`).
2. Aba **Actions** → workflow **Build MadaraTaijutsu** roda sozinho (ou clique em *Run workflow*).
3. Ao terminar, baixe o artefato **MadaraTaijutsu-1.12.2-1.0.0** — dentro está o `.jar`.

### Opção B — no seu computador
1. Instale o **JDK 8** (ex.: Temurin 8) e deixe-o como `JAVA_HOME`.
2. Na pasta do projeto:
   - Windows: `gradlew.bat setupDecompWorkspace build`
   - Linux/macOS: `./gradlew setupDecompWorkspace build`
3. O arquivo sai em `build/libs/MadaraTaijutsu-1.12.2-1.0.0.jar`.
4. Copie para `.minecraft/mods/` (perfil Forge 1.12.2).

Para testar no ambiente de desenvolvimento: `gradlew runClient`.

Se o ForgeGradle 2.3 falhar ao baixar algo (o ecossistema do 1.12.2 é antigo), use o MDK oficial:
baixe o MDK 1.12.2-14.23.5.2847 em files.minecraftforge.net, copie `src/` deste projeto para
dentro dele (substituindo o exemplo) e rode o mesmo comando de build.

## Teste da lógica

`tools/ChoreoSimTest.java` simula os 5 modos sem o Minecraft (cliques espaçados, spam de cliques,
cliques lentos), verificando vitória, todos derrotados, cliques ignorados após a vitória, reinício e
que nenhuma pose fica inválida. Roda automaticamente no GitHub Actions.

## Limitações conhecidas
- Braços e pernas do modelo do Minecraft não têm cotovelo/joelho; os golpes são estilizados com
  membros inteiros, tronco e giros do corpo (preserva 100% a compatibilidade com skins).
- A armadura vestida segue a animação vanilla, não a coreografada. Itens na mão acompanham o braço.
- Terreno irregular: os atores ficam na altura dos pés do jogador.
- Apenas singleplayer/cliente local; outros jogadores não veem a cena.
